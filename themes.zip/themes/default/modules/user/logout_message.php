<h2 class="">Logout out - successful</h2>
<a class="" href="<?php echo $login_link; ?>">Login</a>
<div class="box box-info">
    <div class="box-header with-border">
        <h3 class="box-title"><?php echo $form_title; ?></h3>
    </div><!-- /.box-header -->
    <!-- form start -->
    <form class="form-horizontal">
        <div class="box-body">
        <?php echo $form_content; ?>    
        </div><!-- /.box-body -->
        <div class="box-footer">
            <?php echo $form_footer; ?>    
        </div><!-- /.box-footer -->
    </form>
</div>
<div class="form-group">
    <label for="<?php echo $name; ?>" class="col-sm-2 control-label"><?php echo $label; ?></label>
    <div class="col-sm-10">
        <input class="form-control" id="<?php echo $name; ?>" name="<?php echo $name; ?>" value="<?php echo $value; ?>" placeholder="<?php echo $label; ?>" type="<?php echo $type; ?>" <?php echo $status; ?>>
    </div>
</div>



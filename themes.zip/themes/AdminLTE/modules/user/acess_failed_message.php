<div class="box box-primary">
    <div class="box-header with-border">
        <h3 class="box-title">Access to this Page is not permitted to your Role</h3>
        <span class="label label-primary pull-right"><a class="" href="<?php echo $home . '/user/auth/logout'; ?>"><i class="fa fa-long-arrow-up"></i></a></span>
    </div><!-- /.box-header -->
    <div class="box-body">
        <p>Access to this Page is not permitted to your Role</p>
        <a class="btn btn-primary" href="<?php echo $home . '/user/auth/logout'; ?>"><i class="fa fa-long-arrow-right"></i> Logout</a>
    </div><!-- /.box-body -->
</div>


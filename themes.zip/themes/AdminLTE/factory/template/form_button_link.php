<div class="col-sm-2">
    <a href="<?php echo $home.'/'.$module.'/'.$controller.'/'.$method; ?>" class="btn btn-md btn-info btn-flat pull-left"><?php echo $label; ?></a>
</div>






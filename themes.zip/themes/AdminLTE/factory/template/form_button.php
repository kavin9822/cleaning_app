    <div class="col-sm-2">
<button id="<?php echo $name; ?>" name="<?php echo $name; ?>" type="<?php echo $type; ?>" class="btn btn-info" <?php if(isset($status)){echo $status;} ?>><?php echo $label; ?></button>
    </div>



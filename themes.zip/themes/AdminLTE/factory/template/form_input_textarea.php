<div class="form-group">
    <label for="<?php echo $name; ?>" class="col-sm-2 control-label"><?php echo $label; ?></label>
    <div class="col-sm-10">
        <textarea id="<?php echo $name; ?>" name="<?php echo $name; ?>" class="form-control" rows="<?php echo $number_of_rows; ?>" placeholder="<?php echo $label; ?>"><?php echo $value; ?></textarea>
    </div>
</div>
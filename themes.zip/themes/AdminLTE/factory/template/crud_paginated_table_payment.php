<div class="row visible-print-block">
    <div class="col-md-12">    
         <h3>
         	<img class="img" src="<?php echo $invoice_logo; ?>" alt="Logo">
         	<?php echo $company_name; ?>         	
         </h3>         
    </div> 
</div>
<div class="row">
    <div class="col-md-12">
         <h4>   <?php echo "Payment Voucher" ?>  </h4>
    </div>
</div>



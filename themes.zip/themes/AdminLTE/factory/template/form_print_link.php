<div class="col-sm-2">
    <a href="<?php echo $home.'/'.$module.'/'.$controller.'/'.$method; ?>" class="no-print btn btn-md btn-info btn-flat pull-left"><?php echo $label; ?></a>
</div>

<div class="col-sm-2">    
          <a target="_blank" class="btn btn-success pull-right no-print" onclick="javascript:window.print()"><i class="fa fa-print"></i><?php echo " Print"; ?></a>
</div>

<!-- /.Print footer -->    
<div class="col-lg-10 visible-print-block">
        <h4 class="widget-user-username text-right">Authorised Signatory</h4>
</div>






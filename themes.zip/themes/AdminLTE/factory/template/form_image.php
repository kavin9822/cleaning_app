<div class="form-group">
    <label for="<?php echo $name; ?>" class="col-sm-3 label-default"><?php echo $label; ?></label>
    <div class="col-sm-9">
        <img class="img-thumbnail" name ="$name" src="<?php echo $home.'/'.$value; ?>" alt="Upload the file" width="150px">
    </div>
</div>
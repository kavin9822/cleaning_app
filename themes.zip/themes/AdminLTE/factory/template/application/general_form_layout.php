<div class="box box-primary">
    <div class="box-header">
        <h3 class="box-title  hidden-print"><?php if(isset($form_title)){echo $form_title;} ?></h3>
    </div>
    <div class="box-body">
        <!-- Date range -->
        <div class="form-group">
            <div class="input-group">
                <?php if(isset($sub_content)){echo $sub_content;} ?>
            </div>
        </div><!-- /.form group -->
    </div><!-- /.box-body -->
</div>
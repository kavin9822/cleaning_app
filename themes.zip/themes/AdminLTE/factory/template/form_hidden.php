<input class="form-control" id="<?php echo $name; ?>" name="<?php echo $name; ?>" value="<?php echo $value; ?>" type="<?php echo $type; ?>" <?php if(isset($status)){echo $status;} ?>>


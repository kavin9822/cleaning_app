                <div class="form-group">
                    <label for="role_ID" class="col-sm-4 control-label">Over Write</label>
                    <div class="col-sm-4">
                        <select class="form-control" name="write" id="write">
                            <option  value="Y" >Yes</option>
                            <option  value="N" >No</option>
                        </select>
                    </div>
                </div>        
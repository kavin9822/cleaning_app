<?php
/*
* Modules list in php array
*/

return array(
	'admin',
	'customer',
	'employee',
	'user',
    'sales'
    );
This directory contains the core components of PHP-RBAC. The v2.x Public PSR Compliant API wraps around these core components to do it's magic.

The contents of this directory will be updated in the future to meet modern 'OOP Best Practices' while complying with PSR recommendations.
<?php
#development
set_include_path(".;C:/xampp/htdocs/mfg/lib");

#production
//set_include_path(".:/var/app/current/lib");

//Set default local timezone(SGT) settings.
date_default_timezone_set('Asia/Singapore');

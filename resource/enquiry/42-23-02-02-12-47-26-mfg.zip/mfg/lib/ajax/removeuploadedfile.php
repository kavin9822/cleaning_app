<?php

/*
 * Production - linux
 */

include_once './set_inc_path.php';

include_once 'util/ses.php';
$ajxSess = new Session();

include_once 'PhpRbac/database/database.config';

try {
    $Db = new PDO("mysql:host={$host};dbname={$dbname}", $user, $pass);
} catch (Exception $exc) {
    
}


header('Content-Type: application/json');

try {
        
            $args = array(
            'purchaseentry_ID' => FILTER_SANITIZE_STRING,
            );
    
            $peattach_id = filter_input(INPUT_POST, 'purchaseentry_ID', FILTER_SANITIZE_STRING);
           

        $peattach_table_name = $tablePrefix . 'purchaseentry_attachmentdetails';

 
        $pe_id = false;
        if(!empty($peattach_id)){
           $pe_id  =  $Db->quote($peattach_id);
        }
       
        if(empty($pe_id)){
            http_response_code(204);
            echo json_encode(array('message' => 'failed to add'));
            return;
        }
        
        
        
        //DELETE FROM `ycias_wishlist` WHERE `ycias_wishlist`.`ID` = 16"
      $sql_query = "DELETE FROM `$peattach_table_name` WHERE ID = $pe_id";

        $stmt = $Db->prepare($sql_query);
        if($stmt->execute()){
             	http_response_code(200);
             	             	echo json_encode(array('message' => 'removed Succesfully'));

            
        }else{
             	http_response_code(204);
             	echo json_encode(array('message' => 'failed to remove'));
            
        }

    } catch (Exception $exc) {
          http_response_code(204);
          echo json_encode(array('message' => 'failed to remove'));
          
    }
   
?>


       
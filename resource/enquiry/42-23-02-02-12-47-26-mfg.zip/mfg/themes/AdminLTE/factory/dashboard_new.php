<section class="content-header">
    <h1 class="text-center">
        <img src="<?php echo $invoice_logo; ?>" class="img" alt="Invoice Logo" style="height:65px;"> &nbsp;
        <?php echo $company_name; ?> Dashboard</h1>
</section>
<br/>

<div class="row">
    <div class="col-md-3" >
    </div>
    <div class="col-md-6 center-block" style="margin: 5% auto">
    <!-- LINE CHART -->
    <div class="box box-info">
        <div class="box-header with-border">
            <h3 class="box-title text-green"><b>YCIAS</b></h3>
        </div>
        <div class="box-body" style="display: block;">

            <div class="row">
                <div class="col-xs-12">
                    <p style="font-size:20px;">Yajurr Customer Information and Accounting System</p>
                </div> 
            </div>

            
            
            <div class="row">
                <div class="col-xs-5">
                    <p><b>Version:</b> 1.0</p>
                    <p><b>Release:</b> 01-Oct-2016</p> 
                </div> 
                <div class="col-xs-7">
                    <p style="text-align: right"><b>Developed By</b></p>
                    <a  target=\"_blank\" href="http://www.whyceeyes.com/"><p style="text-align: right">Yajurr Computer Solution Pvt. Ltd.</p></a> 
                </div>    

            </div>

        </div>
        <!-- /.box-body -->
    </div>
    <!-- /.box -->
</div>
</div>

<?php

echo base64_decode(base64_decode('82537d10965c4a20fe6ea0530edb4091')); 

?>

<br>

<?php

echo md5('veda@2000');
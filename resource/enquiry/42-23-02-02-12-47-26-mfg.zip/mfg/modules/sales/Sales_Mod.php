<?php

/**
 * Description of Product_Mod
 *
 * @author psmahadevan
 */
class Sales_Mod {

    private $crg;
    private $ses;
    private $db;
    private $sd;
    private $tpl;
    private $rbac;

    public function __construct($reg = NULL) {
        /*
         * Receiving $rg array
         */
        $this->crg = $reg;

        /*
         * geting object from reg array
         */
        $this->ses = $this->crg->get('ses');
        $this->db = $this->crg->get('db');
        $this->sd = $this->crg->get('SD');
        $this->tpl = $this->crg->get('tpl');
        $this->rbac = $this->crg->get('rbac');
    }
    
///////////////////// Enquiry_Form//////////////////
    
function enquiry(){
     
        if ($this->crg->get('wp') || $this->crg->get('rp')) {
             
            /////////////////////////////////////////////////////////////////
            //////////////////////////////access condition applied///////////
            /////////////////////////////////////////////////////////////////
            
            include_once 'util/DBUTIL.php';
            $dbutil = new DBUTIL($this->crg);
            
            include_once 'util/genUtil.php';
            $util = new GenUtil();
             
            $entityID = $this->ses->get('user')['entity_ID'];
            $userID = $this->ses->get('user')['ID'];
            
            $pdt_table = $this->crg->get('table_prefix') . 'product';
            $employee_table = $this->crg->get('table_prefix') . 'employee';
            $pdndept_table = $this->crg->get('table_prefix') . 'pdndepartment';
            $dept_table = $this->crg->get('table_prefix') . 'department';
            $rawmaterial_table = $this->crg->get('table_prefix') . 'rawmaterial';
            $unit_table = $this->crg->get('table_prefix') . 'unit';
            $enquirydetail_tab = $this->crg->get('table_prefix') . 'enquirydetail';
            $enquirymaster_tab = $this->crg->get('table_prefix') . 'enquiry';
            $customer_table = $this->crg->get('table_prefix') . 'customer';
            $state_table = $this->crg->get('table_prefix') . 'state';
            $country_table = $this->crg->get('table_prefix') . 'country';
           
           //product table data 
           
            $pdt_sql = "SELECT ID,ProductName FROM $pdt_table";
            $stmt = $this->db->prepare($pdt_sql);            
            $stmt->execute();
            $pdt_data  = $stmt->fetchAll();	
            $this->tpl->set('pdt_data', $pdt_data);
            
            //employee table data 
           
            $emp_sql = "SELECT $employee_table.ID,$employee_table.EmpName FROM $employee_table,$dept_table WHERE $employee_table.department_ID=$dept_table.ID AND $dept_table.DeptName='sales'";
            $stmt = $this->db->prepare($emp_sql);            
            $stmt->execute();
            $employee_data  = $stmt->fetchAll();	
            $this->tpl->set('employee_data', $employee_data);
            
            // mode of enquiry array
            
            $enquirymode_data = array(array("ID"=>"1","Title"=>"Walk-In"),array("ID"=>"2","Title"=>"Telephone"),array("ID"=>"3","Title"=>"IndiaMart"),array("ID"=>"4","Title"=>"Others"));
            $this->tpl->set('enquirymode_data', $enquirymode_data);
            
             // costrequired_data array
            
            $costrequired_data = array(array("ID"=>"1","Title"=>"Yes"),array("ID"=>"2","Title"=>"No"));
            $this->tpl->set('costrequired_data', $costrequired_data);
            
            // order received array
            
            $orderreceived_data = array(array("ID"=>"1","Title"=>"Yes"),array("ID"=>"2","Title"=>"No"));
            $this->tpl->set('orderreceived_data', $orderreceived_data);
            
            // enquiry status array
            
            $enquirystatus_data = array(array("ID"=>"1","Title"=>"Quotation Sent"),array("ID"=>"2","Title"=>"Order Placed"),array("ID"=>"3","Title"=>"Dropped"));
            $this->tpl->set('enquirystatus_data', $enquirystatus_data);
            
            // enquiry type  array
            
            $enquirytype_data = array(array("ID"=>"1","Title"=>"Enquiry"),array("ID"=>"2","Title"=>"Tender"));
            $this->tpl->set('enquirytype_data', $enquirytype_data);
            
            //department table data 
           
            $dept_sql = "SELECT ID,DeptName FROM $pdndept_table  ORDER BY ID DESC";
            $stmt = $this->db->prepare($dept_sql);            
            $stmt->execute();
            $department_data  = $stmt->fetchAll();	
            $this->tpl->set('department_data', $department_data);
            
            //process table data
           
            $pdt_sql = "SELECT ID,Process FROM $processdetail_tab";
            $stmt = $this->db->prepare($pdt_sql);            
            $stmt->execute();
            $process_data  = $stmt->fetchAll();	
            $this->tpl->set('process_data', $process_data);
            
            //rawmaterial table data
           
            $pdt_sql = "SELECT ID,RMName FROM $rawmaterial_table";
            $stmt = $this->db->prepare($pdt_sql);            
            $stmt->execute();
            $rawmaterial_data  = $stmt->fetchAll();	
            $this->tpl->set('rawmaterial_data', $rawmaterial_data);
            
            //unit table data
           
            $pdt_sql = "SELECT ID,UnitName FROM $unit_table";
            $stmt = $this->db->prepare($pdt_sql);            
            $stmt->execute();
            $unit_data  = $stmt->fetchAll();	
            $this->tpl->set('unit_data', $unit_data);
            
           
            $this->tpl->set('page_title', 'Enquiry');	          
            $this->tpl->set('page_header', 'Production');
            //Add Role when u submit the add role form
            $thisPageURL = $this->crg->get('route')['base_path'] . '/' . $this->crg->get('route')['module'] . '/' . $this->crg->get('route')['controller'] . '/' . $this->crg->get('route')['action'];

            $crud_string = null;
	
            if (isset($_POST['req_from_list_view'])) {
                $crud_string = strtolower($_POST['req_from_list_view']);
            }              
            
            //Edit submit
            if (!empty($_POST['edit_submit_button']) && $_POST['edit_submit_button'] == 'edit') {
                $crud_string = 'editsubmit';
            }

            //Add submit
            if (!empty($_POST['add_submit_button']) && $_POST['add_submit_button'] == 'add') {
                $crud_string = 'addsubmit';
            }


            switch ($crud_string) {
                 case 'delete':                    
                      $data = trim($_POST['ycs_ID']);
                      // var_dump($data); 
                       
                       
                    if (!$data) {
                        $this->tpl->set('message', 'Please select any one ID to '.$crud_string.'!');
                        $this->tpl->set('label', 'List');
                        $this->tpl->set('content', $this->tpl->fetch('factory/template/form_button_link.php'));
                       
                    }
                     
                     $sqldetdelete="Delete $enquirydetail_tab,$enquirymaster_tab from $enquirymaster_tab
                                        LEFT JOIN  $enquirydetail_tab ON $enquirymaster_tab.ID=$enquirydetail_tab.enquiry_ID 
                                        where $enquirydetail_tab.enquiry_ID=$data"; 
                        $stmt = $this->db->prepare($sqldetdelete);            
                        
                        if($stmt->execute()){
                        $this->tpl->set('message', 'Enquiry deleted successfully');
                        header('Location:' . $this->crg->get('route')['base_path'] . '/sales/cst/enquiry');
                        // $this->tpl->set('label', 'List');
                        // $this->tpl->set('content', $this->tpl->fetch('factory/template/form_button_link.php'));
                        }
            break;
                case 'view':                    
                    $data = trim($_POST['ycs_ID']);
                 
                    if (!$data) {
                        $this->tpl->set('message', 'Please select any one ID to view!');
                        $this->tpl->set('label', 'List');
                        $this->tpl->set('content', $this->tpl->fetch('factory/template/form_button_link.php'));
                        break;
                    }
                    
                    //mode of form submit
                    $this->tpl->set('mode', 'view');
                    //set id to edit $ycs_ID
                    $this->tpl->set('ycs_ID', $data);         
                                
                    $sqlsrr = "SELECT * FROM  `$enquirymaster_tab` LEFT JOIN `$enquirydetail_tab` ON  `$enquirymaster_tab`.`ID`=`$enquirydetail_tab`.`enquiry_ID` LEFT JOIN `$customer_table` ON  `$enquirymaster_tab`.`customer_ID`=`$customer_table`.`ID` WHERE `$enquirymaster_tab`.`ID` = '$data'";                    
                    $enquiry_data = $dbutil->getSqlData($sqlsrr); 
                    
                    //var_dump($enquiry_data[0]);
                    
                    $stateid=$enquiry_data[0]['BillingState_ID'];
                    $countryid=$enquiry_data[0]['BillingCountry_ID'];
                    
                    //state table data 
           
                    $state_sql = "SELECT ID,StateName FROM $state_table where ID=$stateid";
                    $stmt = $this->db->prepare($state_sql);            
                    $stmt->execute();
                    $state_data  = $stmt->fetchAll();	
                    $this->tpl->set('state_data', $state_data);
                    
                    //country table data 
           
                    $country_sql = "SELECT ID,CountryName FROM $country_table where ID=$countryid";
                    $stmt = $this->db->prepare($country_sql);            
                    $stmt->execute();
                    $country_data  = $stmt->fetchAll();	
                    $this->tpl->set('country_data', $country_data);

                    
                    //edit option     
                    $this->tpl->set('message', 'You can view Enquiry  form');
                    $this->tpl->set('page_header', 'Production');
                    $this->tpl->set('FmData', $enquiry_data); 
                    
                    $this->tpl->set('content', $this->tpl->fetch('factory/form/enquiry_form.php'));                    
                    break;
                
                case 'edit':                    
                    $data = trim($_POST['ycs_ID']);
               // var_dump($data);
                    if (!$data) {
                        $this->tpl->set('message', 'Please select any one ID to edit!');
                        $this->tpl->set('label', 'List');
                        $this->tpl->set('content', $this->tpl->fetch('factory/template/form_button_link.php'));
                        break;
                    }
                    
                    //mode of form submit
                    $this->tpl->set('mode', 'edit');
                    //set id to edit $ycs_ID
                    $this->tpl->set('ycs_ID', $data);         
                                
                    $sqlsrr = "SELECT * FROM  `$enquirymaster_tab` LEFT JOIN `$enquirydetail_tab` ON  `$enquirymaster_tab`.`ID`=`$enquirydetail_tab`.`enquiry_ID` LEFT JOIN `$customer_table` ON  `$enquirymaster_tab`.`customer_ID`=`$customer_table`.`ID` WHERE `$enquirymaster_tab`.`ID` = '$data'";                    
                    $enquiry_data = $dbutil->getSqlData($sqlsrr); 
                    
                    //var_dump($enquiry_data[0]);
                    
                    $stateid=$enquiry_data[0]['BillingState_ID'];
                    $countryid=$enquiry_data[0]['BillingCountry_ID'];
                    
                    //state table data 
           
                    $state_sql = "SELECT ID,StateName FROM $state_table where ID=$stateid";
                    $stmt = $this->db->prepare($state_sql);            
                    $stmt->execute();
                    $state_data  = $stmt->fetchAll();	
                    $this->tpl->set('state_data', $state_data);
                    
                    //country table data 
           
                    $country_sql = "SELECT ID,CountryName FROM $country_table where ID=$countryid";
                    $stmt = $this->db->prepare($country_sql);            
                    $stmt->execute();
                    $country_data  = $stmt->fetchAll();	
                    $this->tpl->set('country_data', $country_data);

                    //edit option     
                    $this->tpl->set('message', 'You can edit Enquiry form');
                    $this->tpl->set('page_header', 'Production');
                    $this->tpl->set('FmData', $enquiry_data); 
                    
                    $this->tpl->set('content', $this->tpl->fetch('factory/form/enquiry_form.php'));                    
                    break;
                
                case 'editsubmit':             
                    $data = trim($_POST['ycs_ID']);
                    
                    //mode of form submit
                    $this->tpl->set('mode', 'edit');
                    //set id to edit $ycs_ID
                    $this->tpl->set('ycs_ID', $data);

                    //Post data
                    include_once 'util/genUtil.php';
                    $util = new GenUtil();
                    $form_post_data = $util->arrFltr($_POST);

                    //Build SQL now
                     $sqlsel_del = "SELECT RPFIfAny FROM $enquirydetail_tab WHERE enquiry_ID  = '$data'";
                     $stmt = $this->db->prepare($sqlsel_del);
                     $stmt->execute();
                     $resource_data = $stmt->fetchAll();
                     
                     if(!empty($resource_data)){
                          foreach($resource_data as $k=>$v){
                                    if(file_exists($v['RPFIfAny'])){
                                        unlink($v['RPFIfAny']); 
                                    }
                                }
                     }
                                 
                               
                    $sqldet_del = "DELETE FROM $enquirydetail_tab WHERE enquiry_ID=$data";
                    $stmt = $this->db->prepare($sqldet_del);
                    $stmt->execute();   
                            
                            try{
                            
                            $emp_id= $form_post_data['employee_ID'];
                            $enquirymode= $form_post_data['EnquiryMode'];
                            $enq_type= $form_post_data['EnquiryType'];
                            $pdndept_id= $form_post_data['pdndepartment_ID'];
                            $customerid= $form_post_data['customer_ID'];
                            $costreq= $form_post_data['CostRequired'];
                            $orderreceived= $form_post_data['OrderReceived'];
                            $enquirystatus= $form_post_data['EnquiryStatus'];
                            $pono= $form_post_data['PONo'];
                            $pdnstatus= $form_post_data['ProductionStatus'];
                            $remainder_date=date("Y-m-d", strtotime($form_post_data['RemaindDate']));
                            $remainder_time= $form_post_data['RemaindTime'];
                            $remainder_abt= $form_post_data['RemaindAbout'];
                                          
                           
                            $sql_update="Update $enquirymaster_tab SET  employee_ID='$emp_id',
                                                                        EnquiryMode='$enquirymode',
                                                                        EnquiryType='$enq_type',
                                                                        pdndepartment_ID='$pdndept_id',
                                                                        customer_ID='$customerid',
                                                                        CostRequired='$costreq',
                                                                        OrderReceived='$orderreceived',
                                                                        EnquiryStatus='$enquirystatus',
                                                                        PONo='$pono',
                                                                        ProductionStatus='$pdnstatus',
                                                                        RemaindDate='$remainder_date',
                                                                        RemaindTime='$remainder_time',
                                                                        RemaindAbout='$remainder_abt'
                                                                        WHERE ID=$data";
                            $stmt1 = $this->db->prepare($sql_update);
                            $stmt1->execute();
                        if($enq_type==1){
                        $entry_count = 1;
                        FOR ($entry_count; $entry_count <= $form_post_data['maxCount'];) {
                                
                                $productname ='ItemName_' . $entry_count;
                                $quantity ='Quantity_' . $entry_count;
                                $unit_id ='unit_' . $entry_count;
                                $remarks ='Note_' . $entry_count;
                                $rpfany ='Water_' . $entry_count;
                                
                                if(!empty($_FILES[$rpfany]['name'])){
                                     $uploadedfile = $util->custom_file_upload_specific($rpfany, $data,'enquiry');
                                }else{
                                     $uploadedfile ='';
                                }

                                $vals = "'" . $data . "'," .
                                        "'" . $form_post_data[$productname] . "'," .
                                        "'" . $form_post_data[$quantity] . "'," .
                                        "'" . $form_post_data[$unit_id] . "'," .
                                        "'" . $form_post_data[$remarks] . "'," .
                                        "'" . $uploadedfile . "'" ;
  
                                $sql2 = "INSERT INTO $enquirydetail_tab
                                        ( 
                                            `enquiry_ID`, 
                                            `ProductName`,
                                            `Quantity`,
                                            `unit_ID`,
                                            `Remarks`,
                                            `RPFIfAny`
                                        ) 
                                VALUES ($vals)";

                                $stmt = $this->db->prepare($sql2);
                                $stmt->execute();
                            //increment here
                            $entry_count++;
                            }
                        }
                            $this->tpl->set('message', 'Enquiry form edited successfully!');   
                            header('Location:' . $this->crg->get('route')['base_path'] . '/sales/cst/enquiry');
                            // $this->tpl->set('label', 'List');
                            // $this->tpl->set('content', $this->tpl->fetch('factory/template/form_button_link.php'));
                            } catch (Exception $exc) {
                             //edit failed option
                            $this->tpl->set('message', 'Failed to edit, try again!');
                            $this->tpl->set('FmData', $form_post_data);
                            $this->tpl->set('content', $this->tpl->fetch('factory/form/enquiry_form.php'));
                            }

                    break;

                case 'addsubmit':
                     if (isset($crud_string)) {
                         
                        $form_post_data = $dbutil->arrFltr($_POST);
                    
                       // var_dump($_POST);
                        if($form_post_data['customer_ID']==0){
                            
                                if(!empty($form_post_data['Address_type']) && $form_post_data['Address_type']=='same'){
                                    $permnt_addressline1= $form_post_data['BillingAddress1'];
        							$permnt_addressline2= $form_post_data['BillingAddress2'];
        							$permnt_city= $form_post_data['BillingCity'];
        							$permnt_state_id= $form_post_data['BillingState_ID'];
        							$permnt_country_id= $form_post_data['BillingCountry_ID'];
        							$permnt_pincode= $form_post_data['BillingZip'];
                                }else{
                                    $permnt_addressline1='';
        							$permnt_addressline2='';
        							$permnt_city='';
        							$permnt_state_id='';
        							$permnt_country_id='';
        							$permnt_pincode='';
                                }
                    
                                $val =  "'" . $form_post_data['contactperson'] . "'," .
										"'" . $form_post_data['companyname'] . "'," .
										"'" . $form_post_data['BillingAddress1'] . "'," .
										"'" . $form_post_data['BillingAddress2'] . "'," .
										"'" . $form_post_data['BillingCity'] . "'," .
										"'" . $form_post_data['BillingState_ID'] . "'," .
										"'" . $form_post_data['BillingCountry_ID'] . "'," .
										"'" . $form_post_data['BillingZip'] . "'," .
										"'" . $permnt_addressline1 . "'," .
										"'" . $permnt_addressline2 . "'," .
										"'" . $permnt_city . "'," .
										"'" . $permnt_state_id . "'," .
										"'" . $permnt_country_id . "'," .
										"'" . $permnt_pincode . "'," .
										"'" . $form_post_data['MobileNo'] . "'," .
										"'" . $form_post_data['Address_type'] . "'," .
										"'" . $form_post_data['Email'] . "'," .
                                        "'" . $this->ses->get('user')['entity_ID'] . "'," .
                                        "'" . $this->ses->get('user')['ID'] . "'";
                                        
                                $sql = "INSERT INTO `" . $this->crg->get('table_prefix') . "customer`
                                            ( 
                                            `PersonName`,
											`CompanyName`,
											`BillingAddress1`,
											`BillingAddress2`,
											`BillingCity`,
											`BillingState_ID`,
											`BillingCountry_ID`,
											`BillingZip`,
											`PermntAddress1`,
											`PermntAddress2`,
											`PermntCity`,
											`PermntState_ID`,
											`PermntCountry_ID`,
											`PermntZip`,
											`MobileNo`,
											`Address_type`,
											`Email`,
                                            `entity_ID`,
                                            `users_ID`
                                            ) 
                                        VALUES ( $val )";
									   $stmt = $this->db->prepare($sql); 
									
							if ($stmt->execute()) { 
							   $customer_ID = $this->db->lastInsertId();
							}
                        }else{
							$customer_ID = $form_post_data['customer_ID'];		    
						}
                        $entry_count = 1;
                       
                        if (isset($form_post_data['EnquiryType']) && $form_post_data['EnquiryType']=='1') {
                           
                                $val =  "'" . $form_post_data['EnquiryNo'] . "'," .
                                        "'" . $form_post_data['employee_ID'] . "'," .
                                        "'" . $form_post_data['EnquiryMode'] . "'," .
                                        "'" . $form_post_data['EnquiryType'] . "'," .
                                        "'" . $form_post_data['pdndepartment_ID'] . "'," .
                                        "'" . $customer_ID . "'," .
                                        "'" . $form_post_data['CostRequired'] . "'," .
                                        "'" . $form_post_data['OrderReceived'] . "'," .
                                        "'" . $form_post_data['EnquiryStatus'] . "'," .
                                        "'" . $form_post_data['PONo'] . "'," .
                                        "'" . $form_post_data['ProductionStatus'] . "'," .
                                        "'" . date("Y-m-d", strtotime($form_post_data['RemaindDate'])) . "'," .
                                        "'" . $form_post_data['RemaindTime'] . "'," .
                                        "'" . $form_post_data['RemaindAbout'] . "'," .
                                        "'" .  $this->ses->get('user')['entity_ID'] . "'," .
                                        "'" .  $this->ses->get('user')['ID'] . "'";

                                    $sql = "INSERT INTO `" . $this->crg->get('table_prefix') . "enquiry`
                                            ( 
                                            `EnquiryNo`,
                                            `employee_ID`,
                                            `EnquiryMode`,
                                            `EnquiryType`,
                                            `pdndepartment_ID`,
                                            `customer_ID`,
                                            `CostRequired`,
                                            `OrderReceived`,
                                            `EnquiryStatus`,
                                            `PONo`,
                                            `ProductionStatus`,
                                            `RemaindDate`,
                                            `RemaindTime`,
                                            `RemaindAbout`,
                                            `entity_ID`,
                                            `users_ID`
                                            ) 
                                        VALUES ( $val )";
                                    $stmt = $this->db->prepare($sql);
                                  
                                  
                        if ($stmt->execute()) { 
                        $lastInsertedID = $this->db->lastInsertId();
                        FOR ($entry_count; $entry_count <= $form_post_data['maxCount'];) {
                               
                                $productname ='ItemName_' . $entry_count;
                                $quantity ='Quantity_' . $entry_count;
                                $unit_id ='unit_' . $entry_count;
                                $remarks ='Note_' . $entry_count;
                                $rpfany ='Water_' . $entry_count;
                                
                                if(!empty($_FILES[$rpfany]['name'])){
                                    
                                     $uploadedfile = $util->custom_file_upload_specific($rpfany, $lastInsertedID,'enquiry');
                                }else{
                                     $uploadedfile ='';
                                }

                                $vals = "'" . $lastInsertedID . "'," .
                                        "'" . $form_post_data[$productname] . "'," .
                                        "'" . $form_post_data[$quantity] . "'," .
                                        "'" . $form_post_data[$unit_id] . "'," .
                                        "'" . $form_post_data[$remarks] . "'," .
                                        "'" . $uploadedfile . "'" ;
                                 
                                $sql2 = "INSERT INTO $enquirydetail_tab
                                        ( 
                                            `enquiry_ID`, 
                                            `ProductName`,
                                            `Quantity`,
                                            `unit_ID`,
                                            `Remarks`,
                                            `RPFIfAny`
                                        ) 
                                VALUES ($vals)";

                                 // this need to be changed in to transaction type
                                
                                $stmt = $this->db->prepare($sql2);
                                $stmt->execute();
                                  //increment here
                                $entry_count++;
                                
                            }
                        }
                        }else{
                                $val =  "'" . $form_post_data['EnquiryNo'] . "'," .
                                        "'" . $form_post_data['employee_ID'] . "'," .
                                        "'" . $form_post_data['EnquiryMode'] . "'," .
                                        "'" . $form_post_data['EnquiryType'] . "'," .
                                        "'" . $form_post_data['pdndepartment_ID'] . "'," .
                                        "'" . $form_post_data['customer_ID'] . "'," .
                                        "'" . $form_post_data['CostRequired'] . "'," .
                                        "'" . $form_post_data['OrderReceived'] . "'," .
                                        "'" . $form_post_data['EnquiryStatus'] . "'," .
                                        "'" . $form_post_data['PONo'] . "'," .
                                        "'" . $form_post_data['ProductionStatus'] . "'," .
                                        "'" . date("Y-m-d", strtotime($form_post_data['RemaindDate'])) . "'," .
                                        "'" . $form_post_data['RemaindTime'] . "'," .
                                        "'" . $form_post_data['RemaindAbout'] . "'," .
                                        "'" .  $this->ses->get('user')['entity_ID'] . "'," .
                                        "'" .  $this->ses->get('user')['ID'] . "'";

                              $sql = "INSERT INTO `" . $this->crg->get('table_prefix') . "enquiry`
                                            ( 
                                            `EnquiryNo`,
                                            `employee_ID`,
                                            `EnquiryMode`,
                                            `EnquiryType`,
                                            `pdndepartment_ID`,
                                            `customer_ID`,
                                            `CostRequired`,
                                            `OrderReceived`,
                                            `EnquiryStatus`,
                                            `PONo`,
                                            `ProductionStatus`,
                                            `RemaindDate`,
                                            `RemaindTime`,
                                            `RemaindAbout`,
                                            `entity_ID`,
                                            `users_ID`
                                            ) 
                                        VALUES ( $val )";
                                  $stmt = $this->db->prepare($sql);
                                  $stmt->execute();
                        }
                        $this->tpl->set('mode', 'add');
                        $this->tpl->set('message', '- Success -');
                        header('Location:' . $this->crg->get('route')['base_path'] . '/sales/cst/enquiry');
                       // $this->tpl->set('content', $this->tpl->fetch('factory/form/enquiry_form.php'));
                     } else {
                            //edit option
                            //if submit failed to insert form
                            $this->tpl->set('message', 'Failed to submit!');
                            $this->tpl->set('FmData', $form_post_data);
                            $this->tpl->set('content', $this->tpl->fetch('factory/form/enquiry_form.php'));
                     }
                    break;
                case 'add':
                    $this->tpl->set('mode', 'add');
	                $this->tpl->set('page_header', 'Production');
	                $EnquiryNo=$dbutil->keyGeneration('enquiry','ENQ','','EnquiryNo');
                    $this->tpl->set('EnquiryNo', $EnquiryNo);
                    $this->tpl->set('content', $this->tpl->fetch('factory/form/enquiry_form.php'));
                    break;

                default:
                    /*
                     * List form
                     */
                     
                    ////////////////////start//////////////////////////////////////////////
                    
           //bUILD SQL 
            $whereString = '';
            
         $colArr = array(
                "$enquirymaster_tab.ID",
                "$enquirymaster_tab.EnquiryNo",
                "$employee_table.EmpName",
                "$customer_table.PersonName",
                "$pdndept_table.DeptName",
                "$enquirydetail_tab.ProductName",
                "$enquirydetail_tab.Quantity"
            );
            
            $this->tpl->set('FmData', $_POST);
            foreach($_POST as $k=>$v){
                if(strpos($k,'^')){
                    unset($_POST[$k]);
                }
                $_POST[str_replace('^','_',$k)] = $v;
            }
            $PD=$_POST;
            if($_POST['list']!=''){
                $this->tpl->set('FmData', NULL);
                $PD=NULL;
            }

            IF (count($PD) >= 2) {
                $wsarr = array();
                foreach ($colArr as $colNames) {

	            if (strpos($colNames, 'DATE') !== false) {
                    list($colNames,$x) = $dbutil->dateFilterFormat($colNames);                    
                }else {
        		    $x = $dbutil->__mdsf($PD[str_replace('.','_',$colNames)]);        		    
                }

                  if ('' != $x) {
                   $wsarr[] = $colNames . " LIKE '%" . $x . "%'";
                    }
                }
                
           IF (count($wsarr) >= 1) {
                $whereString = ' AND '. implode(' AND ', $wsarr);
            }
           } else {
             $whereString ="ORDER BY $enquirymaster_tab.ID DESC";
           }
           
        $sql = "SELECT "
                    . implode(',',$colArr)
                    . " FROM $enquirymaster_tab 
                             LEFT JOIN $enquirydetail_tab ON $enquirymaster_tab.ID=$enquirydetail_tab.enquiry_ID 
                             LEFT JOIN $pdndept_table ON $enquirymaster_tab.pdndepartment_ID=$pdndept_table.ID 
                             LEFT JOIN $employee_table ON $enquirymaster_tab.employee_ID=$employee_table.ID 
                             LEFT JOIN $customer_table ON $enquirymaster_tab.customer_ID=$customer_table.ID "
                    . " WHERE "
                    . " $enquirymaster_tab.entity_ID = $entityID"
                    . " $whereString";
            
         
    
                $results_per_page = 50;     
            
                if(isset($PD['pageno'])){$page=$PD['pageno'];}
                else if(isset($PD['pagenof'])){$page=$PD['pagenofirst'];}
                else if(isset($PD['pagenop'])){$page=$PD['pagenoprev'];}
                else if(isset($PD['pagenon'])){$page=$PD['pagenonext'];}
                else if(isset($PD['pagenol'])){$page=$PD['pagenolast'];}
                else if(isset($PD['pagenog'])){$page=$PD['pagenogo'];}
                else{$page=1;} 
            /*
             * SET DATA TO TEMPLATE
                        */
           $this->tpl->set('sql_data_rows', $dbutil->setPaginationList($sql,$page,$results_per_page,$wsarr));
         
         
            $this->tpl->set('table_columns_label_arr', array('ID','Enquiry No','Attended By','Contact Person','Production Department','Product Name','Quantity'));
            
            /*
             * selectColArr for filter form
             */
            
            $this->tpl->set('selectColArr',$colArr);
                        
            /*
             * set pagination template
             */
            $this->crg->set('paginationListTemplate','factory/template/sql_based_crud_paginated_table.php');
                   
            //////////////////////close//////////////////////////////////////  
                     
                    include_once $this->tpl->path . '/factory/form/crud_form_enquiry.php';
                    $cus_form_data = Form_Elements::data($this->crg);
                    include_once 'util/crud3_1.php';
                    new Crud3($this->crg, $cus_form_data);
                    break;
            }

	    ///////////////Use different template////////////////////
	    $this->tpl->set('master_layout', 'layout_datepicker.php'); 
////////////////////////////////////////////////////////////////////////////////
//////////////////////////////on access condition failed then //////////////////
//////////////////////////////////////////////////////////////////////////////// 
     } else {
             if ($this->ses->get('user')['ID']) {
                 $this->tpl->set('content', $this->tpl->fetch('modules/user/acess_failed_message.php'));
             } else {
                 header('Location:' . $this->crg->get('route')['base_path'] . '/user/auth/login');
             }
         }
    }
    
////////////////////////////////////////////////////
   
function tender(){
     
        if ($this->crg->get('wp') || $this->crg->get('rp')) {
             
            /////////////////////////////////////////////////////////////////
            //////////////////////////////access condition applied///////////
            /////////////////////////////////////////////////////////////////
            
            include_once 'util/DBUTIL.php';
            $dbutil = new DBUTIL($this->crg);
            
            include_once 'util/genUtil.php';
            $util = new GenUtil();
             
            $entityID = $this->ses->get('user')['entity_ID'];
            $userID = $this->ses->get('user')['ID'];
            
            
            $employee_table = $this->crg->get('table_prefix') . 'employee';
            $pdndept_table = $this->crg->get('table_prefix') . 'pdndepartment';
            $dept_table = $this->crg->get('table_prefix') . 'department';
            $rawmaterial_table = $this->crg->get('table_prefix') . 'rawmaterial';
            $unit_table = $this->crg->get('table_prefix') . 'unit';
			$tendersubdetail_tab = $this->crg->get('table_prefix') . 'tenderremarks';
            $tenderdetail_tab = $this->crg->get('table_prefix') . 'tenderdetail';
            $tendermaster_tab = $this->crg->get('table_prefix') . 'tender';
            $customer_table = $this->crg->get('table_prefix') . 'customer';
            $state_table = $this->crg->get('table_prefix') . 'state';
            $country_table = $this->crg->get('table_prefix') . 'country';
            $enquiry_table = $this->crg->get('table_prefix') . 'enquiry';
          
            // mode of bidding type array
            
            $biddingtype_data = array(array("ID"=>"1","Title"=>"Online"),array("ID"=>"2","Title"=>"Offline"));
            $this->tpl->set('biddingtype_data', $biddingtype_data);
            
            // contracttype_data array
            
            $contracttype_data = array(array("ID"=>"1","Title"=>"Goods"),array("ID"=>"2","Title"=>"Service"));
            $this->tpl->set('contracttype_data', $contracttype_data);
            
            // tendertype_data array
            
            $tendertype_data = array(array("ID"=>"1","Title"=>"Open"),array("ID"=>"2","Title"=>"Limited"),array("ID"=>"3","Title"=>"Special Limited"));
            $this->tpl->set('tendertype_data', $tendertype_data);
            
            // tenderstatus_data array
            
            $tenderstatus_data = array(array("ID"=>"1","Title"=>"Open"),array("ID"=>"2","Title"=>"Bid Submitted"),array("ID"=>"3","Title"=>"Tender Closed"));
            $this->tpl->set('tenderstatus_data', $tenderstatus_data);
            
            // Regular / Developmental data array
            
            $reg_or_dev_data = array(array("ID"=>"1","Title"=>"Regular"),array("ID"=>"2","Title"=>"Developmental"));
            $this->tpl->set('reg_or_dev_data', $reg_or_dev_data);
            
            // procure_from_data array
            
            $procure_from_data = array(array("ID"=>"1","Title"=>"Yes"),array("ID"=>"2","Title"=>"No"));
            $this->tpl->set('procure_from_data', $procure_from_data);
            
            // RA_enabled_data array
            
            $ra_enabled_data = array(array("ID"=>"1","Title"=>"Yes"),array("ID"=>"2","Title"=>"No"));
            $this->tpl->set('ra_enabled_data', $ra_enabled_data);
            
            // bidresult_data array
            
            $bidresult_data = array(array("ID"=>"1","Title"=>"Bid Awarded"),array("ID"=>"2","Title"=>"Bid Not Awarded"));
            $this->tpl->set('bidresult_data', $bidresult_data);
            
            // prebidconference_data array
            
            $prebidconference_data = array(array("ID"=>"1","Title"=>"Yes"),array("ID"=>"2","Title"=>"No"));
            $this->tpl->set('prebidconference_data', $prebidconference_data);
            
            // RA_enabled_data array
            
            $requestforprice_data = array(array("ID"=>"1","Title"=>"Yes"),array("ID"=>"2","Title"=>"No"));
            $this->tpl->set('requestforprice_data', $requestforprice_data);
            
            //unit table data
           
            $pdt_sql = "SELECT ID,UnitName FROM $unit_table";
            $stmt = $this->db->prepare($pdt_sql);            
            $stmt->execute();
            $unit_data  = $stmt->fetchAll();	
            $this->tpl->set('unit_data', $unit_data);
            
            //enquiry table data
           
            $enquiry_sql = "SELECT ID,EnquiryNo FROM $enquiry_table WHERE $enquiry_table.EnquiryType=2";
            $stmt = $this->db->prepare($enquiry_sql);            
            $stmt->execute();
            $enquiry_data  = $stmt->fetchAll();	
            $this->tpl->set('enquiry_data', $enquiry_data);
            
           
            $this->tpl->set('page_title', 'Tender');	          
            $this->tpl->set('page_header', 'Production');
            //Add Role when u submit the add role form
            $thisPageURL = $this->crg->get('route')['base_path'] . '/' . $this->crg->get('route')['module'] . '/' . $this->crg->get('route')['controller'] . '/' . $this->crg->get('route')['action'];

            $crud_string = null;
	
            if (isset($_POST['req_from_list_view'])) {
                $crud_string = strtolower($_POST['req_from_list_view']);
            }              
            
            //Edit submit
            if (!empty($_POST['edit_submit_button']) && $_POST['edit_submit_button'] == 'edit') {
                $crud_string = 'editsubmit';
            }

            //Add submit
            if (!empty($_POST['add_submit_button']) && $_POST['add_submit_button'] == 'add') {
                $crud_string = 'addsubmit';
            }


            switch ($crud_string) {
                 case 'delete':                    
                      $data = trim($_POST['ycs_ID']);
                      // var_dump($data); 
                       
                       
                    if (!$data) {
                        $this->tpl->set('message', 'Please select any one ID to '.$crud_string.'!');
                        $this->tpl->set('label', 'List');
                        $this->tpl->set('content', $this->tpl->fetch('factory/template/form_button_link.php'));
                       
                    }
                     
                     $sqldetdelete="Delete $tenderdetail_tab,$tendermaster_tab from $tendermaster_tab
                                        LEFT JOIN  $tenderdetail_tab ON $tendermaster_tab.ID=$tenderdetail_tab.tender_ID 
                                        where $tenderdetail_tab.tender_ID=$data"; 
                        $stmt = $this->db->prepare($sqldetdelete);            
                        
                        if($stmt->execute()){
                        $this->tpl->set('message', 'Enquiry deleted successfully');
                        header('Location:' . $this->crg->get('route')['base_path'] . '/sales/cst/tender');
                        // $this->tpl->set('label', 'List');
                        // $this->tpl->set('content', $this->tpl->fetch('factory/template/form_button_link.php'));
                        }
            break;
                case 'view':                    
                    $data = trim($_POST['ycs_ID']);
                 
                    if (!$data) {
                        $this->tpl->set('message', 'Please select any one ID to view!');
                        $this->tpl->set('label', 'List');
                        $this->tpl->set('content', $this->tpl->fetch('factory/template/form_button_link.php'));
                        break;
                    }
                    
                    //mode of form submit
                    $this->tpl->set('mode', 'view');
                    //set id to edit $ycs_ID
                    $this->tpl->set('ycs_ID', $data);         
                                
                    $sqlsrr = "SELECT * FROM  `$tendermaster_tab` LEFT JOIN `$tenderdetail_tab` ON  `$tendermaster_tab`.`ID`=`$tenderdetail_tab`.`tender_ID` LEFT JOIN `$customer_table` ON  `$tendermaster_tab`.`customer_ID`=`$customer_table`.`ID` WHERE `$tendermaster_tab`.`ID` = '$data'";                    
                    $tender_data = $dbutil->getSqlData($sqlsrr); 
                    
                    //var_dump($tender_data[0]);
                  
                    //edit option     
                    $this->tpl->set('message', 'You can view Tender form');
                    $this->tpl->set('page_header', 'Production');
                    $this->tpl->set('FmData', $tender_data); 
                    
                    $this->tpl->set('content', $this->tpl->fetch('factory/form/tender_form.php'));                    
                    break;
                
                case 'edit':                    
                    $data = trim($_POST['ycs_ID']);
               // var_dump($data);
                    if (!$data) {
                        $this->tpl->set('message', 'Please select any one ID to edit!');
                        $this->tpl->set('label', 'List');
                        $this->tpl->set('content', $this->tpl->fetch('factory/template/form_button_link.php'));
                        break;
                    }
                    
                    //mode of form submit
                    $this->tpl->set('mode', 'edit');
                    //set id to edit $ycs_ID
                    $this->tpl->set('ycs_ID', $data);         
                                
                    $sqlsrr = "SELECT * FROM  `$tendermaster_tab` LEFT JOIN `$tenderdetail_tab` ON  `$tendermaster_tab`.`ID`=`$tenderdetail_tab`.`tender_ID` LEFT JOIN `$customer_table` ON  `$tendermaster_tab`.`customer_ID`=`$customer_table`.`ID` WHERE `$tendermaster_tab`.`ID` = '$data'";                    
                    $tender_data = $dbutil->getSqlData($sqlsrr); 
                    
                    //var_dump($tender_data[0]);
                    
                    //edit option     
                    $this->tpl->set('message', 'You can edit Tender form');
                    $this->tpl->set('page_header', 'Production');
                    $this->tpl->set('FmData', $tender_data); 
                    
                    $this->tpl->set('content', $this->tpl->fetch('factory/form/tender_form.php'));                    
                    break;
                
                case 'editsubmit':             
                    $data = trim($_POST['ycs_ID']);
                    
                    //mode of form submit
                    $this->tpl->set('mode', 'edit');
                    //set id to edit $ycs_ID
                    $this->tpl->set('ycs_ID', $data);

                    //Post data
                    include_once 'util/genUtil.php';
                    $util = new GenUtil();
                    $form_post_data = $util->arrFltr($_POST);

                    //Build SQL now
                     $sqlsel_del = "SELECT RPFIfAny FROM $tenderdetail_tab WHERE tender_ID  = '$data'";
                     $stmt = $this->db->prepare($sqlsel_del);
                     $stmt->execute();
                     $resource_data = $stmt->fetchAll();
                     
                     if(!empty($resource_data)){
                          foreach($resource_data as $k=>$v){
                                    if(file_exists($v['RPFIfAny'])){
                                        unlink($v['RPFIfAny']); 
                                    }
                                }
                     }
                                 
                               
                    $sqldet_del = "DELETE FROM $tenderdetail_tab WHERE tender_ID=$data";
                    $stmt = $this->db->prepare($sqldet_del);
                    $stmt->execute();   
                            
                            try{
                            
                            $emp_id= $form_post_data['employee_ID'];
                            $tendermode= $form_post_data['EnquiryMode'];
                            $enq_type= $form_post_data['EnquiryType'];
                            $pdndept_id= $form_post_data['pdndepartment_ID'];
                            $customerid= $form_post_data['customer_ID'];
                            $costreq= $form_post_data['CostRequired'];
                            $orderreceived= $form_post_data['OrderReceived'];
                            $tenderstatus= $form_post_data['EnquiryStatus'];
                            $pono= $form_post_data['PONo'];
                            $pdnstatus= $form_post_data['ProductionStatus'];
                            $remainder_date=date("Y-m-d", strtotime($form_post_data['RemaindDate']));
                            $remainder_time= $form_post_data['RemaindTime'];
                            $remainder_abt= $form_post_data['RemaindAbout'];
                                          
                           
                            $sql_update="Update $tendermaster_tab SET  employee_ID='$emp_id',
                                                                        EnquiryMode='$tendermode',
                                                                        EnquiryType='$enq_type',
                                                                        pdndepartment_ID='$pdndept_id',
                                                                        customer_ID='$customerid',
                                                                        CostRequired='$costreq',
                                                                        OrderReceived='$orderreceived',
                                                                        EnquiryStatus='$tenderstatus',
                                                                        PONo='$pono',
                                                                        ProductionStatus='$pdnstatus',
                                                                        RemaindDate='$remainder_date',
                                                                        RemaindTime='$remainder_time',
                                                                        RemaindAbout='$remainder_abt'
                                                                        WHERE ID=$data";
                            $stmt1 = $this->db->prepare($sql_update);
                            $stmt1->execute();
                        if($enq_type==1){
                        $entry_count = 1;
                        FOR ($entry_count; $entry_count <= $form_post_data['maxCount'];) {
                                
                                $productname ='ItemName_' . $entry_count;
                                $quantity ='Quantity_' . $entry_count;
                                $unit_id ='unit_' . $entry_count;
                                $remarks ='Note_' . $entry_count;
                                $rpfany ='Water_' . $entry_count;
                                
                                if(!empty($_FILES[$rpfany]['name'])){
                                     $uploadedfile = $util->custom_file_upload_specific($rpfany, $data,'tender');
                                }else{
                                     $uploadedfile ='';
                                }

                                $vals = "'" . $data . "'," .
                                        "'" . $form_post_data[$productname] . "'," .
                                        "'" . $form_post_data[$quantity] . "'," .
                                        "'" . $form_post_data[$unit_id] . "'," .
                                        "'" . $form_post_data[$remarks] . "'," .
                                        "'" . $uploadedfile . "'" ;
  
                                $sql2 = "INSERT INTO $tenderdetail_tab
                                        ( 
                                            `tender_ID`, 
                                            `ProductName`,
                                            `Quantity`,
                                            `unit_ID`,
                                            `Remarks`,
                                            `RPFIfAny`
                                        ) 
                                VALUES ($vals)";

                                $stmt = $this->db->prepare($sql2);
                                $stmt->execute();
                            //increment here
                            $entry_count++;
                            }
                        }
                            $this->tpl->set('message', 'Tender form edited successfully!');   
                            header('Location:' . $this->crg->get('route')['base_path'] . '/sales/cst/tender');
                            // $this->tpl->set('label', 'List');
                            // $this->tpl->set('content', $this->tpl->fetch('factory/template/form_button_link.php'));
                            } catch (Exception $exc) {
                             //edit failed option
                            $this->tpl->set('message', 'Failed to edit, try again!');
                            $this->tpl->set('FmData', $form_post_data);
                            $this->tpl->set('content', $this->tpl->fetch('factory/form/tender_form.php'));
                            }

                    break;

                case 'addsubmit':
                     if (isset($crud_string)) {
                         
                        $form_post_data = $dbutil->arrFltr($_POST);
                    
                       // var_dump($_POST);

                        $entry_count = 1;
                       
                        if (isset($form_post_data['EnquiryType']) && $form_post_data['EnquiryType']=='1') {
                           
                                $val =  "'" . $form_post_data['EnquiryNo'] . "'," .
                                        "'" . $form_post_data['employee_ID'] . "'," .
                                        "'" . $form_post_data['EnquiryMode'] . "'," .
                                        "'" . $form_post_data['EnquiryType'] . "'," .
                                        "'" . $form_post_data['pdndepartment_ID'] . "'," .
                                        "'" . $customer_ID . "'," .
                                        "'" . $form_post_data['CostRequired'] . "'," .
                                        "'" . $form_post_data['OrderReceived'] . "'," .
                                        "'" . $form_post_data['EnquiryStatus'] . "'," .
                                        "'" . $form_post_data['PONo'] . "'," .
                                        "'" . $form_post_data['ProductionStatus'] . "'," .
                                        "'" . date("Y-m-d", strtotime($form_post_data['RemaindDate'])) . "'," .
                                        "'" . $form_post_data['RemaindTime'] . "'," .
                                        "'" . $form_post_data['RemaindAbout'] . "'," .
                                        "'" .  $this->ses->get('user')['entity_ID'] . "'," .
                                        "'" .  $this->ses->get('user')['ID'] . "'";

                                    $sql = "INSERT INTO `" . $this->crg->get('table_prefix') . "tender`
                                            ( 
                                            `EnquiryNo`,
                                            `employee_ID`,
                                            `EnquiryMode`,
                                            `EnquiryType`,
                                            `pdndepartment_ID`,
                                            `customer_ID`,
                                            `CostRequired`,
                                            `OrderReceived`,
                                            `EnquiryStatus`,
                                            `PONo`,
                                            `ProductionStatus`,
                                            `RemaindDate`,
                                            `RemaindTime`,
                                            `RemaindAbout`,
                                            `entity_ID`,
                                            `users_ID`
                                            ) 
                                        VALUES ( $val )";
                                    $stmt = $this->db->prepare($sql);
                                  
                                  
                        if ($stmt->execute()) { 
                        $lastInsertedID = $this->db->lastInsertId();
                        FOR ($entry_count; $entry_count <= $form_post_data['maxCount'];) {
                               
                                $productname ='ItemName_' . $entry_count;
                                $quantity ='Quantity_' . $entry_count;
                                $unit_id ='unit_' . $entry_count;
                                $remarks ='Note_' . $entry_count;
                                $rpfany ='Water_' . $entry_count;
                                
                                if(!empty($_FILES[$rpfany]['name'])){
                                    
                                     $uploadedfile = $util->custom_file_upload_specific($rpfany, $lastInsertedID,'tender');
                                }else{
                                     $uploadedfile ='';
                                }

                                $vals = "'" . $lastInsertedID . "'," .
                                        "'" . $form_post_data[$productname] . "'," .
                                        "'" . $form_post_data[$quantity] . "'," .
                                        "'" . $form_post_data[$unit_id] . "'," .
                                        "'" . $form_post_data[$remarks] . "'," .
                                        "'" . $uploadedfile . "'" ;
                                 
                                $sql2 = "INSERT INTO $tenderdetail_tab
                                        ( 
                                            `tender_ID`, 
                                            `ProductName`,
                                            `Quantity`,
                                            `unit_ID`,
                                            `Remarks`,
                                            `RPFIfAny`
                                        ) 
                                VALUES ($vals)";

                                 // this need to be changed in to transaction type
                                
                                $stmt = $this->db->prepare($sql2);
                                $stmt->execute();
                                  //increment here
                                $entry_count++;
                                
                            }
                        }
                        }else{
                                $val =  "'" . $form_post_data['EnquiryNo'] . "'," .
                                        "'" . $form_post_data['employee_ID'] . "'," .
                                        "'" . $form_post_data['EnquiryMode'] . "'," .
                                        "'" . $form_post_data['EnquiryType'] . "'," .
                                        "'" . $form_post_data['pdndepartment_ID'] . "'," .
                                        "'" . $form_post_data['customer_ID'] . "'," .
                                        "'" . $form_post_data['CostRequired'] . "'," .
                                        "'" . $form_post_data['OrderReceived'] . "'," .
                                        "'" . $form_post_data['EnquiryStatus'] . "'," .
                                        "'" . $form_post_data['PONo'] . "'," .
                                        "'" . $form_post_data['ProductionStatus'] . "'," .
                                        "'" . date("Y-m-d", strtotime($form_post_data['RemaindDate'])) . "'," .
                                        "'" . $form_post_data['RemaindTime'] . "'," .
                                        "'" . $form_post_data['RemaindAbout'] . "'," .
                                        "'" .  $this->ses->get('user')['entity_ID'] . "'," .
                                        "'" .  $this->ses->get('user')['ID'] . "'";

                              $sql = "INSERT INTO `" . $this->crg->get('table_prefix') . "tender`
                                            ( 
                                            `EnquiryNo`,
                                            `employee_ID`,
                                            `EnquiryMode`,
                                            `EnquiryType`,
                                            `pdndepartment_ID`,
                                            `customer_ID`,
                                            `CostRequired`,
                                            `OrderReceived`,
                                            `EnquiryStatus`,
                                            `PONo`,
                                            `ProductionStatus`,
                                            `RemaindDate`,
                                            `RemaindTime`,
                                            `RemaindAbout`,
                                            `entity_ID`,
                                            `users_ID`
                                            ) 
                                        VALUES ( $val )";
                                  $stmt = $this->db->prepare($sql);
                                  $stmt->execute();
                        }
                        $this->tpl->set('mode', 'add');
                        $this->tpl->set('message', '- Success -');
                        header('Location:' . $this->crg->get('route')['base_path'] . '/sales/cst/tender');
                       // $this->tpl->set('content', $this->tpl->fetch('factory/form/tender_form.php'));
                     } else {
                            //edit option
                            //if submit failed to insert form
                            $this->tpl->set('message', 'Failed to submit!');
                            $this->tpl->set('FmData', $form_post_data);
                            $this->tpl->set('content', $this->tpl->fetch('factory/form/tender_form.php'));
                     }
                    break;
                case 'add':
                    $this->tpl->set('mode', 'add');
	                $this->tpl->set('page_header', 'Production');
	                $TenderNo=$dbutil->keyGeneration('tender','TND','','TenderNo');
                    $this->tpl->set('TenderNo', $TenderNo);
                    $this->tpl->set('content', $this->tpl->fetch('factory/form/tender_form.php'));
                    break;

                default:
                    /*
                     * List form
                     */
                     
                    ////////////////////start//////////////////////////////////////////////
                    
           //bUILD SQL 
            $whereString = '';
            
         $colArr = array(
                "$tendermaster_tab.ID",
                "$tendermaster_tab.EnquiryNo",
                "$employee_table.EmpName",
                "$customer_table.PersonName",
                "$pdndept_table.DeptName"
            );
            
            $this->tpl->set('FmData', $_POST);
            foreach($_POST as $k=>$v){
                if(strpos($k,'^')){
                    unset($_POST[$k]);
                }
                $_POST[str_replace('^','_',$k)] = $v;
            }
            $PD=$_POST;
            if($_POST['list']!=''){
                $this->tpl->set('FmData', NULL);
                $PD=NULL;
            }

            IF (count($PD) >= 2) {
                $wsarr = array();
                foreach ($colArr as $colNames) {

	            if (strpos($colNames, 'DATE') !== false) {
                    list($colNames,$x) = $dbutil->dateFilterFormat($colNames);                    
                }else {
        		    $x = $dbutil->__mdsf($PD[str_replace('.','_',$colNames)]);        		    
                }

                  if ('' != $x) {
                   $wsarr[] = $colNames . " LIKE '%" . $x . "%'";
                    }
                }
                
           IF (count($wsarr) >= 1) {
                $whereString = ' AND '. implode(' AND ', $wsarr);
            }
           } else {
             $whereString ="ORDER BY $tendermaster_tab.ID DESC";
           }
           
        $sql = "SELECT "
                    . implode(',',$colArr)
                    . " FROM $tendermaster_tab LEFT JOIN $pdndept_table ON $tendermaster_tab.pdndepartment_ID=$pdndept_table.ID LEFT JOIN $employee_table ON $tendermaster_tab.employee_ID=$employee_table.ID LEFT JOIN $customer_table ON $tendermaster_tab.customer_ID=$customer_table.ID "
                    . " WHERE "
                    . " $tendermaster_tab.entity_ID = $entityID"
                    . " $whereString";
            
         
    
                $results_per_page = 50;     
            
                if(isset($PD['pageno'])){$page=$PD['pageno'];}
                else if(isset($PD['pagenof'])){$page=$PD['pagenofirst'];}
                else if(isset($PD['pagenop'])){$page=$PD['pagenoprev'];}
                else if(isset($PD['pagenon'])){$page=$PD['pagenonext'];}
                else if(isset($PD['pagenol'])){$page=$PD['pagenolast'];}
                else if(isset($PD['pagenog'])){$page=$PD['pagenogo'];}
                else{$page=1;} 
            /*
             * SET DATA TO TEMPLATE
                        */
           $this->tpl->set('sql_data_rows', $dbutil->setPaginationList($sql,$page,$results_per_page,$wsarr));
         
         
            $this->tpl->set('table_columns_label_arr', array('ID','Tender No','Attended By','Contact Person','Production Department'));
            
            /*
             * selectColArr for filter form
             */
            
            $this->tpl->set('selectColArr',$colArr);
                        
            /*
             * set pagination template
             */
            $this->crg->set('paginationListTemplate','factory/template/sql_based_crud_paginated_table.php');
                   
            //////////////////////close//////////////////////////////////////  
                     
                    include_once $this->tpl->path . '/factory/form/crud_form_tender.php';
                    $cus_form_data = Form_Elements::data($this->crg);
                    include_once 'util/crud3_1.php';
                    new Crud3($this->crg, $cus_form_data);
                    break;
            }

	    ///////////////Use different template////////////////////
	    $this->tpl->set('master_layout', 'layout_datepicker.php'); 
////////////////////////////////////////////////////////////////////////////////
//////////////////////////////on access condition failed then //////////////////
//////////////////////////////////////////////////////////////////////////////// 
     } else {
             if ($this->ses->get('user')['ID']) {
                 $this->tpl->set('content', $this->tpl->fetch('modules/user/acess_failed_message.php'));
             } else {
                 header('Location:' . $this->crg->get('route')['base_path'] . '/user/auth/login');
             }
         }
    }
    
   
////////////////////////////////////////////////////
}

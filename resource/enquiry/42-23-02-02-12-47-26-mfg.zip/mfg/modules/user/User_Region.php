<?php

/**
 * Description of Customer_Mod
 *
 * @author psmahadevan
 */
class User_Region {

    private $crg;
    private $ses;
    private $db;
    private $sd;
    private $tpl;
    private $rbac;

    public function __construct($reg = NULL) {
        /*
         * Receiving $rg array
         */
        $this->crg = $reg;

        /*
         * geting object from reg array
         */
        $this->ses = $this->crg->get('ses');
        $this->db = $this->crg->get('db');
        $this->sd = $this->crg->get('SD');
        $this->tpl = $this->crg->get('tpl');
        $this->rbac = $this->crg->get('rbac');
    }    
    
    
//     function mailbox() {
//          if ($this->crg->get('wp') || $this->crg->get('rp')) {

// //////////////////////////////////////////////////////////////////////////////////
// //////////////////////////////access condition applied///////////////////////////
// ////////////////////////////////////////////////////////////////////////////////  
            
//             include_once 'util/DBUTIL.php';
//             $dbutil = new DBUTIL($this->crg);

//             $crud_string = null;
	
//             if (isset($_POST['Action'])) {
//                 $crud_string = strtolower($_POST['Action']);
//             } 
            
//              switch ($crud_string) {
//                 case 'approve': 
                           
//                     $rawmaterial_table = $this->crg->get('table_prefix') . 'rawmaterial';   
//                     $matreqdetail_tab = $this->crg->get('table_prefix') . 'MaterialRequestDetail';
//                     $matreqmaster_tab = $this->crg->get('table_prefix') . 'MaterialRequestMaster';
                    
                  
//                     //rawmaterial select box data
                    
//                     $sql = "SELECT ID,RMName FROM $rawmaterial_table"; 
//                     $stmt = $this->db->prepare($sql);            
//                     $stmt->execute();
//                     $rawmaterial_data  = $stmt->fetchAll();	
//                     $this->tpl->set('rawmaterial_data', $rawmaterial_data);
        
//                     $this->tpl->set('page_title', 'Material Request');	          
//                     $this->tpl->set('page_header', 'Production');
//                     //Add Role when u submit the add role form
//                     $thisPageURL = $this->crg->get('route')['base_path'] . '/' . $this->crg->get('route')['module'] . '/' . $this->crg->get('route')['controller'] . '/' . $this->crg->get('route')['action'];

//                     $data = trim($_POST['process_ID']);
                 
                    
                    
//                     //mode of form submit
//                     $this->tpl->set('mode', 'edit');
//                     //set id to edit $ycs_ID
//                     $this->tpl->set('ycs_ID', $data);         
                                
//                       $sqlsrr = "SELECT * FROM `$matreqdetail_tab`,`$matreqmaster_tab` WHERE `$matreqdetail_tab`.`materialissue_ID`=`$matreqmaster_tab`.`ID` AND `$matreqdetail_tab`.`materialissue_ID` = '$data'";                    
                  
//                       $matreqdetail_data = $dbutil->getSqlData($sqlsrr);
                        
                  
//                     //edit option     
//                     $this->tpl->set('message', 'You can edit Material Request form');
//                     $this->tpl->set('page_header', 'Production');
//                     $this->tpl->set('FmData', $matreqdetail_data); 
                    
                    
//                      $_SESSION['req_from_list_view']='edit';
//                      $_SESSION['ycs_ID']=$data;
//                      header('Location:' . $this->crg->get('route')['base_path'] . '/product/mat/materialrequest');
//                      $this->tpl->set('master_layout', 'layout_datepicker.php');
//                       // $this->tpl->set('content', $this->tpl->fetch('factory/form/MaterialRequest_form.php')); 
//                     break;
//                     default :
//                         // print_r($this->ses->get('user'));
                      
//                         $user_tab = $this->crg->get('table_prefix') . 'users'; 
//                          $appprocess_tab = $this->crg->get('table_prefix') . 'approvalprocess'; 
//                         $entityID = $this->ses->get('user')['entity_ID'];
                      
            	        
//             	        $sqlinbox =  "SELECT s.user_nicename as SendToUser,f.user_nicename as SendFrmUser,a.ProcessType,a.process_ID,CONCAT(if( "
//                                         ."TIMESTAMPDIFF(day,a.AuditDateTime,NOW())=0,'',concat(TIMESTAMPDIFF(day,a.AuditDateTime,NOW()),' days ')) , "
//                                         ."if(MOD( TIMESTAMPDIFF(hour,a.AuditDateTime,NOW()), 24)=0,'',concat(MOD( TIMESTAMPDIFF(hour,a.AuditDateTime,NOW()), 24), ' hours ')),"
//                                         ."MOD( TIMESTAMPDIFF(minute,a.AuditDateTime,NOW()), 60), ' minutes '"
//                                         .") as age FROM $appprocess_tab a JOIN $user_tab s ON s.ID = a.sendfromUser_ID JOIN $user_tab f ON f.ID = a.sendtoUser_ID where a.ApprovalStatus=0";
//                         $sqlinboxdata = $dbutil->getSqlData($sqlinbox,2); 
//                         $this->tpl->set('sqlinbox_data', $sqlinboxdata);
            	        
                      
                    
//                         $this->tpl->set('content', $this->tpl->fetch('factory/mailbox.php'));
            
            
            
//                 }
//                             //////////////////////////////on access condition failed then ///////////////////////////
//                         } else {
//                             if ($this->ses->get('user')['ID']) {
//                                 $this->tpl->set('content', $this->tpl->fetch('modules/user/acess_failed_message.php'));
//                             } else {
//                                 header('Location:' . $this->crg->get('route')['base_path'] . '/user/auth/login');
//                             }
//                         }
//                     }
                    
//  commented by 10.03.2020         function mailbox() {
//          if ($this->crg->get('wp') || $this->crg->get('rp')) {

// //////////////////////////////////////////////////////////////////////////////////
// //////////////////////////////access condition applied///////////////////////////
// ////////////////////////////////////////////////////////////////////////////////  
            
//             include_once 'util/DBUTIL.php';
//             $dbutil = new DBUTIL($this->crg);

//             $crud_string = null;
            
        
	
//             if (isset($_POST['Action'])) {
//                 $crud_string = strtolower($_POST['Action']);
                   
//             } 
            
//              switch ($crud_string) {
             
//                 case 'approve': 
                       
//                         // $approvaltype_tab = $this->crg->get('table_prefix') . 'approvalprocess';
//                         // $sql = "SELECT process_ID FROM $approvaltype_tab where  $approvaltype_tab.ProcessType='Material Request"; 
//                         // $stmt = $this->db->prepare($sql);            
//                         // $stmt->execute();
//                         // $approvaltype_data = $stmt->fetchAll();	
                        
//                         //$approve=$approvaltype_data;
                      
            
           
                    
//                     $rawmaterial_table = $this->crg->get('table_prefix') . 'rawmaterial';   
//                     $matreqdetail_tab = $this->crg->get('table_prefix') . 'MaterialRequestDetail';
//                     $matreqmaster_tab = $this->crg->get('table_prefix') . 'MaterialRequestMaster';
                    
                  
//                     //rawmaterial select box data
                    
//                     $sql = "SELECT ID,RMName FROM $rawmaterial_table"; 
//                     $stmt = $this->db->prepare($sql);            
//                     $stmt->execute();
//                     $rawmaterial_data  = $stmt->fetchAll();	
//                     $this->tpl->set('rawmaterial_data', $rawmaterial_data);
        
//                     $this->tpl->set('page_title', 'Material Request');	          
//                     $this->tpl->set('page_header', 'Production');
//                     //Add Role when u submit the add role form
//                     $thisPageURL = $this->crg->get('route')['base_path'] . '/' . $this->crg->get('route')['module'] . '/' . $this->crg->get('route')['controller'] . '/' . $this->crg->get('route')['action'];

//                     $data = trim($_POST['process_ID']);
                    
//                      $ProcessType = trim($_POST['ProcessType']);
                     
//                      if($ProcessType=='Material Request'){
                 
//                     var_dump($_POST);
//                     //mode of form submit
//                     $this->tpl->set('mode', 'edit');
//                     //set id to edit $ycs_ID
//                     $this->tpl->set('ycs_ID', $data);         
                                
//                       $sqlsrr = "SELECT * FROM `$matreqdetail_tab`,`$matreqmaster_tab` WHERE `$matreqdetail_tab`.`materialrequest_ID`=`$matreqmaster_tab`.`ID` AND `$matreqdetail_tab`.`materialrequest_ID` = '$data'";                    
                  
//                       $matreqdetail_data = $dbutil->getSqlData($sqlsrr);
                        
                  
//                     //edit option     
//                     $this->tpl->set('message', 'You can edit Material Request form');
//                     $this->tpl->set('page_header', 'Production');
//                     $this->tpl->set('FmData', $matreqdetail_data); 
                    
                    
//                      $_SESSION['req_from_list_view']='edit';
//                      $_SESSION['ycs_ID']=$data;
//                      header('Location:' . $this->crg->get('route')['base_path'] . '/product/mat/materialrequest');
//                      $this->tpl->set('master_layout', 'layout_datepicker.php');
//                       // $this->tpl->set('content', $this->tpl->fetch('factory/form/MaterialRequest_form.php')); 
                  
//                      }
//                      elseif($ProcessType=='Purchase Order'){
//                           $pom_tab = $this->crg->get('table_prefix') . 'purchaseorder';
//                     $pod_tab = $this->crg->get('table_prefix') . 'purchaseorderdetail';
                    
        
//                     $this->tpl->set('page_title', 'Purchase Order');	          
//                     $this->tpl->set('page_header', 'Production');
//                     //Add Role when u submit the add role form
//                     $thisPageURL = $this->crg->get('route')['base_path'] . '/' . $this->crg->get('route')['module'] . '/' . $this->crg->get('route')['controller'] . '/' . $this->crg->get('route')['action'];

//                     $data = trim($_POST['process_ID']);
   
                   
//                     //mode of form submit
//                     $this->tpl->set('mode', 'edit');
//                     //set id to edit $ycs_ID
//                     $this->tpl->set('ycs_ID', $data);         
                                
//                       $sqlsrr = "SELECT * FROM `$pod_tab`,`$pom_tab` WHERE `$pod_tab`.`purchaseorder_ID`=`$pom_tab`.`ID` AND `$pod_tab`.`purchaseorder_ID` = '$data'";                    
                  
//                       $pomdetail_data = $dbutil->getSqlData($sqlsrr);
                        
                  
//                     //edit option     
//                     $this->tpl->set('message', 'You can edit Purchase Order form');
//                     $this->tpl->set('page_header', 'Production');
//                     $this->tpl->set('FmData', $pomdetail_data); 
                    
                    
//                      $_SESSION['req_from_list_view']='edit';
//                      $_SESSION['ycs_ID']=$data;
//                      header('Location:' . $this->crg->get('route')['base_path'] . '/purchase/pur/order');
//                      $this->tpl->set('master_layout', 'layout_datepicker.php');
//                       // $this->tpl->set('content', $this->tpl->fetch('factory/form/MaterialRequest_form.php')); 
//                      }
                     
               
//                      elseif($ProcessType=='Pipe Production'){
//                           $pipe_tab = $this->crg->get('table_prefix') . 'pipeproduction';
//                           $pipeprod_tab = $this->crg->get('table_prefix') . 'productionbreakdowndet';
//                           $pipeprodraw_tab = $this->crg->get('table_prefix') . 'pprawmaterialdet';
        
//                     $this->tpl->set('page_title', 'Pipe Production');	          
//                     $this->tpl->set('page_header', 'Production');
//                     //Add Role when u submit the add role form
//                     $thisPageURL = $this->crg->get('route')['base_path'] . '/' . $this->crg->get('route')['module'] . '/' . $this->crg->get('route')['controller'] . '/' . $this->crg->get('route')['action'];

//                     $data = trim($_POST['process_ID']);
   
                   
//                     //mode of form submit
//                     $this->tpl->set('mode', 'edit');
//                     //set id to edit $ycs_ID
//                     $this->tpl->set('ycs_ID', $data);         
                                
//                       $sqlsrr = "SELECT * FROM `$pipe_tab`,`$pipeprod_tab`,`$pipeprodraw_tab` WHERE `$pipeprod_tab`.`pipeproduction_ID`=`$pipe_tab`.`ID` AND `$pipeprodraw_tab`.`pipeproduction_ID`=`$pipe_tab`.`ID` AND `$pipe_tab`.`ID` = '$data'";                    
                  
//                       $pipedetail_data = $dbutil->getSqlData($sqlsrr);
                        
                  
//                     //edit option     
//                     $this->tpl->set('message', 'You can edit Pipe Production form');
//                     $this->tpl->set('page_header', 'Production');
//                     $this->tpl->set('FmData', $pipedetail_data); 
                    
                    
//                      $_SESSION['req_from_list_view']='edit';
//                      $_SESSION['ycs_ID']=$data;
//                      header('Location:' . $this->crg->get('route')['base_path'] . '/product/cst/pipe');
//                      $this->tpl->set('master_layout', 'layout_datepicker.php');
//                       // $this->tpl->set('content', $this->tpl->fetch('factory/form/MaterialRequest_form.php')); 
//                      }
//                      elseif($ProcessType=='Inspection Approval'){
//                           $inspmast_tab = $this->crg->get('table_prefix') . 'onlineinspmaster';
//                           $inspdet_tab = $this->crg->get('table_prefix') . 'onlineinspdet';
//                           $inspsubdet_tab = $this->crg->get('table_prefix') . 'onlineinspsubdet';
//                           $inspprobdet_tab = $this->crg->get('table_prefix') . 'onlineinspprobdet';
        
        
//                     $this->tpl->set('page_title', 'Online Inspection');	          
//                     $this->tpl->set('page_header', 'Production');
//                     //Add Role when u submit the add role form
//                     $thisPageURL = $this->crg->get('route')['base_path'] . '/' . $this->crg->get('route')['module'] . '/' . $this->crg->get('route')['controller'] . '/' . $this->crg->get('route')['action'];

//                     $data = trim($_POST['process_ID']);
   
                   
//                     //mode of form submit
//                     $this->tpl->set('mode', 'edit');
//                     //set id to edit $ycs_ID
//                     $this->tpl->set('ycs_ID', $data);         
                                
//                       $sqlsrr = "SELECT * FROM `$inspmast_tab`,`$inspdet_tab`,`$inspsubdet_tab`,`$inspprobdet_tab` WHERE `$inspdet_tab`.`onlineinspmaster_ID`=`$inspmast_tab`.`ID` AND `$inspsubdet_tab`.`onlineinspmaster_ID`=`$inspmast_tab`.`ID` AND `$inspprobdet_tab`.`onlineinspmaster_ID`=`$inspmast_tab`.`ID` AND `$inspmast_tab`.`ID` = '$data'";                    
                  
//                       $inspdetail_data = $dbutil->getSqlData($sqlsrr);
                        
                  
//                     //edit option     
//                     $this->tpl->set('message', 'You can edit Online Inspection form');
//                     $this->tpl->set('page_header', 'Production');
//                     $this->tpl->set('FmData', $inspdetail_data); 
                    
                    
//                      $_SESSION['req_from_list_view']='edit';
//                      $_SESSION['ycs_ID']=$data;
//                      header('Location:' . $this->crg->get('route')['base_path'] . '/product/cst/oie');
//                      $this->tpl->set('master_layout', 'layout_datepicker.php');
//                       // $this->tpl->set('content', $this->tpl->fetch('factory/form/MaterialRequest_form.php')); 
//                      }
                     
//                       elseif($ProcessType=='Why-Why Analysis'){
//                           $whymast_tab = $this->crg->get('table_prefix') . 'whywhy ';
//                           $whydet_tab = $this->crg->get('table_prefix') . 'whywhydet ';
                         
        
        
//                     $this->tpl->set('page_title', 'Why-Why Analysis');	          
//                     $this->tpl->set('page_header', 'Production');
//                     //Add Role when u submit the add role form
//                     $thisPageURL = $this->crg->get('route')['base_path'] . '/' . $this->crg->get('route')['module'] . '/' . $this->crg->get('route')['controller'] . '/' . $this->crg->get('route')['action'];

//                     $data = trim($_POST['process_ID']);
   
                   
//                     //mode of form submit
//                     $this->tpl->set('mode', 'edit');
//                     //set id to edit $ycs_ID
//                     $this->tpl->set('ycs_ID', $data);         
                                
//                       $sqlsrr = "SELECT * FROM `$whymast_tab`,`$whydet_tab` WHERE `$whydet_tab`.`whywhy_ID`=`$whymast_tab`.`ID` AND  `$whydet_tab`.`whywhy_ID` = '$data'";                    
                  
//                       $whydetail_data = $dbutil->getSqlData($sqlsrr);
                        
                  
//                     //edit option     
//                     $this->tpl->set('message', 'You can edit Why-Why Analysis form');
//                     $this->tpl->set('page_header', 'Production');
//                     $this->tpl->set('FmData', $whydetail_data); 
                    
                    
//                      $_SESSION['req_from_list_view']='edit';
//                      $_SESSION['ycs_ID']=$data;
//                      header('Location:' . $this->crg->get('route')['base_path'] . '/admin/mast/why');
//                      $this->tpl->set('master_layout', 'layout_datepicker.php');
//                       // $this->tpl->set('content', $this->tpl->fetch('factory/form/MaterialRequest_form.php')); 
//                      }
                     
//                   break;
                    
                    
                     
//                     // $pom_tab = $this->crg->get('table_prefix') . 'purchaseorder';
//                     // $pod_tab = $this->crg->get('table_prefix') . 'purchaseorderdetail';
                    
        
//                     // $this->tpl->set('page_title', 'Purchase Order');	          
//                     // $this->tpl->set('page_header', 'Production');
//                     // //Add Role when u submit the add role form
//                     // $thisPageURL = $this->crg->get('route')['base_path'] . '/' . $this->crg->get('route')['module'] . '/' . $this->crg->get('route')['controller'] . '/' . $this->crg->get('route')['action'];

//                      //$data = trim($_POST['process_ID']);
//   // var_dump($data);
                    
//                     // //mode of form submit
//                     // $this->tpl->set('mode', 'edit');
//                     // //set id to edit $ycs_ID
//                     // $this->tpl->set('ycs_ID', $data);         
                                
//                     //   $sqlsrr = "SELECT * FROM `$pod_tab`,`$pom_tab` WHERE `$pod_tab`.`purchaseorder_ID`=`$pom_tab`.`ID` AND `$pod_tab`.`purchaseorder_ID` = '$data'";                    
                  
//                     //   $pomdetail_data = $dbutil->getSqlData($sqlsrr);
                        
                  
//                     // //edit option     
//                     // $this->tpl->set('message', 'You can edit Purchase Order form');
//                     // $this->tpl->set('page_header', 'Production');
//                     // $this->tpl->set('FmData', $pomdetail_data); 
                    
                    
//                     //  $_SESSION['req_from_list_view']='edit';
//                     //  $_SESSION['ycs_ID']=$data;
//                     //  header('Location:' . $this->crg->get('route')['base_path'] . '/purchase/pur/order');
//                     //  $this->tpl->set('master_layout', 'layout_datepicker.php');
//                     //   // $this->tpl->set('content', $this->tpl->fetch('factory/form/MaterialRequest_form.php')); 
//                     // break;
                    
//                     default :
//                         // print_r($this->ses->get('user'));
                      
//                         $user_tab = $this->crg->get('table_prefix') . 'users'; 
//                         $appprocess_tab = $this->crg->get('table_prefix') . 'approvalprocess'; 
//                         $entityID = $this->ses->get('user')['entity_ID'];
                      
            	        
//             	        $sqlinbox =  "SELECT s.user_nicename as SendToUser,f.user_nicename as SendFrmUser,a.ProcessType,a.process_ID,CONCAT(if( "
//                                         ."TIMESTAMPDIFF(day,a.AuditDateTime,NOW())=0,'',concat(TIMESTAMPDIFF(day,a.AuditDateTime,NOW()),' days ')) , "
//                                         ."if(MOD( TIMESTAMPDIFF(hour,a.AuditDateTime,NOW()), 24)=0,'',concat(MOD( TIMESTAMPDIFF(hour,a.AuditDateTime,NOW()), 24), ' hours ')),"
//                                         ."MOD( TIMESTAMPDIFF(minute,a.AuditDateTime,NOW()), 60), ' minutes '"
//                                         .") as age FROM $appprocess_tab a JOIN $user_tab s ON s.ID = a.sendfromUser_ID JOIN $user_tab f ON f.ID = a.sendtoUser_ID where a.ApprovalStatus=0";
//                         $sqlinboxdata = $dbutil->getSqlData($sqlinbox,2); 
//                         $this->tpl->set('sqlinbox_data', $sqlinboxdata);
            	        
                      
                    
//                         $this->tpl->set('content', $this->tpl->fetch('factory/mailbox.php'));
            
            
            
//                 }
//                             //////////////////////////////on access condition failed then ///////////////////////////
//                         } else {
//                             if ($this->ses->get('user')['ID']) {
//                                 $this->tpl->set('content', $this->tpl->fetch('modules/user/acess_failed_message.php'));
//                             } else {
//                                 header('Location:' . $this->crg->get('route')['base_path'] . '/user/auth/login');
//                             }
//                         }
//                     }     


 function mailbox() {
         if ($this->crg->get('wp') || $this->crg->get('rp')) {

//////////////////////////////////////////////////////////////////////////////////
//////////////////////////////access condition applied///////////////////////////
////////////////////////////////////////////////////////////////////////////////  
            
            include_once 'util/DBUTIL.php';
            $dbutil = new DBUTIL($this->crg);

            $crud_string = null;
            
            
	
            if (isset($_REQUEST['process_ID'])) {
                $crud_string = 'approve';
                   
            } 
            
            
            
            
             switch ($crud_string) {
                 
                 
             
                case 'approve': 
                       
                        // $approvaltype_tab = $this->crg->get('table_prefix') . 'approvalprocess';
                        // $sql = "SELECT process_ID FROM $approvaltype_tab where  $approvaltype_tab.ProcessType='Material Request"; 
                        // $stmt = $this->db->prepare($sql);            
                        // $stmt->execute();
                        // $approvaltype_data = $stmt->fetchAll();	
                        
                        //$approve=$approvaltype_data;
                      
            
           
                    
                    $rawmaterial_table = $this->crg->get('table_prefix') . 'rawmaterial';
                    $matreqdetail_tab = $this->crg->get('table_prefix') . 'MaterialRequestDetail';
                    $matreqmaster_tab = $this->crg->get('table_prefix') . 'MaterialRequestMaster';


                    //rawmaterial select box data
                    
                    $sql = "SELECT ID,RMName FROM $rawmaterial_table"; 
                    $stmt = $this->db->prepare($sql);            
                    $stmt->execute();
                    $rawmaterial_data  = $stmt->fetchAll();	
                    $this->tpl->set('rawmaterial_data', $rawmaterial_data);
        
                    $this->tpl->set('page_title', 'Material Request');	          
                    $this->tpl->set('page_header', 'Production');
                    //Add Role when u submit the add role form
                    $thisPageURL = $this->crg->get('route')['base_path'] . '/' . $this->crg->get('route')['module'] . '/' . $this->crg->get('route')['controller'] . '/' . $this->crg->get('route')['action'];

                   // $data = trim($_POST['process_ID']);
                   
                   $data = trim($_GET['process_ID']);
                   
                  // var_dump($data);
                    
                    //  $ProcessType = trim($_POST['ProcessType']);
                    
                     $ProcessType = trim($_GET['processtype']);
                     
                    
                     
                     
                     if($ProcessType=='Material Request'){
                 
                  
                    //mode of form submit
                    $this->tpl->set('mode', 'edit');
                    //set id to edit $ycs_ID
                    $this->tpl->set('ycs_ID', $data);         
                                
                      $sqlsrr = "SELECT * FROM `$matreqdetail_tab`,`$matreqmaster_tab` WHERE `$matreqdetail_tab`.`materialrequest_ID`=`$matreqmaster_tab`.`ID` AND `$matreqdetail_tab`.`materialrequest_ID` = '$data'";                    
                  
                      $matreqdetail_data = $dbutil->getSqlData($sqlsrr);
                     
                  
                    //edit option     
                    $this->tpl->set('message', 'Material Request Approval Form');
                    $this->tpl->set('page_header', 'Production');
                    $this->tpl->set('FmData', $matreqdetail_data); 
                    
                    
                     $_SESSION['req_from_list_view']='edit';
                     $_SESSION['ycs_ID']=$data;
                     header('Location:' . $this->crg->get('route')['base_path'] . '/product/mat/materialrequest');
                     $this->tpl->set('master_layout', 'layout_datepicker.php');
                      // $this->tpl->set('content', $this->tpl->fetch('factory/form/MaterialRequest_form.php')); 
                  
                     }
                    //  elseif($ProcessType=='Purchase Order'){
                         
                    // $pom_tab = $this->crg->get('table_prefix') . 'purchaseorder';
                    // $pod_tab = $this->crg->get('table_prefix') . 'purchaseorderdetail';
                    
        
                    // $this->tpl->set('page_title', 'Purchase Order');	          
                    // $this->tpl->set('page_header', 'Production');
                    // //Add Role when u submit the add role form
                    // $thisPageURL = $this->crg->get('route')['base_path'] . '/' . $this->crg->get('route')['module'] . '/' . $this->crg->get('route')['controller'] . '/' . $this->crg->get('route')['action'];

                    // //$data = trim($_POST['process_ID']);
   
                   
                    // //mode of form submit
                    // $this->tpl->set('mode', 'edit');
                    // //set id to edit $ycs_ID
                    // $this->tpl->set('ycs_ID', $data);         
                                
                    //   $sqlsrr = "SELECT * FROM `$pod_tab`,`$pom_tab` WHERE `$pod_tab`.`purchaseorder_ID`=`$pom_tab`.`ID` AND `$pod_tab`.`purchaseorder_ID` = '$data'";                    
                  
                    //   $pomdetail_data = $dbutil->getSqlData($sqlsrr);
                      
                    // //edit option     
                    // $this->tpl->set('message', 'You can edit Purchase Order form');
                    // $this->tpl->set('page_header', 'Production');
                    // $this->tpl->set('FmData', $pomdetail_data); 
                    
                    
                    //  $_SESSION['req_from_list_view']='edit';
                    //  $_SESSION['ycs_ID']=$data;
                    //  header('Location:' . $this->crg->get('route')['base_path'] . '/purchase/pur/order');
                    //  $this->tpl->set('master_layout', 'layout_datepicker.php');
                    //   // $this->tpl->set('content', $this->tpl->fetch('factory/form/MaterialRequest_form.php')); 
                    //  }
                     
                    elseif($ProcessType=='Purchase Request') {
                         
                    $prm_tab = $this->crg->get('table_prefix') . 'PurchaseRequestMaster';
                    $prd_tab = $this->crg->get('table_prefix') . 'PurchaseRequestDetail';
                    
        
                    $this->tpl->set('page_title', 'Purchase Request');
                    $this->tpl->set('page_header', 'Production');
                    //Add Role when u submit the add role form
                    $thisPageURL = $this->crg->get('route')['base_path'] . '/' . $this->crg->get('route')['module'] . '/' . $this->crg->get('route')['controller'] . '/' . $this->crg->get('route')['action'];

                    //$data = trim($_POST['process_ID']);
   
                   
                    //mode of form submit
                    $this->tpl->set('mode', 'edit');
                    //set id to edit $ycs_ID
                    $this->tpl->set('ycs_ID', $data);
                                
                     $sqlsrr = "SELECT * FROM `$prd_tab`,`$prm_tab` WHERE `$prd_tab`.`purchaseorder_ID`=`$prm_tab`.`ID` AND `$prd_tab`.`purchaseorder_ID` = '$data'";
                  
                      $pomdetail_data = $dbutil->getSqlData($sqlsrr);
                      
                    //edit option     
                    $this->tpl->set('message', 'Purchase Request Approval Form');
                    $this->tpl->set('page_header', 'Production');
                    $this->tpl->set('FmData', $pomdetail_data); 
                    
                    
                     $_SESSION['req_from_list_view']='edit';
                     $_SESSION['ycs_ID']=$data;
                     header('Location:' . $this->crg->get('route')['base_path'] . '/purchase/pur/purchaserequest');
                     $this->tpl->set('master_layout', 'layout_datepicker.php');
                      // $this->tpl->set('content', $this->tpl->fetch('factory/form/MaterialRequest_form.php')); 
                     }
                     
                  
                     
                     elseif($ProcessType=='Pipe Production'){
                         
                          $pipe_tab = $this->crg->get('table_prefix') . 'pipeproduction';
                          $pipeprod_tab = $this->crg->get('table_prefix') . 'productionbreakdowndet';
                          $pipeprodraw_tab = $this->crg->get('table_prefix') . 'pprawmaterialdet';
        
                    $this->tpl->set('page_title', 'Pipe Production');	          
                    $this->tpl->set('page_header', 'Production');
                    //Add Role when u submit the add role form
                    $thisPageURL = $this->crg->get('route')['base_path'] . '/' . $this->crg->get('route')['module'] . '/' . $this->crg->get('route')['controller'] . '/' . $this->crg->get('route')['action'];

                   // $data = trim($_POST['process_ID']);
   
                   
                    //mode of form submit
                    $this->tpl->set('mode', 'edit');
                    //set id to edit $ycs_ID
                    $this->tpl->set('ycs_ID', $data);         
                                
                      $sqlsrr = "SELECT * FROM `$pipe_tab`,`$pipeprod_tab`,`$pipeprodraw_tab` WHERE `$pipeprod_tab`.`pipeproduction_ID`=`$pipe_tab`.`ID` AND `$pipeprodraw_tab`.`pipeproduction_ID`=`$pipe_tab`.`ID` AND `$pipe_tab`.`ID` = '$data'";
                  
                      $pipedetail_data = $dbutil->getSqlData($sqlsrr);
                        
                  
                    //edit option     
                    $this->tpl->set('message', 'Pipe Production Approval Form');
                    $this->tpl->set('page_header', 'Production');
                    $this->tpl->set('FmData', $pipedetail_data); 
                    
                    
                     $_SESSION['req_from_list_view']='edit';
                     $_SESSION['ycs_ID']=$data;
                     header('Location:' . $this->crg->get('route')['base_path'] . '/product/cst/pipe');
                     $this->tpl->set('master_layout', 'layout_datepicker.php');
                      // $this->tpl->set('content', $this->tpl->fetch('factory/form/MaterialRequest_form.php')); 
                     }
                     elseif($ProcessType=='Inspection Approval'){
                          $inspmast_tab = $this->crg->get('table_prefix') . 'onlineinspmaster';
                          $inspdet_tab = $this->crg->get('table_prefix') . 'onlineinspdet';
                          $inspsubdet_tab = $this->crg->get('table_prefix') . 'onlineinspsubdet';
                          $inspprobdet_tab = $this->crg->get('table_prefix') . 'onlineinspprobdet';
        
        
                    $this->tpl->set('page_title', 'Online Inspection');	          
                    $this->tpl->set('page_header', 'Production');
                    //Add Role when u submit the add role form
                    $thisPageURL = $this->crg->get('route')['base_path'] . '/' . $this->crg->get('route')['module'] . '/' . $this->crg->get('route')['controller'] . '/' . $this->crg->get('route')['action'];

                   // $data = trim($_POST['process_ID']);
   
                   
                    //mode of form submit
                    $this->tpl->set('mode', 'edit');
                    //set id to edit $ycs_ID
                    $this->tpl->set('ycs_ID', $data);         
                                
                      $sqlsrr = "SELECT * FROM `$inspmast_tab`,`$inspdet_tab`,`$inspsubdet_tab`,`$inspprobdet_tab` WHERE `$inspdet_tab`.`onlineinspmaster_ID`=`$inspmast_tab`.`ID` AND `$inspsubdet_tab`.`onlineinspmaster_ID`=`$inspmast_tab`.`ID` AND `$inspprobdet_tab`.`onlineinspmaster_ID`=`$inspmast_tab`.`ID` AND `$inspmast_tab`.`ID` = '$data'";                    
                  
                      $inspdetail_data = $dbutil->getSqlData($sqlsrr);
                        
                  
                    //edit option     
                    $this->tpl->set('message', 'Online Inspection Approval Form');
                    $this->tpl->set('page_header', 'Production');
                    $this->tpl->set('FmData', $inspdetail_data); 
                    
                    
                     $_SESSION['req_from_list_view']='edit';
                     $_SESSION['ycs_ID']=$data;
                     header('Location:' . $this->crg->get('route')['base_path'] . '/product/cst/oie');
                     $this->tpl->set('master_layout', 'layout_datepicker.php');
                      // $this->tpl->set('content', $this->tpl->fetch('factory/form/MaterialRequest_form.php')); 
                     }
                     
                      elseif($ProcessType=='Why-Why Analysis'){
                          $whymast_tab = $this->crg->get('table_prefix') . 'whywhy ';
                          $whydet_tab = $this->crg->get('table_prefix') . 'whywhydet ';
                         
        
        
                    $this->tpl->set('page_title', 'Why-Why Analysis');	          
                    $this->tpl->set('page_header', 'Production');
                    //Add Role when u submit the add role form
                    $thisPageURL = $this->crg->get('route')['base_path'] . '/' . $this->crg->get('route')['module'] . '/' . $this->crg->get('route')['controller'] . '/' . $this->crg->get('route')['action'];

                   // $data = trim($_POST['process_ID']);
   
                   
                    //mode of form submit
                    $this->tpl->set('mode', 'edit');
                    //set id to edit $ycs_ID
                    $this->tpl->set('ycs_ID', $data);         
                                
                      $sqlsrr = "SELECT * FROM `$whymast_tab`,`$whydet_tab` WHERE `$whydet_tab`.`whywhy_ID`=`$whymast_tab`.`ID` AND  `$whydet_tab`.`whywhy_ID` = '$data'";                    
                  
                      $whydetail_data = $dbutil->getSqlData($sqlsrr);
                        
                  
                    //edit option     
                    $this->tpl->set('message', ' Why-Why Analysis Approval Form');
                    $this->tpl->set('page_header', 'Production');
                    $this->tpl->set('FmData', $whydetail_data); 
                    
                    
                     $_SESSION['req_from_list_view']='edit';
                     $_SESSION['ycs_ID']=$data;
                     header('Location:' . $this->crg->get('route')['base_path'] . '/admin/mast/why');
                     $this->tpl->set('master_layout', 'layout_datepicker.php');
                      // $this->tpl->set('content', $this->tpl->fetch('factory/form/MaterialRequest_form.php')); 
                     }
                      elseif($ProcessType=='GRN Approval')
                   {
                   
                 
                   
                    $grn_tab = $this->crg->get('table_prefix') . 'purchaseentry';
                    $grndetail_tab = $this->crg->get('table_prefix') . 'purchaseentrydetail';
                    
        
                    $this->tpl->set('page_title', 'GRN Approval');	
                    $this->tpl->set('page_header', 'Production');
                    //Add Role when u submit the add role form
                    $thisPageURL = $this->crg->get('route')['base_path'] . '/' . $this->crg->get('route')['module'] . '/' . $this->crg->get('route')['controller'] . '/' . $this->crg->get('route')['action'];
                    
                    
                  //  $data = trim($_POST['process_ID']);
                    
                    //mode of form submit
                   
                    $this->tpl->set('mode', 'edit');
                    //set id to edit $ycs_ID
                    $this->tpl->set('ycs_ID', $data);         
                                
                      $sqlsrr = "SELECT * FROM `$grndetail_tab`,`$grn_tab` WHERE `$grndetail_tab`.`purchaseentry_ID`=`$grn_tab`.`ID` AND `$grndetail_tab`.`purchaseentry_ID` = '$data'";                    
                  
                      $grndetail_data = $dbutil->getSqlData($sqlsrr);

                    //edit option     
                    $this->tpl->set('message', 'GRN Approval Form');
                    $this->tpl->set('page_header', 'Production');
                    $this->tpl->set('FmData', $grndetail_data); 
                   
                   
                    
                     $_SESSION['req_from_list_view']='edit';
                     $_SESSION['ycs_ID']=$data;
                     // commented on 18/5/ 2020 header('Location:' . $this->crg->get('route')['base_path'] . '/purchase/pur/purchase');
                     header('Location:' . $this->crg->get('route')['base_path'] . '/product/cst/purchase');
                     $this->tpl->set('master_layout', 'layout_datepicker.php');
                      // $this->tpl->set('content', $this->tpl->fetch('factory/form/MaterialRequest_form.php')); 
                     
                       
                   }
                  break;
                    
                    
                     
                    // $pom_tab = $this->crg->get('table_prefix') . 'purchaseorder';
                    // $pod_tab = $this->crg->get('table_prefix') . 'purchaseorderdetail';
                    
        
                    // $this->tpl->set('page_title', 'Purchase Order');	          
                    // $this->tpl->set('page_header', 'Production');
                    // //Add Role when u submit the add role form
                    // $thisPageURL = $this->crg->get('route')['base_path'] . '/' . $this->crg->get('route')['module'] . '/' . $this->crg->get('route')['controller'] . '/' . $this->crg->get('route')['action'];

                     //$data = trim($_POST['process_ID']);
  // var_dump($data);
                    
                    // //mode of form submit
                    // $this->tpl->set('mode', 'edit');
                    // //set id to edit $ycs_ID
                    // $this->tpl->set('ycs_ID', $data);         
                                
                    //   $sqlsrr = "SELECT * FROM `$pod_tab`,`$pom_tab` WHERE `$pod_tab`.`purchaseorder_ID`=`$pom_tab`.`ID` AND `$pod_tab`.`purchaseorder_ID` = '$data'";                    
                  
                    //   $pomdetail_data = $dbutil->getSqlData($sqlsrr);
                        
                  
                    // //edit option     
                    // $this->tpl->set('message', 'You can edit Purchase Order form');
                    // $this->tpl->set('page_header', 'Production');
                    // $this->tpl->set('FmData', $pomdetail_data); 
                    
                    
                    //  $_SESSION['req_from_list_view']='edit';
                    //  $_SESSION['ycs_ID']=$data;
                    //  header('Location:' . $this->crg->get('route')['base_path'] . '/purchase/pur/order');
                    //  $this->tpl->set('master_layout', 'layout_datepicker.php');
                    //   // $this->tpl->set('content', $this->tpl->fetch('factory/form/MaterialRequest_form.php')); 
                    // break;
                    
                    default :
                        // print_r($this->ses->get('user'));
                      
                        $user_tab = $this->crg->get('table_prefix') . 'users'; 
                        $appprocess_tab = $this->crg->get('table_prefix') . 'approvalprocess'; 
                        $entityID = $this->ses->get('user')['entity_ID'];
                      
            	        
            	        $sqlinbox =  "SELECT s.user_nicename as SendToUser,f.user_nicename as SendFrmUser,a.ProcessType,a.process_ID,CONCAT(if( "
                                        ."TIMESTAMPDIFF(day,a.AuditDateTime,NOW())=0,'',concat(TIMESTAMPDIFF(day,a.AuditDateTime,NOW()),' days ')) , "
                                        ."if(MOD( TIMESTAMPDIFF(hour,a.AuditDateTime,NOW()), 24)=0,'',concat(MOD( TIMESTAMPDIFF(hour,a.AuditDateTime,NOW()), 24), ' hours ')),"
                                        ."MOD( TIMESTAMPDIFF(minute,a.AuditDateTime,NOW()), 60), ' minutes '"
                                        .") as age FROM $appprocess_tab a JOIN $user_tab s ON s.ID = a.sendfromUser_ID JOIN $user_tab f ON f.ID = a.sendtoUser_ID where a.ApprovalStatus=0";
                       
                                        $sqlinboxdata = $dbutil->getSqlData($sqlinbox,2); 
                                        $this->tpl->set('sqlinbox_data', $sqlinboxdata);

                    
                        $this->tpl->set('content', $this->tpl->fetch('factory/mailbox.php'));
            
            
            
                }
                            //////////////////////////////on access condition failed then ///////////////////////////
                        } else {
                            if ($this->ses->get('user')['ID']) {
                                $this->tpl->set('content', $this->tpl->fetch('modules/user/acess_failed_message.php'));
                            } else {
                                header('Location:' . $this->crg->get('route')['base_path'] . '/user/auth/login');
                            }
                        }
                    }


    function dashboard() {
        if ($this->crg->get('wp') || $this->crg->get('rp')) {

//////////////////////////////////////////////////////////////////////////////////
//////////////////////////////access condition applied///////////////////////////
////////////////////////////////////////////////////////////////////////////////  
            
            include_once 'util/DBUTIL.php';
            $dbutil = new DBUTIL($this->crg);

            $crud_string = null;
	
            if (isset($_POST['Action'])) {
                $crud_string = strtolower($_POST['Action']);
            } 
            
             switch ($crud_string) {
                
                  default :
            // print_r($this->ses->get('user'));
            $stock_tab = $this->crg->get('table_prefix') . 'stock';      
            $prd_tab = $this->crg->get('table_prefix') . 'product'; 
            $user_tab = $this->crg->get('table_prefix') . 'users'; 
             $appprocess_tab = $this->crg->get('table_prefix') . 'approvalprocess'; 
            $entityID = $this->ses->get('user')['entity_ID'];
            
            $sqlstk = "SELECT $prd_tab.ItemName,$stock_tab.TotalQty, $stock_tab.LastUpdatedRate, $stock_tab.TotalValue,$user_tab.user_nicename,$stock_tab.AuditDateTime FROM $stock_tab,$user_tab,$prd_tab WHERE $prd_tab.ID=$stock_tab.ItemNo AND $user_tab.ID= $stock_tab.users_ID AND $stock_tab.entity_ID = $entityID";            
            $stock = $dbutil->getSqlData($sqlstk,2); 
	        $this->tpl->set('stk_data', $stock);
	        
	       
	        
            $cst_tab = $this->crg->get('table_prefix') . 'customer';
            $sqlcus = "SELECT COUNT(SGuserRegDate) FROM $cst_tab "
                    . "WHERE MONTH(SGuserRegDate) = MONTH(CURDATE()) "
                    . "AND YEAR(SGuserRegDate) = YEAR(CURDATE()) AND entity_ID = $entityID";            
            $cus_reg = $dbutil->getSqlData($sqlcus,2);              
	        $this->tpl->set('cus_reg_data', $cus_reg);
                        
            $sqlcusqry = "SELECT COUNT(PackExpireDate) FROM $cst_tab "
                       . "WHERE DATE(PackExpireDate) = CURDATE() AND entity_ID = $entityID";            
            $cuspac_expr = $dbutil->getSqlData($sqlcusqry,2); 
            //var_dump($cuspac_expr);
	    $this->tpl->set('cus_pac_reg', $cuspac_expr);
        
        
           /// commented by mr to show new page $this->tpl->set('content', $this->tpl->fetch('factory/dashboard.php'));
             $this->tpl->set('content', $this->tpl->fetch('factory/dashboard_new.php'));
            
            
            
}
            //////////////////////////////on access condition failed then ///////////////////////////
        } else {
            if ($this->ses->get('user')['ID']) {
                $this->tpl->set('content', $this->tpl->fetch('modules/user/acess_failed_message.php'));
            } else {
                header('Location:' . $this->crg->get('route')['base_path'] . '/user/auth/login');
            }
        }
    }
    
    function chart() {
        if ($this->crg->get('wp') || $this->crg->get('rp')) {

//////////////////////////////////////////////////////////////////////////////////
//////////////////////////////access condition applied///////////////////////////
////////////////////////////////////////////////////////////////////////////////  
            
                        $sql_query = "CALL pPODashboard()"; 
                        $stmt = $this->db->prepare($sql_query);                        
                        $stmt->execute();
                        $result = $stmt->fetchAll(2);
                        $json_cart_data = json_encode($result);
                        //var_dump($result);
                        
                        $this->tpl->set('po_stage_data', $json_cart_data);
                        
                        $sql_query1 = "CALL pPrdWiseDespQty()"; 
                        $stmt = $this->db->prepare($sql_query1);                        
                        $stmt->execute();
                        $result1 = $stmt->fetchAll();
                        $result2 = array();
                        foreach($result1 as $k=>$v){
                           $result2[]=[$v['ItemName'],$v['Qty']];
                        }
                       
                        $json_bar_cart = json_encode($result2);
                        //var_dump($json_bar_cart);
                        
                        $this->tpl->set('despatch_data', $json_bar_cart);
                        
                        
        
            $this->tpl->set('content', $this->tpl->fetch('factory/chart.php'));

            //////////////////////////////on access condition failed then ///////////////////////////
        } else {
            if ($this->ses->get('user')['ID']) {
                $this->tpl->set('content', $this->tpl->fetch('modules/user/acess_failed_message.php'));
            } else {
                header('Location:' . $this->crg->get('route')['base_path'] . '/user/auth/login');
            }
        }
    }

    /*
     * End of Class
     */
}

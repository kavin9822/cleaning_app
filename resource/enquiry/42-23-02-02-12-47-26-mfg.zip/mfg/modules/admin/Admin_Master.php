<?php

/**
 * Description of Customer_Mod
 *
 * @author psmahadevan
 */
class Admin_Master {

    private $crg;
    private $ses;
    private $db;
    private $sd;
    private $tpl;
    private $rbac;

    public function __construct($reg = NULL) {
        /*
         * Receiving $rg array
         */
        $this->crg = $reg;

        /*
         * geting object from reg array
         */
        $this->ses = $this->crg->get('ses');
        $this->db = $this->crg->get('db');
        $this->sd = $this->crg->get('SD');
        $this->tpl = $this->crg->get('tpl');
        $this->rbac = $this->crg->get('rbac');
    }

    function department() {
        if ($this->crg->get('wp') || $this->crg->get('rp')) {
//////////////////////////////////////////////////////////////////////////////////
//////////////////////////////access condition applied///////////////////////////
//////////////////////////////////////////////////////////////////////////////// 
          
           include_once 'util/DBUTIL.php';
           $dbutil = new DBUTIL($this->crg);
             
             $entityID = $this->ses->get('user')['entity_ID'];
             $userID = $this->ses->get('user')['ID'];
            
            
           $dept_tab = $this->crg->get('table_prefix') . 'department';
                  
          

            ////////////////////start//////////////////////////////////////////////
                    
           //bUILD SQL 
            $whereString = '';
            
            $colArr = array(
                "$dept_tab.ID", 
                "$dept_tab.DeptName",
                "$dept_tab.Description"
               
            );
            
            $this->tpl->set('FmData', $_POST);
            foreach($_POST as $k=>$v){
                if(strpos($k,'^')){
                    unset($_POST[$k]);
                }
                $_POST[str_replace('^','_',$k)] = $v;
            }
            $PD=$_POST;
            if($_POST['list']!=''){
                $this->tpl->set('FmData', NULL);
                $PD=NULL;
            }

            IF (count($PD) >= 2) {
                $wsarr = array();
                foreach ($colArr as $colNames) {

		   if (strpos($colNames, 'Date') !== false) {
                list($colNames,$x) = $dbutil->dateFilterFormat($colNames);
            } else {
		        $x = $dbutil->__mdsf($PD[str_replace('.','_',$colNames)]);
            }

                    if ('' != $x) {
                        $wsarr[] = $colNames . " LIKE '%" . $x . "%'";
                    }
                }
                
              IF (count($wsarr) >= 1) {
                 $whereString = ' AND '. implode(' AND ', $wsarr);
              }
            }
            
            $orderBy ="ORDER BY $dept_tab.ID DESC";
            
         $sql = "SELECT "
                 . implode(',',$colArr)
                 . " FROM $dept_tab "
                 . " WHERE "
                 . " $dept_tab.entity_ID=$entityID "
                 . " $whereString "
                 . " $orderBy";
         
            //$results_per_page = 50;   
			$results_per_page = 5;   			
            
                if(isset($PD['pageno'])){$page=$PD['pageno'];}
                else if(isset($PD['pagenof'])){$page=$PD['pagenofirst'];}
                else if(isset($PD['pagenop'])){$page=$PD['pagenoprev'];}
                else if(isset($PD['pagenon'])){$page=$PD['pagenonext'];}
                else if(isset($PD['pagenol'])){$page=$PD['pagenolast'];}
                else if(isset($PD['pagenog'])){$page=$PD['pagenogo'];}
                else{$page=1;} 
         
            /*
             * SET DATA TO TEMPLATE
             */
          //  $this->tpl->set('sql_data_rows', $dbutil->setPaginationList($sql,$page,$results_per_page,$wsarr));
			  $this->tpl->set('sql_data_rows', $dbutil->setPaginationList($sql,$page,$results_per_page,$wsarr));
            /*
             * set table label
             */
            $this->tpl->set('table_columns_label_arr', array('ID','Department Name','Description'));
            
            /*,;;
             * selectColArr for filter form
             */
            
            $this->tpl->set('selectColArr',$colArr);
                        
            /*
             * set pagination template
             */
            $this->crg->set('paginationListTemplate','factory/template/sql_based_crud_paginated_table.php');
                   
            //////////////////////close//////////////////////////////////////  
          
             include_once $this->tpl->path .'/factory/form/crud_form_departmentmaster.php';
            
            
            $cus_form_data = Form_Elements::data($this->crg);
            include_once 'util/crud3_1.php';
            new Crud3($this->crg, $cus_form_data);
            $this->tpl->set('master_layout', 'layout_datepicker.php'); 
             //if crud is delivered at different point a template
            //Then  call that template and set to content
           
           ////$this->tpl->set('content', $this->tpl->fetch('modules/customer/manage_customer.php'));
        //////////////////////////////////////////////////////////////////////////////////
        //////////////////////////////on access condition failed then ///////////////////////////
        ////////////////////////////////////////////////////////////////////////////////            
        } else {
            if ($this->ses->get('user')['ID']) {
                $this->tpl->set('content', $this->tpl->fetch('modules/user/acess_failed_message.php'));
            } else {
                header('Location:' . $this->crg->get('route')['base_path'] . '/user/auth/login');
            }
        }
    }   
    //////////////////department close here//
    function unit() {

        if ($this->crg->get('wp') || $this->crg->get('rp')) {

        //////////////////////////////////////////////////////////////////////////////////
        
        //////////////////////////////access condition applied///////////////////////////
        
        //////////////////////////////////////////////////////////////////////////////// 

         
           include_once 'util/DBUTIL.php';

           $dbutil = new DBUTIL($this->crg);

           $entityID = $this->ses->get('user')['entity_ID'];
           $userID = $this->ses->get('user')['ID'];
           $unit_tab = $this->crg->get('table_prefix') . 'unit';

            ////////////////////start//////////////////////////////////////////////

           //bUILD SQL 

            $whereString = '';

            $colArr = array(

                "$unit_tab.ID",
                "$unit_tab.UnitName",
                "$unit_tab.Description"
            );

            $this->tpl->set('FmData', $_POST);

            foreach($_POST as $k=>$v){

                if(strpos($k,'^')){

                    unset($_POST[$k]);

                }

                $_POST[str_replace('^','_',$k)] = $v;

            }

            $PD=$_POST;

            if($_POST['list']!=''){

                $this->tpl->set('FmData', NULL);

                $PD=NULL;

            }



            IF (count($PD) >= 2) {

                $wsarr = array();

                foreach ($colArr as $colNames) {



		   if (strpos($colNames, 'Date') !== false) {

                list($colNames,$x) = $dbutil->dateFilterFormat($colNames);

            } else {

		        $x = $dbutil->__mdsf($PD[str_replace('.','_',$colNames)]);

            }



                    if ('' != $x) {

                        $wsarr[] = $colNames . " LIKE '%" . $x . "%'";

                    }

                }

                

              IF (count($wsarr) >= 1) {

                 $whereString = ' AND '. implode(' AND ', $wsarr);

              }

            }

            $orderBy ="ORDER BY $unit_tab.ID DESC";

         $sql = "SELECT "

                 . implode(',',$colArr)

                 . " FROM $unit_tab "

                 . " WHERE "

                 . " $unit_tab.entity_ID=$entityID "

                 . " $whereString "

                 . " $orderBy";

            $results_per_page = 50;     

                if(isset($PD['pageno'])){$page=$PD['pageno'];}

                else if(isset($PD['pagenof'])){$page=$PD['pagenofirst'];}

                else if(isset($PD['pagenop'])){$page=$PD['pagenoprev'];}

                else if(isset($PD['pagenon'])){$page=$PD['pagenonext'];}

                else if(isset($PD['pagenol'])){$page=$PD['pagenolast'];}

                else if(isset($PD['pagenog'])){$page=$PD['pagenogo'];}

                else{$page=1;} 


            /*

             * SET DATA TO TEMPLATE

             */

            $this->tpl->set('sql_data_rows', $dbutil->setPaginationList($sql,$page,$results_per_page,$wsarr));

            /*

             * set table label

             */

            $this->tpl->set('table_columns_label_arr', array('ID','Unit Name','Description',));

            

            /*,;;

             * selectColArr for filter form

             */

            

            $this->tpl->set('selectColArr',$colArr);

                        

            /*

             * set pagination template

             */

            $this->crg->set('paginationListTemplate','factory/template/sql_based_crud_paginated_table.php');

            //////////////////////close//////////////////////////////////////  

            include_once $this->tpl->path .'/factory/form/crud_form_unit.php';

            $cus_form_data = Form_Elements::data($this->crg);

            include_once 'util/crud3_1.php';

            new Crud3($this->crg, $cus_form_data);

            $this->tpl->set('master_layout', 'layout_datepicker.php'); 

             //if crud is delivered at different point a template

            //Then  call that template and set to content

           

           ////$this->tpl->set('content', $this->tpl->fetch('modules/customer/manage_customer.php'));

        //////////////////////////////////////////////////////////////////////////////////

        //////////////////////////////on access condition failed then ///////////////////////////

        ////////////////////////////////////////////////////////////////////////////////            

        } else {

            if ($this->ses->get('user')['ID']) {

                $this->tpl->set('content', $this->tpl->fetch('modules/user/acess_failed_message.php'));

            } else {

                header('Location:' . $this->crg->get('route')['base_path'] . '/user/auth/login');

            }

        }

    } 
    ////////////////////////////////////////
    function designation() {
       
        if ($this->crg->get('wp') || $this->crg->get('rp')) {
            
        //////////////////////////////////////////////////////////////////////////////////
        //////////////////////////////access condition applied///////////////////////////
        //////////////////////////////////////////////////////////////////////////////// 
                  
            include_once 'util/DBUTIL.php';
            $dbutil = new DBUTIL($this->crg);
             
            $entityID = $this->ses->get('user')['entity_ID'];
            $userID = $this->ses->get('user')['ID'];
            
            $department_tab = $this->crg->get('table_prefix') . 'department';
            $designation_tab = $this->crg->get('table_prefix') . 'designation';      
          

            ////////////////////start//////////////////////////////////////////////
                    
           //bUILD SQL 
            $whereString = '';
            
            $colArr = array(
                "$designation_tab.ID", 
                "$designation_tab.DesignationName",
				"$department_tab.DeptName"
               
            );
            
            $this->tpl->set('FmData', $_POST);
            foreach($_POST as $k=>$v){
                if(strpos($k,'^')){
                    unset($_POST[$k]);
                }
                $_POST[str_replace('^','_',$k)] = $v;
            }
            $PD=$_POST;
            if($_POST['list']!=''){
                $this->tpl->set('FmData', NULL);
                $PD=NULL;
            }

            IF (count($PD) >= 2) {
                $wsarr = array();
                foreach ($colArr as $colNames) {

		   if (strpos($colNames, 'Date') !== false) {
                list($colNames,$x) = $dbutil->dateFilterFormat($colNames);
            } else {
		        $x = $dbutil->__mdsf($PD[str_replace('.','_',$colNames)]);
            }

                    if ('' != $x) {
                        $wsarr[] = $colNames . " LIKE '%" . $x . "%'";
                    }
                }
                
              IF (count($wsarr) >= 1) {
                 $whereString = ' AND '. implode(' AND ', $wsarr);
              }
            }
            
            $orderBy ="ORDER BY $designation_tab.ID DESC";
            
         $sql = "SELECT "
                 . implode(',',$colArr)
                 . " FROM $designation_tab,$department_tab "
                 . " WHERE "
                 . " $designation_tab.entity_ID=$entityID AND"
                 . " $designation_tab.Department_ID=$department_tab.ID "
                 . " $whereString "
                 . " $orderBy";
         
            $results_per_page = 50;     
            
                if(isset($PD['pageno'])){$page=$PD['pageno'];}
                else if(isset($PD['pagenof'])){$page=$PD['pagenofirst'];}
                else if(isset($PD['pagenop'])){$page=$PD['pagenoprev'];}
                else if(isset($PD['pagenon'])){$page=$PD['pagenonext'];}
                else if(isset($PD['pagenol'])){$page=$PD['pagenolast'];}
                else if(isset($PD['pagenog'])){$page=$PD['pagenogo'];}
                else{$page=1;} 
         
            /*
             * SET DATA TO TEMPLATE
             */
            $this->tpl->set('sql_data_rows', $dbutil->setPaginationList($sql,$page,$results_per_page,$wsarr));
            /*
             * set table label
             */
            $this->tpl->set('table_columns_label_arr', array('ID','Designation Name','Department Name'));
            
            /*,;;
             * selectColArr for filter form
             */
            
            $this->tpl->set('selectColArr',$colArr);
                        
            /*
             * set pagination template
             */
            $this->crg->set('paginationListTemplate','factory/template/sql_based_crud_paginated_table.php');
                   
            //////////////////////close//////////////////////////////////////  
          
             include_once $this->tpl->path .'/factory/form/crud_form_designation.php';
            
            
            $cus_form_data = Form_Elements::data($this->crg);
            include_once 'util/crud3_1.php';
            new Crud3($this->crg, $cus_form_data);
            $this->tpl->set('master_layout', 'layout_datepicker.php'); 
             //if crud is delivered at different point a template
            //Then  call that template and set to content
           
           ////$this->tpl->set('content', $this->tpl->fetch('modules/customer/manage_customer.php'));
        //////////////////////////////////////////////////////////////////////////////////
        //////////////////////////////on access condition failed then ///////////////////////////
        ////////////////////////////////////////////////////////////////////////////////            
        } else {
            if ($this->ses->get('user')['ID']) {
                $this->tpl->set('content', $this->tpl->fetch('modules/user/acess_failed_message.php'));
            } else {
                header('Location:' . $this->crg->get('route')['base_path'] . '/user/auth/login');
            }
        }
    }
    ///////////////////////////////////////
    function rawmaterialtype() {
    if ($this->crg->get('wp') || $this->crg->get('rp')) {
        
        ////////////////////////////////////////////////////////////
        //////////////////////////////access condition applied//////
        ////////////////////////////////////////////////////////////
      
        include_once 'util/DBUTIL.php';
        $dbutil = new DBUTIL($this->crg);
         
        $entityID = $this->ses->get('user')['entity_ID'];
        $userID = $this->ses->get('user')['ID'];
        
        $rawmaterialtype_tab = $this->crg->get('table_prefix') . 'rawmaterialtype';
              
        ////////////////////start//////////////////////////////////////////////
                
       //bUILD SQL 
        $whereString = '';
        
        $colArr = array(
            "$rawmaterialtype_tab.ID", 
            "$rawmaterialtype_tab.RawMaterialType",
            "$rawmaterialtype_tab.Description"
        );
        
        $this->tpl->set('FmData', $_POST);
        foreach($_POST as $k=>$v){
            if(strpos($k,'^')){
                unset($_POST[$k]);
            }
            $_POST[str_replace('^','_',$k)] = $v;
        }
        $PD=$_POST;
        if($_POST['list']!=''){
            $this->tpl->set('FmData', NULL);
            $PD=NULL;
        }

        IF (count($PD) >= 2) {
            $wsarr = array();
            foreach ($colArr as $colNames) {

       if (strpos($colNames, 'Date') !== false) {
            list($colNames,$x) = $dbutil->dateFilterFormat($colNames);
        } else {
            $x = $dbutil->__mdsf($PD[str_replace('.','_',$colNames)]);
        }

                if ('' != $x) {
                    $wsarr[] = $colNames . " LIKE '%" . $x . "%'";
                }
            }
            
          IF (count($wsarr) >= 1) {
             $whereString = ' WHERE '. implode(' AND ', $wsarr);

          }
        }
        
        $orderBy ="ORDER BY $rawmaterialtype_tab.ID DESC";
        
     $sql = "SELECT "
             . implode(',',$colArr)
             . " FROM $rawmaterialtype_tab "
             . " WHERE "
             . " $rawmaterialtype_tab.entity_ID=$entityID "
             . " $whereString "
             . " $orderBy";
     
        $results_per_page = 50;     
        
            if(isset($PD['pageno'])){$page=$PD['pageno'];}
            else if(isset($PD['pagenof'])){$page=$PD['pagenofirst'];}
            else if(isset($PD['pagenop'])){$page=$PD['pagenoprev'];}
            else if(isset($PD['pagenon'])){$page=$PD['pagenonext'];}
            else if(isset($PD['pagenol'])){$page=$PD['pagenolast'];}
            else if(isset($PD['pagenog'])){$page=$PD['pagenogo'];}
            else{$page=1;} 
     
        /*
         * SET DATA TO TEMPLATE
         */
        $this->tpl->set('sql_data_rows', $dbutil->setPaginationList($sql,$page,$results_per_page,$wsarr));
        /*
         * set table label
         */
        $this->tpl->set('table_columns_label_arr', array('ID','Raw Material Category','Description'));
        
        /*,;;
         * selectColArr for filter form
         */
        
        $this->tpl->set('selectColArr',$colArr);
                    
        /*
         * set pagination template
         */
        $this->crg->set('paginationListTemplate','factory/template/sql_based_crud_paginated_table.php');
               
        //////////////////////close//////////////////////////////////////  
      
         include_once $this->tpl->path .'/factory/form/crud_form_rawmaterialtype.php';
        
        
        $cus_form_data = Form_Elements::data($this->crg);
        include_once 'util/crud3_1.php';
        new Crud3($this->crg, $cus_form_data);
        $this->tpl->set('master_layout', 'layout_datepicker.php'); 
         //if crud is delivered at different point a template
        //Then  call that template and set to content
       
       ////$this->tpl->set('content', $this->tpl->fetch('modules/customer/manage_customer.php'));
    //////////////////////////////////////////////////////////////////////////////////
    //////////////////////////////on access condition failed then ///////////////////////////
    ////////////////////////////////////////////////////////////////////////////////            
    } else {
        if ($this->ses->get('user')['ID']) {
            $this->tpl->set('content', $this->tpl->fetch('modules/user/acess_failed_message.php'));
        } else {
            header('Location:' . $this->crg->get('route')['base_path'] . '/user/auth/login');
        }
    }
}  
    ///////////////////////////////////////
    function product() {

        if ($this->crg->get('wp') || $this->crg->get('rp')) {

            //////////////////////////////////////////////////////////
            //////////////////////////////access condition applied///
            ////////////////////////////////////////////////////////

           include_once 'util/DBUTIL.php';
           $dbutil = new DBUTIL($this->crg);

           $entityID = $this->ses->get('user')['entity_ID'];
           $userID = $this->ses->get('user')['ID'];
           $unit_tab = $this->crg->get('table_prefix') . 'unit';
           $product_tab = $this->crg->get('table_prefix') . 'product';
           $producttype_tab = $this->crg->get('table_prefix') . 'producttype';

            ////////////////////start//////////////////////////////////////////////

           //bUILD SQL 

            $whereString = '';

            $colArr = array(

                "$product_tab.ID",
                "$producttype_tab.ProductType",
                "$product_tab.ProductName",
                "$product_tab.Description",
                "$unit_tab.UnitName"
            );

            $this->tpl->set('FmData', $_POST);

            foreach($_POST as $k=>$v){
                if(strpos($k,'^')){
                 unset($_POST[$k]);
                }
                $_POST[str_replace('^','_',$k)] = $v;
            }
            $PD=$_POST;
            if($_POST['list']!=''){
                $this->tpl->set('FmData', NULL);
                $PD=NULL;
            }

            IF (count($PD) >= 2) {
                $wsarr = array();
                foreach ($colArr as $colNames) {
        		   if (strpos($colNames, 'Date') !== false) {
        
                        list($colNames,$x) = $dbutil->dateFilterFormat($colNames);
        
                    } else {
        
        		        $x = $dbutil->__mdsf($PD[str_replace('.','_',$colNames)]);
        
            }

                    if ('' != $x) {

                        $wsarr[] = $colNames . " LIKE '%" . $x . "%'";
                    }
                }
              IF (count($wsarr) >= 1) {
                 $whereString = ' AND '. implode(' AND ', $wsarr);
              }
            }

        $orderBy ="ORDER BY $product_tab.ID DESC";

         $sql = "SELECT "
                 . implode(',',$colArr)
                 . " FROM $product_tab LEFT JOIN $unit_tab ON $product_tab.unit_ID=$unit_tab.ID LEFT JOIN $producttype_tab ON $product_tab.producttype_ID=$producttype_tab.ID "
                 . " WHERE "
                // . " $product_tab.unit_ID=$unit_tab.ID AND "
                 . " $product_tab.entity_ID=$entityID "
                 . " $whereString "
                 . " $orderBy";

            $results_per_page = 50;     

                if(isset($PD['pageno'])){$page=$PD['pageno'];}

                else if(isset($PD['pagenof'])){$page=$PD['pagenofirst'];}

                else if(isset($PD['pagenop'])){$page=$PD['pagenoprev'];}

                else if(isset($PD['pagenon'])){$page=$PD['pagenonext'];}

                else if(isset($PD['pagenol'])){$page=$PD['pagenolast'];}

                else if(isset($PD['pagenog'])){$page=$PD['pagenogo'];}

                else{$page=1;} 


            /*

             * SET DATA TO TEMPLATE

             */

            $this->tpl->set('sql_data_rows', $dbutil->setPaginationList($sql,$page,$results_per_page,$wsarr));

            /*

             * set table label

             */

            $this->tpl->set('table_columns_label_arr', array('ID','Product Category','Product Name','Description','Unit'));

            /*,;;

             * selectColArr for filter form

             */
            $this->tpl->set('selectColArr',$colArr);
            
            /*

             * set pagination template

             */

            $this->crg->set('paginationListTemplate','factory/template/sql_based_crud_paginated_table.php');

            //////////////////////close//////////////////////////////////////  

            include_once $this->tpl->path .'/factory/form/crud_form_product.php';

            $cus_form_data = Form_Elements::data($this->crg);

            include_once 'util/crud3_1.php';

            new Crud3($this->crg, $cus_form_data);

            $this->tpl->set('master_layout', 'layout_datepicker.php'); 

        } else {

            if ($this->ses->get('user')['ID']) {
                $this->tpl->set('content', $this->tpl->fetch('modules/user/acess_failed_message.php'));
            } else {
                header('Location:' . $this->crg->get('route')['base_path'] . '/user/auth/login');
            }
        }
    } 
    //////////////////////////////////////
    function rawmaterial() {
    if ($this->crg->get('wp') || $this->crg->get('rp')) {
        
        ////////////////////////////////////////////////////////////
        //////////////////////////////access condition applied//////
        ////////////////////////////////////////////////////////////
      
        include_once 'util/DBUTIL.php';
        $dbutil = new DBUTIL($this->crg);
         
        $entityID = $this->ses->get('user')['entity_ID'];
        $userID = $this->ses->get('user')['ID'];
        
        $rawmaterial_tab = $this->crg->get('table_prefix') . 'rawmaterial';
        $rawmaterialtype_tab = $this->crg->get('table_prefix') . 'rawmaterialtype';
        $rawmaterialsubtype_tab = $this->crg->get('table_prefix') . 'rawmaterialsubtype';
        $unit_tab = $this->crg->get('table_prefix') . 'unit';
              
        ////////////////////start//////////////////////////////////////////////
                
       //bUILD SQL 
        $whereString = '';
        
        $colArr = array(
            "$rawmaterial_tab.ID", 
            "$rawmaterialtype_tab.RawMaterialType",
            "$rawmaterialsubtype_tab.RawMaterialSubType",
            "$rawmaterial_tab.RMName",
            "$unit_tab.UnitName"
        );
        
        $this->tpl->set('FmData', $_POST);
        foreach($_POST as $k=>$v){
            if(strpos($k,'^')){
                unset($_POST[$k]);
            }
            $_POST[str_replace('^','_',$k)] = $v;
        }
        $PD=$_POST;
        if($_POST['list']!=''){
            $this->tpl->set('FmData', NULL);
            $PD=NULL;
        }

        IF (count($PD) >= 2) {
            $wsarr = array();
            foreach ($colArr as $colNames) {

       if (strpos($colNames, 'Date') !== false) {
            list($colNames,$x) = $dbutil->dateFilterFormat($colNames);
        } else {
            $x = $dbutil->__mdsf($PD[str_replace('.','_',$colNames)]);
        }

                if ('' != $x) {
                    $wsarr[] = $colNames . " LIKE '%" . $x . "%'";
                }
            }
            
          IF (count($wsarr) >= 1) {
             $whereString = ' WHERE '. implode(' AND ', $wsarr);

          }
        }
        
        $orderBy ="ORDER BY $rawmaterial_tab.ID DESC";
        
     $sql = "SELECT "
             . implode(',',$colArr)
             . " FROM $rawmaterial_tab,$rawmaterialtype_tab,$rawmaterialsubtype_tab,$unit_tab "
             . " WHERE "
             . " $rawmaterial_tab.rawmaterialtype_ID=$rawmaterialtype_tab.ID AND "
             . " $rawmaterial_tab.rawmaterialsubtype_ID=$rawmaterialsubtype_tab.ID AND "
             . " $rawmaterial_tab.unit_ID=$unit_tab.ID AND "
             . " $rawmaterial_tab.entity_ID=$entityID "
             . " $whereString "
             . " $orderBy";
     
        $results_per_page = 50;     
        
            if(isset($PD['pageno'])){$page=$PD['pageno'];}
            else if(isset($PD['pagenof'])){$page=$PD['pagenofirst'];}
            else if(isset($PD['pagenop'])){$page=$PD['pagenoprev'];}
            else if(isset($PD['pagenon'])){$page=$PD['pagenonext'];}
            else if(isset($PD['pagenol'])){$page=$PD['pagenolast'];}
            else if(isset($PD['pagenog'])){$page=$PD['pagenogo'];}
            else{$page=1;} 
     
        /*
         * SET DATA TO TEMPLATE
         */
        $this->tpl->set('sql_data_rows', $dbutil->setPaginationList($sql,$page,$results_per_page,$wsarr));
        /*
         * set table label
         */
        $this->tpl->set('table_columns_label_arr', array('ID','Raw Material Category','Raw Material SubCategory','Raw Material','Unit of Measure'));
        
        /*,;;
         * selectColArr for filter form
         */
        
        $this->tpl->set('selectColArr',$colArr);
                    
        /*
         * set pagination template
         */
        $this->crg->set('paginationListTemplate','factory/template/sql_based_crud_paginated_table.php');
               
        //////////////////////close//////////////////////////////////////  
      
         include_once $this->tpl->path .'/factory/form/crud_form_rawmaterial.php';
        
        
        $cus_form_data = Form_Elements::data($this->crg);
        include_once 'util/crud3_1.php';
        new Crud3($this->crg, $cus_form_data);
        $this->tpl->set('master_layout', 'layout_datepicker.php'); 
         //if crud is delivered at different point a template
        //Then  call that template and set to content
       
       ////$this->tpl->set('content', $this->tpl->fetch('modules/customer/manage_customer.php'));
    //////////////////////////////////////////////////////////////////////////////////
    //////////////////////////////on access condition failed then ///////////////////////////
    ////////////////////////////////////////////////////////////////////////////////            
    } else {
        if ($this->ses->get('user')['ID']) {
            $this->tpl->set('content', $this->tpl->fetch('modules/user/acess_failed_message.php'));
        } else {
            header('Location:' . $this->crg->get('route')['base_path'] . '/user/auth/login');
        }
    }
} 
    //////////////////////////////////////
    function process(){
     if ($this->crg->get('wp') || $this->crg->get('rp')) {
 ////////////////////////////////////////////////////////////////////////////////
 //////////////////////////////access condition applied//////////////////////////
 ////////////////////////////////////////////////////////////////////////////////    
            
            include_once 'util/DBUTIL.php';
            $dbutil = new DBUTIL($this->crg);
             
            $entityID = $this->ses->get('user')['entity_ID'];
            $userID = $this->ses->get('user')['ID'];
            
            $pdt_table = $this->crg->get('table_prefix') . 'product';
            $processdetail_tab = $this->crg->get('table_prefix') . 'ProcessDetail';
            $processmaster_tab = $this->crg->get('table_prefix') . 'ProcessMaster';
            
           
           //product table data for partno
           
            $pdt_sql = "SELECT ID,ProductName FROM $pdt_table";
            $stmt = $this->db->prepare($pdt_sql);            
            $stmt->execute();
            $pdt_data  = $stmt->fetchAll();	
            $this->tpl->set('pdt_data', $pdt_data);
            
           
            $this->tpl->set('page_title', 'Process');	          
            $this->tpl->set('page_header', 'Production');
            //Add Role when u submit the add role form
            $thisPageURL = $this->crg->get('route')['base_path'] . '/' . $this->crg->get('route')['module'] . '/' . $this->crg->get('route')['controller'] . '/' . $this->crg->get('route')['action'];

            $crud_string = null;
	
            if (isset($_POST['req_from_list_view'])) {
                $crud_string = strtolower($_POST['req_from_list_view']);
            }              
            
            //Edit submit
            if (!empty($_POST['edit_submit_button']) && $_POST['edit_submit_button'] == 'edit') {
                $crud_string = 'editsubmit';
            }

            //Add submit
            if (!empty($_POST['add_submit_button']) && $_POST['add_submit_button'] == 'add') {
                $crud_string = 'addsubmit';
            }


            switch ($crud_string) {
                 case 'delete':                    
                      $data = trim($_POST['ycs_ID']);
                      // var_dump($data); 
                       
                       
                    if (!$data) {
                        $this->tpl->set('message', 'Please select any one ID to '.$crud_string.'!');
                        $this->tpl->set('label', 'List');
                        $this->tpl->set('content', $this->tpl->fetch('factory/template/form_button_link.php'));
                       
                    }
                     
                     $sqldetdelete="Delete $processdetail_tab,$processmaster_tab from $processmaster_tab
                                        LEFT JOIN  $processdetail_tab ON $processmaster_tab.ID=$processdetail_tab.ProcessMaster_ID 
                                        where $processdetail_tab.ProcessMaster_ID=$data"; 
                        $stmt = $this->db->prepare($sqldetdelete);            
                        
                        if($stmt->execute()){
                        $this->tpl->set('message', 'Process deleted successfully');
                        header('Location:' . $this->crg->get('route')['base_path'] . '/admin/mast/process');
                        // $this->tpl->set('label', 'List');
                        // $this->tpl->set('content', $this->tpl->fetch('factory/template/form_button_link.php'));
                        }
            break;
                case 'view':                    
                    $data = trim($_POST['ycs_ID']);
                 
                    if (!$data) {
                        $this->tpl->set('message', 'Please select any one ID to view!');
                        $this->tpl->set('label', 'List');
                        $this->tpl->set('content', $this->tpl->fetch('factory/template/form_button_link.php'));
                        break;
                    }
                    
                    //mode of form submit
                    $this->tpl->set('mode', 'view');
                    //set id to edit $ycs_ID
                    $this->tpl->set('ycs_ID', $data);         
                                
                    $sqlsrr = "SELECT * FROM `$processdetail_tab`,`$processmaster_tab` WHERE `$processdetail_tab`.`ProcessMaster_ID`=`$processmaster_tab`.`ID` AND `$processdetail_tab`.`ProcessMaster_ID` = '$data'";                    
                    $process_data = $dbutil->getSqlData($sqlsrr); 
                    
                    //edit option     
                    $this->tpl->set('message', 'You can view Process form');
                    $this->tpl->set('page_header', 'Production');
                    $this->tpl->set('FmData', $process_data); 
                    
                    $this->tpl->set('content', $this->tpl->fetch('factory/form/process_form.php'));                    
                    break;
                
                case 'edit':                    
                    $data = trim($_POST['ycs_ID']);
               // var_dump($data);
                    if (!$data) {
                        $this->tpl->set('message', 'Please select any one ID to edit!');
                        $this->tpl->set('label', 'List');
                        $this->tpl->set('content', $this->tpl->fetch('factory/template/form_button_link.php'));
                        break;
                    }
                    
                    //mode of form submit
                    $this->tpl->set('mode', 'edit');
                    //set id to edit $ycs_ID
                    $this->tpl->set('ycs_ID', $data);         
                                
                    $sqlsrr = "SELECT  * FROM `$processdetail_tab`,`$processmaster_tab` WHERE `$processdetail_tab`.`ProcessMaster_ID`=`$processmaster_tab`.`ID` AND `$processdetail_tab`.`ProcessMaster_ID` = '$data'";                    
                    $process_data = $dbutil->getSqlData($sqlsrr); 

                    //edit option     
                    $this->tpl->set('message', 'You can edit Process form');
                    $this->tpl->set('page_header', 'Production');
                    $this->tpl->set('FmData', $process_data); 
                    
                    $this->tpl->set('content', $this->tpl->fetch('factory/form/process_form.php'));                    
                    break;
                
                case 'editsubmit':             
                    $data = trim($_POST['ycs_ID']);
                    
                    //mode of form submit
                    $this->tpl->set('mode', 'edit');
                    //set id to edit $ycs_ID
                    $this->tpl->set('ycs_ID', $data);

                    //Post data
                    include_once 'util/genUtil.php';
                    $util = new GenUtil();
                    $form_post_data = $util->arrFltr($_POST);
                
                    //Build SQL now
                    $sqldet_del = "DELETE FROM $processdetail_tab WHERE ProcessMaster_ID=$data";
                    $stmt = $this->db->prepare($sqldet_del);
                    $stmt->execute();   
                            
                            try{
                            
                            $productID= $form_post_data['product_ID'];
                           
                            $sql_update="Update $processmaster_tab set product_ID='$productID' WHERE ID=$data";
                            $stmt1 = $this->db->prepare($sql_update);
                            $stmt1->execute(); 
                        $entry_count = 1;
                        FOR ($entry_count; $entry_count <= $form_post_data['maxCount'];) {
                                
                                $process ='ItemName_' . $entry_count;
                               
                                $vals = "'" . $data . "'," .
                                        "'" . $form_post_data[$process] . "'";
  
                                $sql2 = "INSERT INTO $processdetail_tab
                                        ( 
                                            `ProcessMaster_ID`, 
                                            `Process`
                                        ) 
                                VALUES ($vals)";

                                $stmt = $this->db->prepare($sql2);
                                $stmt->execute();
                            //increment here
                            $entry_count++;
                            }
                       
                            $this->tpl->set('message', 'Process form edited successfully!');   
                            header('Location:' . $this->crg->get('route')['base_path'] . '/admin/mast/process');
                            // $this->tpl->set('label', 'List');
                            // $this->tpl->set('content', $this->tpl->fetch('factory/template/form_button_link.php'));
                            } catch (Exception $exc) {
                             //edit failed option
                            $this->tpl->set('message', 'Failed to edit, try again!');
                            $this->tpl->set('FmData', $form_post_data);
                            $this->tpl->set('content', $this->tpl->fetch('factory/form/process_form.php'));
                            }

                    break;

                case 'addsubmit':
                     if (isset($crud_string)) {
                         
                        $form_post_data = $dbutil->arrFltr($_POST);
                        
                       // var_dump($_POST);
                        
                        $entry_count = 1;
                       
                            if (isset($form_post_data['product_ID'])) {
                           
                                        $val = "'" . $form_post_data['product_ID'] . "'," .
                                               "'" .  $this->ses->get('user')['entity_ID'] . "'," .
                                               "'" .  $this->ses->get('user')['ID'] . "'";

                              $sql = "INSERT INTO `" . $this->crg->get('table_prefix') . "ProcessMaster`
                                            ( 
                                            `product_ID`,
                                            `entity_ID`,
                                            `users_ID`
                                            ) 
                                        VALUES ( $val )";
                                  $stmt = $this->db->prepare($sql);
                                  
                                  
                    if ($stmt->execute()) { 
                        $lastInsertedID = $this->db->lastInsertId();
                        FOR ($entry_count; $entry_count <= $form_post_data['maxCount'];) {
                               
                                $process ='ItemName_' . $entry_count;

                                $vals = "'" . $lastInsertedID . "'," .
                                        "'" . $form_post_data[$process] . "'" ;
                                 
                              $sql2 = "INSERT INTO $processdetail_tab
                                        ( 
                                            `ProcessMaster_ID`, 
                                            `Process`
                                        ) 
                                VALUES ($vals)";

                                 // this need to be changed in to transaction type
                                
                                $stmt = $this->db->prepare($sql2);
                                $stmt->execute();
                                  //increment here
                                $entry_count++;
                                
                            }
                    }
                        }
                        $this->tpl->set('mode', 'add');
                        $this->tpl->set('message', '- Success -');
                        header('Location:' . $this->crg->get('route')['base_path'] . '/admin/mast/process');
                       // $this->tpl->set('content', $this->tpl->fetch('factory/form/process_form.php'));
                     } else {
                            //edit option
                            //if submit failed to insert form
                            $this->tpl->set('message', 'Failed to submit!');
                            $this->tpl->set('FmData', $form_post_data);
                            $this->tpl->set('content', $this->tpl->fetch('factory/form/process_form.php'));
                     }
                    break;
                case 'add':
                    $this->tpl->set('mode', 'add');
	                $this->tpl->set('page_header', 'Production');
                    $this->tpl->set('content', $this->tpl->fetch('factory/form/process_form.php'));
                    break;

                default:
                    /*
                     * List form
                     */
                     
                    ////////////////////start//////////////////////////////////////////////
                    
           //bUILD SQL 
            $whereString = '';
            
         $colArr = array(
                "$processmaster_tab.ID",
                "$pdt_table.ProductName"
            );
            
            $this->tpl->set('FmData', $_POST);
            foreach($_POST as $k=>$v){
                if(strpos($k,'^')){
                    unset($_POST[$k]);
                }
                $_POST[str_replace('^','_',$k)] = $v;
            }
            $PD=$_POST;
            if($_POST['list']!=''){
                $this->tpl->set('FmData', NULL);
                $PD=NULL;
            }

            IF (count($PD) >= 2) {
                $wsarr = array();
                foreach ($colArr as $colNames) {

	            if (strpos($colNames, 'DATE') !== false) {
                    list($colNames,$x) = $dbutil->dateFilterFormat($colNames);                    
                }else {
        		    $x = $dbutil->__mdsf($PD[str_replace('.','_',$colNames)]);        		    
                }

                  if ('' != $x) {
                   $wsarr[] = $colNames . " LIKE '%" . $x . "%'";
                    }
                }
                
           IF (count($wsarr) >= 1) {
                $whereString = ' AND '. implode(' AND ', $wsarr);
            }
           } else {
             $whereString ="ORDER BY $processmaster_tab.ID DESC";
           }
            
        $sql = "SELECT "
                    . implode(',',$colArr)
                    . " FROM $processmaster_tab,$pdt_table "
                    . " WHERE "
                    . " $pdt_table.ID= $processmaster_tab.product_ID AND "
                    . " $processmaster_tab.entity_ID = $entityID"
                    . " $whereString";
            
         
    
                $results_per_page = 50;     
            
                if(isset($PD['pageno'])){$page=$PD['pageno'];}
                else if(isset($PD['pagenof'])){$page=$PD['pagenofirst'];}
                else if(isset($PD['pagenop'])){$page=$PD['pagenoprev'];}
                else if(isset($PD['pagenon'])){$page=$PD['pagenonext'];}
                else if(isset($PD['pagenol'])){$page=$PD['pagenolast'];}
                else if(isset($PD['pagenog'])){$page=$PD['pagenogo'];}
                else{$page=1;} 
            /*
             * SET DATA TO TEMPLATE
                        */
           $this->tpl->set('sql_data_rows', $dbutil->setPaginationList($sql,$page,$results_per_page,$wsarr));
         
         
            $this->tpl->set('table_columns_label_arr', array('ID','Product Name'));
            
            /*
             * selectColArr for filter form
             */
            
            $this->tpl->set('selectColArr',$colArr);
                        
            /*
             * set pagination template
             */
            $this->crg->set('paginationListTemplate','factory/template/sql_based_crud_paginated_table.php');
                   
            //////////////////////close//////////////////////////////////////  
                     
                    include_once $this->tpl->path . '/factory/form/crud_form_process.php';
                    $cus_form_data = Form_Elements::data($this->crg);
                    include_once 'util/crud3_1.php';
                    new Crud3($this->crg, $cus_form_data);
                    break;
            }

	    ///////////////Use different template////////////////////
	    $this->tpl->set('master_layout', 'layout_datepicker.php'); 
////////////////////////////////////////////////////////////////////////////////
//////////////////////////////on access condition failed then //////////////////
//////////////////////////////////////////////////////////////////////////////// 
     } else {
             if ($this->ses->get('user')['ID']) {
                 $this->tpl->set('content', $this->tpl->fetch('modules/user/acess_failed_message.php'));
             } else {
                 header('Location:' . $this->crg->get('route')['base_path'] . '/user/auth/login');
             }
         }
    }
    /////////////////////////////////////
    function bomprocess(){
     if ($this->crg->get('wp') || $this->crg->get('rp')) {
             
            ////////////////////////////////////////////////////////////////////////////////
            //////////////////////////////access condition applied//////////////////////////
            ////////////////////////////////////////////////////////////////////////////////    
            
            include_once 'util/DBUTIL.php';
            $dbutil = new DBUTIL($this->crg);
             
            $entityID = $this->ses->get('user')['entity_ID'];
            $userID = $this->ses->get('user')['ID'];
            
            $pdt_table = $this->crg->get('table_prefix') . 'product';
            $rawmaterial_table = $this->crg->get('table_prefix') . 'rawmaterial';
            $unit_table = $this->crg->get('table_prefix') . 'unit';
            $processdetail_tab = $this->crg->get('table_prefix') . 'ProcessDetail';
            $processmaster_tab = $this->crg->get('table_prefix') . 'ProcessMaster';
            $bomprocessdetail_tab = $this->crg->get('table_prefix') . 'BOMProcessDetail';
            $bomprocessmaster_tab = $this->crg->get('table_prefix') . 'BOMProcessMaster';
           
           //product table data 
           
            $pdt_sql = "SELECT ID,ProductName FROM $pdt_table";
            $stmt = $this->db->prepare($pdt_sql);            
            $stmt->execute();
            $pdt_data  = $stmt->fetchAll();	
            $this->tpl->set('pdt_data', $pdt_data);
            
            //process table data
           
            $pdt_sql = "SELECT ID,Process FROM $processdetail_tab";
            $stmt = $this->db->prepare($pdt_sql);            
            $stmt->execute();
            $process_data  = $stmt->fetchAll();	
            $this->tpl->set('process_data', $process_data);
            
            //rawmaterial table data
           
            $pdt_sql = "SELECT ID,RMName FROM $rawmaterial_table";
            $stmt = $this->db->prepare($pdt_sql);            
            $stmt->execute();
            $rawmaterial_data  = $stmt->fetchAll();	
            $this->tpl->set('rawmaterial_data', $rawmaterial_data);
            
            //unit table data
           
            $pdt_sql = "SELECT ID,UnitName FROM $unit_table";
            $stmt = $this->db->prepare($pdt_sql);            
            $stmt->execute();
            $unit_data  = $stmt->fetchAll();	
            $this->tpl->set('unit_data', $unit_data);
            
           
            $this->tpl->set('page_title', 'BOM Process');	          
            $this->tpl->set('page_header', 'Production');
            //Add Role when u submit the add role form
            $thisPageURL = $this->crg->get('route')['base_path'] . '/' . $this->crg->get('route')['module'] . '/' . $this->crg->get('route')['controller'] . '/' . $this->crg->get('route')['action'];

            $crud_string = null;
	
            if (isset($_POST['req_from_list_view'])) {
                $crud_string = strtolower($_POST['req_from_list_view']);
            }              
            
            //Edit submit
            if (!empty($_POST['edit_submit_button']) && $_POST['edit_submit_button'] == 'edit') {
                $crud_string = 'editsubmit';
            }

            //Add submit
            if (!empty($_POST['add_submit_button']) && $_POST['add_submit_button'] == 'add') {
                $crud_string = 'addsubmit';
            }


            switch ($crud_string) {
                 case 'delete':                    
                      $data = trim($_POST['ycs_ID']);
                      // var_dump($data); 
                       
                       
                    if (!$data) {
                        $this->tpl->set('message', 'Please select any one ID to '.$crud_string.'!');
                        $this->tpl->set('label', 'List');
                        $this->tpl->set('content', $this->tpl->fetch('factory/template/form_button_link.php'));
                       
                    }
                     
                     $sqldetdelete="Delete $bomprocessdetail_tab,$bomprocessmaster_tab from $bomprocessmaster_tab
                                        LEFT JOIN  $bomprocessdetail_tab ON $bomprocessmaster_tab.ID=$bomprocessdetail_tab.BOMProcessMaster_ID 
                                        where $bomprocessdetail_tab.BOMProcessMaster_ID=$data"; 
                        $stmt = $this->db->prepare($sqldetdelete);            
                        
                        if($stmt->execute()){
                        $this->tpl->set('message', 'Process deleted successfully');
                        header('Location:' . $this->crg->get('route')['base_path'] . '/admin/mast/bomprocess');
                        // $this->tpl->set('label', 'List');
                        // $this->tpl->set('content', $this->tpl->fetch('factory/template/form_button_link.php'));
                        }
            break;
                case 'view':                    
                    $data = trim($_POST['ycs_ID']);
                 
                    if (!$data) {
                        $this->tpl->set('message', 'Please select any one ID to view!');
                        $this->tpl->set('label', 'List');
                        $this->tpl->set('content', $this->tpl->fetch('factory/template/form_button_link.php'));
                        break;
                    }
                    
                    //mode of form submit
                    $this->tpl->set('mode', 'view');
                    //set id to edit $ycs_ID
                    $this->tpl->set('ycs_ID', $data);         
                                
                    $sqlsrr = "SELECT * FROM `$bomprocessdetail_tab`,`$bomprocessmaster_tab` WHERE `$bomprocessdetail_tab`.`BOMProcessMaster_ID`=`$bomprocessmaster_tab`.`ID` AND `$bomprocessdetail_tab`.`BOMProcessMaster_ID` = '$data'";                    
                    $process_data = $dbutil->getSqlData($sqlsrr); 
                    
                    //edit option     
                    $this->tpl->set('message', 'You can view Process BOM form');
                    $this->tpl->set('page_header', 'Production');
                    $this->tpl->set('FmData', $process_data); 
                    
                    $this->tpl->set('content', $this->tpl->fetch('factory/form/bomprocess_form.php'));                    
                    break;
                
                case 'edit':                    
                    $data = trim($_POST['ycs_ID']);
               // var_dump($data);
                    if (!$data) {
                        $this->tpl->set('message', 'Please select any one ID to edit!');
                        $this->tpl->set('label', 'List');
                        $this->tpl->set('content', $this->tpl->fetch('factory/template/form_button_link.php'));
                        break;
                    }
                    
                    //mode of form submit
                    $this->tpl->set('mode', 'edit');
                    //set id to edit $ycs_ID
                    $this->tpl->set('ycs_ID', $data);         
                                
                    $sqlsrr = "SELECT  * FROM `$bomprocessdetail_tab`,`$bomprocessmaster_tab` WHERE `$bomprocessdetail_tab`.`BOMProcessMaster_ID`=`$bomprocessmaster_tab`.`ID` AND `$bomprocessdetail_tab`.`BOMProcessMaster_ID` = '$data'";                    
                    $process_data = $dbutil->getSqlData($sqlsrr); 

                    //edit option     
                    $this->tpl->set('message', 'You can edit Process BOM form');
                    $this->tpl->set('page_header', 'Production');
                    $this->tpl->set('FmData', $process_data); 
                    
                    $this->tpl->set('content', $this->tpl->fetch('factory/form/bomprocess_form.php'));                    
                    break;
                
                case 'editsubmit':             
                    $data = trim($_POST['ycs_ID']);
                    
                    //mode of form submit
                    $this->tpl->set('mode', 'edit');
                    //set id to edit $ycs_ID
                    $this->tpl->set('ycs_ID', $data);

                    //Post data
                    include_once 'util/genUtil.php';
                    $util = new GenUtil();
                    $form_post_data = $util->arrFltr($_POST);
                
                    //Build SQL now
                    $sqldet_del = "DELETE FROM $bomprocessdetail_tab WHERE BOMProcessMaster_ID=$data";
                    $stmt = $this->db->prepare($sqldet_del);
                    $stmt->execute();   
                            
                            try{
                            
                            $productID= $form_post_data['product_ID'];
                           
                            $sql_update="Update $bomprocessmaster_tab set product_ID='$productID' WHERE ID=$data";
                            $stmt1 = $this->db->prepare($sql_update);
                            $stmt1->execute(); 
                        $entry_count = 1;
                        FOR ($entry_count; $entry_count <= $form_post_data['maxCount'];) {
                                
                                $process_id ='ItemName_' . $entry_count;
                                $rawmaterial_id ='rawmaterial_' . $entry_count;
                                $quantity ='Quantity_' . $entry_count;
                                $unit_id ='unit_' . $entry_count;

                               
                                $vals = "'" . $data . "'," .
                                        "'" . $form_post_data[$process_id] . "'," .
                                        "'" . $form_post_data[$rawmaterial_id] . "'," .
                                        "'" . $form_post_data[$quantity] . "'," .
                                        "'" . $form_post_data[$unit_id] . "'" ;
  
                                $sql2 = "INSERT INTO $bomprocessdetail_tab
                                        ( 
                                            
                                            `BOMProcessMaster_ID`, 
                                            `process_ID`,
                                            `rawmaterial_ID`,
                                            `Quantity`,
                                            `unit_ID`
                                        ) 
                                VALUES ($vals)";

                                $stmt = $this->db->prepare($sql2);
                                $stmt->execute();
                            //increment here
                            $entry_count++;
                            }
                       
                            $this->tpl->set('message', 'Process BOM form edited successfully!');   
                            header('Location:' . $this->crg->get('route')['base_path'] . '/admin/mast/bomprocess');
                            // $this->tpl->set('label', 'List');
                            // $this->tpl->set('content', $this->tpl->fetch('factory/template/form_button_link.php'));
                            } catch (Exception $exc) {
                             //edit failed option
                            $this->tpl->set('message', 'Failed to edit, try again!');
                            $this->tpl->set('FmData', $form_post_data);
                            $this->tpl->set('content', $this->tpl->fetch('factory/form/bomprocess_form.php'));
                            }

                    break;

                case 'addsubmit':
                     if (isset($crud_string)) {
                         
                        $form_post_data = $dbutil->arrFltr($_POST);
                        
                       // var_dump($_POST);
                        
                        $entry_count = 1;
                       
                            if (isset($form_post_data['product_ID'])) {
                           
                                        $val = "'" . $form_post_data['product_ID'] . "'," .
                                               "'" .  $this->ses->get('user')['entity_ID'] . "'," .
                                               "'" .  $this->ses->get('user')['ID'] . "'";

                              $sql = "INSERT INTO `" . $this->crg->get('table_prefix') . "BOMProcessMaster`
                                            ( 
                                            `product_ID`,
                                            `entity_ID`,
                                            `users_ID`
                                            ) 
                                        VALUES ( $val )";
                                  $stmt = $this->db->prepare($sql);
                                  
                                  
                    if ($stmt->execute()) { 
                        $lastInsertedID = $this->db->lastInsertId();
                        FOR ($entry_count; $entry_count <= $form_post_data['maxCount'];) {
                               
                                $process_id ='ItemName_' . $entry_count;
                                $rawmaterial_id ='rawmaterial_' . $entry_count;
                                $quantity ='Quantity_' . $entry_count;
                                $unit_id ='unit_' . $entry_count;

                                $vals = "'" . $lastInsertedID . "'," .
                                        "'" . $form_post_data[$process_id] . "'," .
                                        "'" . $form_post_data[$rawmaterial_id] . "'," .
                                        "'" . $form_post_data[$quantity] . "'," .
                                        "'" . $form_post_data[$unit_id] . "'" ;
                                 
                              $sql2 = "INSERT INTO $bomprocessdetail_tab
                                        ( 
                                            `BOMProcessMaster_ID`, 
                                            `process_ID`,
                                            `rawmaterial_ID`,
                                            `Quantity`,
                                            `unit_ID`
                                        ) 
                                VALUES ($vals)";

                                 // this need to be changed in to transaction type
                                
                                $stmt = $this->db->prepare($sql2);
                                $stmt->execute();
                                  //increment here
                                $entry_count++;
                                
                            }
                    }
                        }
                        $this->tpl->set('mode', 'add');
                        $this->tpl->set('message', '- Success -');
                        header('Location:' . $this->crg->get('route')['base_path'] . '/admin/mast/bomprocess');
                       // $this->tpl->set('content', $this->tpl->fetch('factory/form/bomprocess_form.php'));
                     } else {
                            //edit option
                            //if submit failed to insert form
                            $this->tpl->set('message', 'Failed to submit!');
                            $this->tpl->set('FmData', $form_post_data);
                            $this->tpl->set('content', $this->tpl->fetch('factory/form/bomprocess_form.php'));
                     }
                    break;
                case 'add':
                    $this->tpl->set('mode', 'add');
	                $this->tpl->set('page_header', 'Production');
                    $this->tpl->set('content', $this->tpl->fetch('factory/form/bomprocess_form.php'));
                    break;

                default:
                    /*
                     * List form
                     */
                     
                    ////////////////////start//////////////////////////////////////////////
                    
           //bUILD SQL 
            $whereString = '';
            
         $colArr = array(
                "$bomprocessmaster_tab.ID",
                "$pdt_table.ProductName"
            );
            
            $this->tpl->set('FmData', $_POST);
            foreach($_POST as $k=>$v){
                if(strpos($k,'^')){
                    unset($_POST[$k]);
                }
                $_POST[str_replace('^','_',$k)] = $v;
            }
            $PD=$_POST;
            if($_POST['list']!=''){
                $this->tpl->set('FmData', NULL);
                $PD=NULL;
            }

            IF (count($PD) >= 2) {
                $wsarr = array();
                foreach ($colArr as $colNames) {

	            if (strpos($colNames, 'DATE') !== false) {
                    list($colNames,$x) = $dbutil->dateFilterFormat($colNames);                    
                }else {
        		    $x = $dbutil->__mdsf($PD[str_replace('.','_',$colNames)]);        		    
                }

                  if ('' != $x) {
                   $wsarr[] = $colNames . " LIKE '%" . $x . "%'";
                    }
                }
                
           IF (count($wsarr) >= 1) {
                $whereString = ' AND '. implode(' AND ', $wsarr);
            }
           } else {
             $whereString ="ORDER BY $bomprocessmaster_tab.ID DESC";
           }
            
        $sql = "SELECT "
                    . implode(',',$colArr)
                    . " FROM $bomprocessmaster_tab,$pdt_table "
                    . " WHERE "
                    . " $pdt_table.ID= $bomprocessmaster_tab.product_ID AND "
                    . " $bomprocessmaster_tab.entity_ID = $entityID"
                    . " $whereString";
            
         
    
                $results_per_page = 50;     
            
                if(isset($PD['pageno'])){$page=$PD['pageno'];}
                else if(isset($PD['pagenof'])){$page=$PD['pagenofirst'];}
                else if(isset($PD['pagenop'])){$page=$PD['pagenoprev'];}
                else if(isset($PD['pagenon'])){$page=$PD['pagenonext'];}
                else if(isset($PD['pagenol'])){$page=$PD['pagenolast'];}
                else if(isset($PD['pagenog'])){$page=$PD['pagenogo'];}
                else{$page=1;} 
            /*
             * SET DATA TO TEMPLATE
                        */
           $this->tpl->set('sql_data_rows', $dbutil->setPaginationList($sql,$page,$results_per_page,$wsarr));
         
         
            $this->tpl->set('table_columns_label_arr', array('ID','Product Name'));
            
            /*
             * selectColArr for filter form
             */
            
            $this->tpl->set('selectColArr',$colArr);
                        
            /*
             * set pagination template
             */
            $this->crg->set('paginationListTemplate','factory/template/sql_based_crud_paginated_table.php');
                   
            //////////////////////close//////////////////////////////////////  
                     
                    include_once $this->tpl->path . '/factory/form/crud_form_bomprocess.php';
                    $cus_form_data = Form_Elements::data($this->crg);
                    include_once 'util/crud3_1.php';
                    new Crud3($this->crg, $cus_form_data);
                    break;
            }

	    ///////////////Use different template////////////////////
	    $this->tpl->set('master_layout', 'layout_datepicker.php'); 
////////////////////////////////////////////////////////////////////////////////
//////////////////////////////on access condition failed then //////////////////
//////////////////////////////////////////////////////////////////////////////// 
     } else {
             if ($this->ses->get('user')['ID']) {
                 $this->tpl->set('content', $this->tpl->fetch('modules/user/acess_failed_message.php'));
             } else {
                 header('Location:' . $this->crg->get('route')['base_path'] . '/user/auth/login');
             }
         }
    }
    ////////////////////////////////////
     function rawmaterialsubtype() {
        if ($this->crg->get('wp') || $this->crg->get('rp')) {
        
        ////////////////////////////////////////////////////////////
        //////////////////////////////access condition applied//////
        ////////////////////////////////////////////////////////////
      
        include_once 'util/DBUTIL.php';
        $dbutil = new DBUTIL($this->crg);
         
        $entityID = $this->ses->get('user')['entity_ID'];
        $userID = $this->ses->get('user')['ID'];
        
        $rawmaterialtype_tab = $this->crg->get('table_prefix') . 'rawmaterialtype';
        $rawmaterialsubtype_tab = $this->crg->get('table_prefix') . 'rawmaterialsubtype';
              
        ////////////////////start//////////////////////////////////////////////
                
       //bUILD SQL 
        $whereString = '';
        
        $colArr = array(
            "$rawmaterialsubtype_tab.ID", 
            "$rawmaterialtype_tab.RawMaterialType",
            "$rawmaterialsubtype_tab.RawMaterialSubType",
            "$rawmaterialsubtype_tab.Description"
        );
        
        $this->tpl->set('FmData', $_POST);
        foreach($_POST as $k=>$v){
            if(strpos($k,'^')){
                unset($_POST[$k]);
            }
            $_POST[str_replace('^','_',$k)] = $v;
        }
        $PD=$_POST;
        if($_POST['list']!=''){
            $this->tpl->set('FmData', NULL);
            $PD=NULL;
        }

        IF (count($PD) >= 2) {
            $wsarr = array();
            foreach ($colArr as $colNames) {

       if (strpos($colNames, 'Date') !== false) {
            list($colNames,$x) = $dbutil->dateFilterFormat($colNames);
        } else {
            $x = $dbutil->__mdsf($PD[str_replace('.','_',$colNames)]);
        }

                if ('' != $x) {
                    $wsarr[] = $colNames . " LIKE '%" . $x . "%'";
                }
            }
            
          IF (count($wsarr) >= 1) {
             $whereString = ' WHERE '. implode(' AND ', $wsarr);

          }
        }
        
        $orderBy ="ORDER BY $rawmaterialsubtype_tab.ID DESC";
        
     $sql = "SELECT "
             . implode(',',$colArr)
             . " FROM $rawmaterialsubtype_tab LEFT JOIN $rawmaterialtype_tab ON $rawmaterialsubtype_tab.rawmaterialtype_ID=$rawmaterialtype_tab.ID "
             . " WHERE "
             . " $rawmaterialsubtype_tab.entity_ID=$entityID "
             . " $whereString "
             . " $orderBy";
     
        $results_per_page = 50;     
        
            if(isset($PD['pageno'])){$page=$PD['pageno'];}
            else if(isset($PD['pagenof'])){$page=$PD['pagenofirst'];}
            else if(isset($PD['pagenop'])){$page=$PD['pagenoprev'];}
            else if(isset($PD['pagenon'])){$page=$PD['pagenonext'];}
            else if(isset($PD['pagenol'])){$page=$PD['pagenolast'];}
            else if(isset($PD['pagenog'])){$page=$PD['pagenogo'];}
            else{$page=1;} 
     
        /*
         * SET DATA TO TEMPLATE
         */
        $this->tpl->set('sql_data_rows', $dbutil->setPaginationList($sql,$page,$results_per_page,$wsarr));
        /*
         * set table label
         */
        $this->tpl->set('table_columns_label_arr', array('ID','Raw Material Category','Raw Material SubCategory','Description'));
        
        /*,;;
         * selectColArr for filter form
         */
        
        $this->tpl->set('selectColArr',$colArr);
                    
        /*
         * set pagination template
         */
        $this->crg->set('paginationListTemplate','factory/template/sql_based_crud_paginated_table.php');
               
        //////////////////////close//////////////////////////////////////  
      
         include_once $this->tpl->path .'/factory/form/crud_form_rawmaterialsubtype.php';
        
        
        $cus_form_data = Form_Elements::data($this->crg);
        include_once 'util/crud3_1.php';
        new Crud3($this->crg, $cus_form_data);
        $this->tpl->set('master_layout', 'layout_datepicker.php'); 
         //if crud is delivered at different point a template
        //Then  call that template and set to content
       
       ////$this->tpl->set('content', $this->tpl->fetch('modules/customer/manage_customer.php'));
    //////////////////////////////////////////////////////////////////////////////////
    //////////////////////////////on access condition failed then ///////////////////////////
    ////////////////////////////////////////////////////////////////////////////////            
        } else {
        if ($this->ses->get('user')['ID']) {
            $this->tpl->set('content', $this->tpl->fetch('modules/user/acess_failed_message.php'));
        } else {
            header('Location:' . $this->crg->get('route')['base_path'] . '/user/auth/login');
        }
        }
    } 
    ///////////////////////////////////
     function producttype() {
        
        if ($this->crg->get('wp') || $this->crg->get('rp')) {
        
        /////////////////////////////////////////////
        /////access condition applied////////////////
        /////////////////////////////////////////////
          
           include_once 'util/DBUTIL.php';
           $dbutil = new DBUTIL($this->crg);
             
            $entityID = $this->ses->get('user')['entity_ID'];
            $userID = $this->ses->get('user')['ID'];
            
            $pdttype_tab = $this->crg->get('table_prefix') . 'producttype';
                 
            ////////////////////start//////////////////////////////////////////////
                    
           //bUILD SQL 
            $whereString = '';
            
            $colArr = array(
                "$pdttype_tab.ID", 
                "$pdttype_tab.ProductType",
                "$pdttype_tab.Description"
            );
            
            $this->tpl->set('FmData', $_POST);
            foreach($_POST as $k=>$v){
                if(strpos($k,'^')){
                    unset($_POST[$k]);
                }
                $_POST[str_replace('^','_',$k)] = $v;
            }
            $PD=$_POST;
            if($_POST['list']!=''){
                $this->tpl->set('FmData', NULL);
                $PD=NULL;
            }

            IF (count($PD) >= 2) {
                $wsarr = array();
                foreach ($colArr as $colNames) {

		   if (strpos($colNames, 'Date') !== false) {
                list($colNames,$x) = $dbutil->dateFilterFormat($colNames);
            } else {
		        $x = $dbutil->__mdsf($PD[str_replace('.','_',$colNames)]);
            }

                    if ('' != $x) {
                        $wsarr[] = $colNames . " LIKE '%" . $x . "%'";
                    }
                }
                
              IF (count($wsarr) >= 1) {
                 $whereString = ' AND '. implode(' AND ', $wsarr);
              }
            }
            
            $orderBy ="ORDER BY $pdttype_tab.ID DESC";
            
         $sql = "SELECT "
                 . implode(',',$colArr)
                 . " FROM $pdttype_tab "
                 . " WHERE "
                 . " $pdttype_tab.entity_ID=$entityID "
                 . " $whereString "
                 . " $orderBy";
         
            $results_per_page = 50;     
            
                if(isset($PD['pageno'])){$page=$PD['pageno'];}
                else if(isset($PD['pagenof'])){$page=$PD['pagenofirst'];}
                else if(isset($PD['pagenop'])){$page=$PD['pagenoprev'];}
                else if(isset($PD['pagenon'])){$page=$PD['pagenonext'];}
                else if(isset($PD['pagenol'])){$page=$PD['pagenolast'];}
                else if(isset($PD['pagenog'])){$page=$PD['pagenogo'];}
                else{$page=1;} 
         
            /*
             * SET DATA TO TEMPLATE
             */
            $this->tpl->set('sql_data_rows', $dbutil->setPaginationList($sql,$page,$results_per_page,$wsarr));
            /*
             * set table label
             */
            $this->tpl->set('table_columns_label_arr', array('ID','Product Category','Description'));
            
            /*,;;
             * selectColArr for filter form
             */
            
            $this->tpl->set('selectColArr',$colArr);
                        
            /*
             * set pagination template
             */
            $this->crg->set('paginationListTemplate','factory/template/sql_based_crud_paginated_table.php');
                   
            //////////////////////close//////////////////////////////////////  
          
            include_once $this->tpl->path .'/factory/form/crud_form_producttype.php';
            $cus_form_data = Form_Elements::data($this->crg);
            include_once 'util/crud3_1.php';
            new Crud3($this->crg, $cus_form_data);
            $this->tpl->set('master_layout', 'layout_datepicker.php'); 
             //if crud is delivered at different point a template
            //Then  call that template and set to content
           
           ////$this->tpl->set('content', $this->tpl->fetch('modules/customer/manage_customer.php'));
        //////////////////////////////////////////////////////////////////////////////////
        //////////////////////////////on access condition failed then ///////////////////////////
        ////////////////////////////////////////////////////////////////////////////////            
        } else {
            if ($this->ses->get('user')['ID']) {
                $this->tpl->set('content', $this->tpl->fetch('modules/user/acess_failed_message.php'));
            } else {
                header('Location:' . $this->crg->get('route')['base_path'] . '/user/auth/login');
            }
        }
    } 
    //////////////////////////////////
    function pdndept() {
        if ($this->crg->get('wp') || $this->crg->get('rp')) {
            
            /////////////////////////////////////////////////////////
            //////////////////////////////access condition applied///
            /////////////////////////////////////////////////////////
                      
            include_once 'util/DBUTIL.php';
            $dbutil = new DBUTIL($this->crg);
             
            $entityID = $this->ses->get('user')['entity_ID'];
            $userID = $this->ses->get('user')['ID'];
            
            
            $pdndept_tab = $this->crg->get('table_prefix') . 'pdndepartment';
                  
            ////////////////////start//////////////////////////////////////////////
                    
           //bUILD SQL 
            $whereString = '';
            
            $colArr = array(
                "$pdndept_tab.ID", 
                "$pdndept_tab.DeptName",
                "$pdndept_tab.Description"
               
            );
            
            $this->tpl->set('FmData', $_POST);
            foreach($_POST as $k=>$v){
                if(strpos($k,'^')){
                    unset($_POST[$k]);
                }
                $_POST[str_replace('^','_',$k)] = $v;
            }
            $PD=$_POST;
            if($_POST['list']!=''){
                $this->tpl->set('FmData', NULL);
                $PD=NULL;
            }

            IF (count($PD) >= 2) {
                $wsarr = array();
                foreach ($colArr as $colNames) {

		   if (strpos($colNames, 'Date') !== false) {
                list($colNames,$x) = $dbutil->dateFilterFormat($colNames);
            } else {
		        $x = $dbutil->__mdsf($PD[str_replace('.','_',$colNames)]);
            }

                    if ('' != $x) {
                        $wsarr[] = $colNames . " LIKE '%" . $x . "%'";
                    }
                }
                
              IF (count($wsarr) >= 1) {
                 $whereString = ' AND '. implode(' AND ', $wsarr);
              }
            }
            
            $orderBy ="ORDER BY $pdndept_tab.ID DESC";
            
         $sql = "SELECT "
                 . implode(',',$colArr)
                 . " FROM $pdndept_tab "
                 . " WHERE "
                 . " $pdndept_tab.entity_ID=$entityID "
                 . " $whereString "
                 . " $orderBy";
         
            $results_per_page = 50;     
            
                if(isset($PD['pageno'])){$page=$PD['pageno'];}
                else if(isset($PD['pagenof'])){$page=$PD['pagenofirst'];}
                else if(isset($PD['pagenop'])){$page=$PD['pagenoprev'];}
                else if(isset($PD['pagenon'])){$page=$PD['pagenonext'];}
                else if(isset($PD['pagenol'])){$page=$PD['pagenolast'];}
                else if(isset($PD['pagenog'])){$page=$PD['pagenogo'];}
                else{$page=1;} 
         
            /*
             * SET DATA TO TEMPLATE
             */
            $this->tpl->set('sql_data_rows', $dbutil->setPaginationList($sql,$page,$results_per_page,$wsarr));
            /*
             * set table label
             */
            $this->tpl->set('table_columns_label_arr', array('ID','Production Department','Description'));
            
            /*,;;
             * selectColArr for filter form
             */
            
            $this->tpl->set('selectColArr',$colArr);
                        
            /*
             * set pagination template
             */
            $this->crg->set('paginationListTemplate','factory/template/sql_based_crud_paginated_table.php');
                   
            //////////////////////close//////////////////////////////////////  
          
             include_once $this->tpl->path .'/factory/form/crud_form_pdndepartment.php';
            
            
            $cus_form_data = Form_Elements::data($this->crg);
            include_once 'util/crud3_1.php';
            new Crud3($this->crg, $cus_form_data);
            $this->tpl->set('master_layout', 'layout_datepicker.php'); 
             //if crud is delivered at different point a template
            //Then  call that template and set to content
           
           ////$this->tpl->set('content', $this->tpl->fetch('modules/customer/manage_customer.php'));
        //////////////////////////////////////////////////////////////////////////////////
        //////////////////////////////on access condition failed then ///////////////////////////
        ////////////////////////////////////////////////////////////////////////////////            
        } else {
            if ($this->ses->get('user')['ID']) {
                $this->tpl->set('content', $this->tpl->fetch('modules/user/acess_failed_message.php'));
            } else {
                header('Location:' . $this->crg->get('route')['base_path'] . '/user/auth/login');
            }
        }
    }   
    ////////////////////////////////////////////////
	
	//////////////////////////////////////////////////////////////////////////////////////////////////////
	////////////////////////////////////////////////////////////////////////////////////////////////////////
	////////////////////////////////// Feasibility Review Report////////////////////////////////////////
	/////////////////////////////////////////////////////////////////////////////////////////////////
	
	 function feasibility_review_report(){
if ($this->crg->get('wp') || $this->crg->get('rp')) {
 ////////////////////////////////////////////////////////////////////////////////
 //////////////////////////////access condition applied//////////////////////////
 ////////////////////////////////////////////////////////////////////////////////    
            
            include_once 'util/DBUTIL.php';
            $dbutil = new DBUTIL($this->crg);
             
            $entityID = $this->ses->get('user')['entity_ID'];
            $userID = $this->ses->get('user')['ID'];     			
            $enquirydetail_table = $this->crg->get('table_prefix') . 'enquirydetail';		 
            $enquiry_table=$this->crg->get('table_prefix') . 'enquiry';
			$feasibility_review_report_table=$this->crg->get('table_prefix') . 'feasibility_review_report';
             
              //department table data 
           
            $enquiry_sql = "SELECT ID,EnquiryNo FROM $enquiry_table ORDER BY $enquiry_table.ID DESC";
            $stmt = $this->db->prepare($enquiry_sql);            
            $stmt->execute();
            $enquiry_data  = $stmt->fetchAll();	
            $this->tpl->set('enquiry_data', $enquiry_data);
            
             //designation table data 
           
             $enquirydetail_sql = "SELECT ID,Quantity FROM $enquirydetail_table";
            $stmt = $this->db->prepare($enquirydetail_sql);            
            $stmt->execute();
            $enquirydetail_data  = $stmt->fetchAll();	
            $this->tpl->set('enquirydetail_data', $enquirydetail_data);
            $this->tpl->set('page_title', 'FEASIBILITY REVIEW REPORT');	          
            $this->tpl->set('page_header', 'Static Data');
            //Add Role when u submit the add role form
            $thisPageURL = $this->crg->get('route')['base_path'] . '/' . $this->crg->get('route')['module'] . '/' . $this->crg->get('route')['controller'] . '/' . $this->crg->get('route')['action'];

            $crud_string = null;
	
            if (isset($_POST['req_from_list_view'])) {
                $crud_string = strtolower($_POST['req_from_list_view']);
            }              
            
            //Edit submit
            if (!empty($_POST['edit_submit_button']) && $_POST['edit_submit_button'] == 'edit') {
                $crud_string = 'editsubmit';
            }

            //Add submit
            if (!empty($_POST['add_submit_button']) && $_POST['add_submit_button'] == 'add') {
                $crud_string = 'addsubmit';
            }


            switch ($crud_string) {
                 case 'delete':                    
                      $data = trim($_POST['ycs_ID']);
                      // var_dump($data); 
                       
                       
                    if (!$data) {
                        $this->tpl->set('message', 'Please select any one ID to '.$crud_string.'!');
                        $this->tpl->set('label', 'List');
                        $this->tpl->set('content', $this->tpl->fetch('factory/template/form_button_link.php'));
                       
                    }
                    $sqldetdelete="Delete from $feasibility_review_report_table  where $feasibility_review_report_table.ID=$data";  
                        $stmt = $this->db->prepare($sqldetdelete);            
                        
                        if($stmt->execute()){
                        $this->tpl->set('message', 'Feasibility Review Report deleted successfully');
                         $this->tpl->set('label', 'List');
                        $this->tpl->set('content', $this->tpl->fetch('factory/template/form_button_link.php'));
                        }
            break;
                case 'view':                    
                    $data = trim($_POST['ycs_ID']);
                 
                    if (!$data) {
                        $this->tpl->set('message', 'Please select any one ID to view!');
                        $this->tpl->set('label', 'List');
                        $this->tpl->set('content', $this->tpl->fetch('factory/template/form_button_link.php'));
                        break;
                    }
                    
                    //mode of form submit
                    $this->tpl->set('mode', 'view');
                    //set id to edit $ycs_ID
                    $this->tpl->set('ycs_ID', $data);                 
					 $sqlsrr = "SELECT * FROM `$feasibility_review_report_table` WHERE `$feasibility_review_report_table`.`ID` = '$data'";		
					 
                    $salarydetail_data = $dbutil->getSqlData($sqlsrr); 
                   
                
                    //view option     
                    $this->tpl->set('message', 'You can view Feasibility Review Report form');
                    $this->tpl->set('page_header', 'Static Data');
                    $this->tpl->set('FmData', $salarydetail_data); 
                    
                    $this->tpl->set('content', $this->tpl->fetch('factory/form/feasibility_review_report.php'));                    
                    break;
                
                case 'edit':                    
                    $data = trim($_POST['ycs_ID']);
               // var_dump($data);
                    if (!$data) {
                        $this->tpl->set('message', 'Please select any one ID to edit!');
                        $this->tpl->set('label', 'List');
                        $this->tpl->set('content', $this->tpl->fetch('factory/template/form_button_link.php'));
                        break;
                    }
                    
                    //mode of form submit
                    $this->tpl->set('mode', 'edit');
                    //set id to edit $ycs_ID
                    $this->tpl->set('ycs_ID', $data);              
					 $sqlsrr = "SELECT * FROM `$feasibility_review_report_table` WHERE `$feasibility_review_report_table`.`ID` = '$data'"; 	 
				 
                    $salarydetail_data = $dbutil->getSqlData($sqlsrr); 
                     
                    //edit option     
                    $this->tpl->set('message', 'You can edit ReasibilityReview Report form');
                    $this->tpl->set('page_header', 'Static Data');
                    $this->tpl->set('FmData', $salarydetail_data); 
                    
                    $this->tpl->set('content', $this->tpl->fetch('factory/form/feasibility_review_report.php'));                    
                    break;
                
                case 'editsubmit':             
                    $data = trim($_POST['ycs_ID']);
                    
                    //mode of form submit
                    $this->tpl->set('mode', 'edit');
                    //set id to edit $ycs_ID
                    $this->tpl->set('ycs_ID', $data);

                    //Post data
                    include_once 'util/genUtil.php';
                    $util = new GenUtil();
                    $form_post_data = $util->arrFltr($_POST);
                    // Profile_image,ID_Proof
                   // var_dump($form_post_data['ID_Proof']);die;
                
                    //Build SQL now                           
                        try{
                            
                            $Enquiry=$form_post_data['Enquiry'];  
                            $Title=$form_post_data['Title'];
                            $Quantity=$form_post_data['Quantity'];
                            $Status=$form_post_data['Status'];
							$Status1=$form_post_data['Status1'];
							$Status2=$form_post_data['Status2'];
							$Status3=$form_post_data['Status3'];
							$Status4=$form_post_data['Status4'];
							$Status5=$form_post_data['Status5'];
							$Status6=$form_post_data['Status6'];
							$Status7=$form_post_data['Status7'];
							$Status8=$form_post_data['Status8'];
							$Status9=$form_post_data['Status9'];
							$Status10=$form_post_data['Status10'];
							$Status11=$form_post_data['Status11'];
							$Status12=$form_post_data['Status12'];
							$Status13=$form_post_data['Status13'];
							$Status14=$form_post_data['Status14'];
							$Status15=$form_post_data['Status15'];
							$Status16=$form_post_data['Status16'];
							$Status17=$form_post_data['Status17'];
							$Status18=$form_post_data['Status18'];
							$Status19=$form_post_data['Status19'];
							$Status20=$form_post_data['Status20'];
							$Status21=$form_post_data['Status21'];
							$Status22=$form_post_data['Status22'];
							$Status23=$form_post_data['Status23'];
							$Status24=$form_post_data['Status24'];
							$Status25=$form_post_data['Status25'];
							$Status26=$form_post_data['Status26'];
							$Status27=$form_post_data['Status27'];
							$Status28=$form_post_data['Status28'];
							$Status29=$form_post_data['Status29'];
							$Status30=$form_post_data['Status30'];
							$Remark=$form_post_data['remark'];
							$Remark1=$form_post_data['remark1'];
							$Remark2=$form_post_data['remark2'];
							$Remark3=$form_post_data['remark3'];
							$Remark4=$form_post_data['remark4'];
							$Remark5=$form_post_data['remark5'];
							$Remark6=$form_post_data['remark6'];
							$Remark7=$form_post_data['remark7'];
							$Remark8=$form_post_data['remark8'];
							$Remark9=$form_post_data['remark9'];
							$Remark10=$form_post_data['remark10'];
							$Remark11=$form_post_data['remark11'];
							$Remark12=$form_post_data['remark12'];
							$Remark13=$form_post_data['remark13'];
							$Remark14=$form_post_data['remark14'];
							$Remark15=$form_post_data['remark15'];
							$Remark16=$form_post_data['remark16'];
							$Remark17=$form_post_data['remark17'];
							$Remark18=$form_post_data['remark18'];
							$Remark19=$form_post_data['remark19'];
							$Remark20=$form_post_data['remark20'];
							$Remark21=$form_post_data['remark21'];
							$Remark22=$form_post_data['remark22'];
							$Remark23=$form_post_data['remark23'];
							$Remark24=$form_post_data['remark24'];
							$Remark25=$form_post_data['remark25'];
							$Remark26=$form_post_data['remark26'];
							$Remark27=$form_post_data['remark27'];
							$Remark28=$form_post_data['remark28'];
							$Remark29=$form_post_data['remark29'];
							$Remark30=$form_post_data['remark30'];
							$check1=$form_post_data['check1'];
							$check2=$form_post_data['check2'];
							$check3=$form_post_data['check3'];
							$check4=$form_post_data['check4'];
							$check5=$form_post_data['check5'];
							$check6=$form_post_data['check6'];
							$check7=$form_post_data['check7'];
							$check8=$form_post_data['check8'];
							$Reason=$form_post_data['Reason'];
							$Reviewed_By=$form_post_data['Reviewed'];
							$Approved_By=$form_post_data['Approved'];

							               
                         $sql_update="Update $feasibility_review_report_table set Enquiry_ID='$Enquiry',
																   Title='$Title',
																   Quantity_ID='$Quantity',
																   Status='$Status',
																   Status1='$Status1',
																   Status2='$Status2',
																   Status3='$Status3',
																   Status4='$Status4',
																   Status5='$Status5',
																   Status6='$Status6',
																   Status7='$Status7',
																   Status8='$Status8',
																   Status9='$Status9',
																   Status10='$Status10',
																   Status11='$Status11',
																   Status12='$Status12',
																   Status13='$Status13',
																   Status14='$Status14',
																   Status15='$Status15',
																   Status16='$Status16',
																   Status17='$Status17',
																   Status18='$Status18',
																   Status19='$Status19',
																   Status20='$Status20',
																   Status21='$Status21',
																   Status22='$Status22',
																   Status23='$Status23',
																   Status24='$Status24',
																   Status25='$Status25',
																   Status26='$Status26',
																   Status27='$Status27',
																   Status28='$Status28',
																   Status29='$Status29',
																   Status30='$Status30',
																   Remark='$Remark',
																   Remark1='$Remark1',
																   Remark2='$Remark2',
																   Remark3='$Remark3',
																   Remark4='$Remark4',
																   Remark5='$Remark5',
																   Remark6='$Remark6',
																   Remark7='$Remark7',
																   Remark8='$Remark8',
																   Remark9='$Remark9',
																   Remark10='$Remark10',
																   Remark11='$Remark11',
																   Remark12='$Remark12',
																   Remark13='$Remark13',
																   Remark14='$Remark14',
																   Remark15='$Remark15',
																   Remark16='$Remark16',
																   Remark17='$Remark17',
																   Remark18='$Remark18',
																   Remark19='$Remark19',
																   Remark20='$Remark20',
																   Remark21='$Remark21',
																   Remark22='$Remark22',
																   Remark23='$Remark23',
																   Remark24='$Remark24',
																   Remark25='$Remark25',
																   Remark26='$Remark26',
																   Remark27='$Remark27',
																   Remark28='$Remark28',
																   Remark29='$Remark29',
																   Remark30='$Remark30',
																   check1='$check1',
																   check2='$check2',
																   check3='$check3',
																   check4='$check4',
																   check5='$check5',
																   check6='$check6',
																   check7='$check7',
																   check8='$check8',
																   Reason='$Reason',
																   Reviewed_By='$Reviewed_By',
																   Approved_By='$Approved_By'
																   
																   WHERE ID=$data";   
								
						$stmt1 = $this->db->prepare($sql_update);
                        $stmt1->execute(); 
                            $this->tpl->set('message', 'Feasibility Review Report form edited successfully!');   
                            $this->tpl->set('label', 'List');
                            $this->tpl->set('content', $this->tpl->fetch('factory/template/form_button_link.php'));
                            } catch (Exception $exc) {
                             //edit failed option
                            $this->tpl->set('message', 'Failed to edit, try again!');
                            $this->tpl->set('FmData', $form_post_data);
                            $this->tpl->set('content', $this->tpl->fetch('factory/form/feasibility_review_report.php'));
                            }

                    break;

                case 'addsubmit':
                     if (isset($crud_string)) {
                         
                        $form_post_data = $dbutil->arrFltr($_POST);
                        
                         include_once 'util/genUtil.php';
                         $util = new GenUtil();
                        
                       // var_dump($_POST);
                       //var_dump($_FILES);die;
                        
                        $entry_count = 1;
                       
                            if (isset($form_post_data['Enquiry'])) {
                           
                                    $val =  "'" . $form_post_data['Enquiry'] . "'," .
                                            "'" . $form_post_data['Title'] . "'," .
                                            "'" . $form_post_data['Quantity'] . "'," .
                                            "'" . $form_post_data['Status'] . "'," .
											"'" . $form_post_data['Status1'] . "'," .
											"'" . $form_post_data['Status2'] . "'," .
											"'" . $form_post_data['Status3'] . "'," .
											"'" . $form_post_data['Status4'] . "'," .
											"'" . $form_post_data['Status5'] . "'," .
											"'" . $form_post_data['Status6'] . "'," .
											"'" . $form_post_data['Status7'] . "'," .
											"'" . $form_post_data['Status8'] . "'," .
											"'" . $form_post_data['Status9'] . "'," .
											"'" . $form_post_data['Status10'] . "'," .
											"'" . $form_post_data['Status11'] . "'," .
											"'" . $form_post_data['Status12'] . "'," .
											"'" . $form_post_data['Status13'] . "'," .
											"'" . $form_post_data['Status14'] . "'," .
											"'" . $form_post_data['Status15'] . "'," .
											"'" . $form_post_data['Status16'] . "'," .
											"'" . $form_post_data['Status17'] . "'," .
											"'" . $form_post_data['Status18'] . "'," .
											"'" . $form_post_data['Status19'] . "'," .
											"'" . $form_post_data['Status20'] . "'," .
											"'" . $form_post_data['Status21'] . "'," .
											"'" . $form_post_data['Status22'] . "'," .
											"'" . $form_post_data['Status23'] . "'," .
											"'" . $form_post_data['Status24'] . "'," .
											"'" . $form_post_data['Status25'] . "'," .
											"'" . $form_post_data['Status26'] . "'," .
											"'" . $form_post_data['Status27'] . "'," .
											"'" . $form_post_data['Status28'] . "'," .
											"'" . $form_post_data['Status29'] . "'," .
											"'" . $form_post_data['Status30'] . "'," .
                                            "'" . $form_post_data['remark'] . "'," .
											"'" . $form_post_data['remark1'] . "'," .
											"'" . $form_post_data['remark2'] . "'," .
											"'" . $form_post_data['remark3'] . "'," .
											"'" . $form_post_data['remark4'] . "'," .
											"'" . $form_post_data['remark5'] . "'," .
											"'" . $form_post_data['remark6'] . "'," .
											"'" . $form_post_data['remark7'] . "'," .
											"'" . $form_post_data['remark8'] . "'," .
											"'" . $form_post_data['remark9'] . "'," .
											"'" . $form_post_data['remark10'] . "'," .
											"'" . $form_post_data['remark11'] . "'," .
											"'" . $form_post_data['remark12'] . "'," .
											"'" . $form_post_data['remark13'] . "'," .
											"'" . $form_post_data['remark14'] . "'," .
											"'" . $form_post_data['remark15'] . "'," .
											"'" . $form_post_data['remark16'] . "'," .
											"'" . $form_post_data['remark17'] . "'," .
											"'" . $form_post_data['remark18'] . "'," .
											"'" . $form_post_data['remark19'] . "'," .
											"'" . $form_post_data['remark20'] . "'," .
											"'" . $form_post_data['remark21'] . "'," .
											"'" . $form_post_data['remark22'] . "'," .
											"'" . $form_post_data['remark23'] . "'," .
											"'" . $form_post_data['remark24'] . "'," .
											"'" . $form_post_data['remark25'] . "'," .
											"'" . $form_post_data['remark26'] . "'," .
											"'" . $form_post_data['remark27'] . "'," .
											"'" . $form_post_data['remark28'] . "'," .
											"'" . $form_post_data['remark29'] . "'," .
											"'" . $form_post_data['remark30'] . "'," .
											"'" . $form_post_data['check1'] . "'," .
											"'" . $form_post_data['check2'] . "'," .
											"'" . $form_post_data['check3'] . "'," .
											"'" . $form_post_data['check4'] . "'," .
											"'" . $form_post_data['check5'] . "'," .
											"'" . $form_post_data['check6'] . "'," .
											"'" . $form_post_data['check7'] . "'," .
											"'" . $form_post_data['check8'] . "'," .
											"'" . $form_post_data['Reason'] . "'," .
											"'" . $form_post_data['Reviewed'] . "'," .
											"'" . $form_post_data['Approved'] . "'," .
                                            "'" .  $this->ses->get('user')['entity_ID'] . "'," .
                                            "'" .  $this->ses->get('user')['ID'] . "'";

                         $sql = "INSERT INTO `" . $this->crg->get('table_prefix') . "feasibility_review_report`
                                            ( 
                                            `Enquiry_ID`,
                                            `Title`, 
                                            `Quantity_ID`, 
											`Status`,
											`Status1`,
											`Status2`,
											`Status3`,
											`Status4`,
											`Status5`,
											`Status6`,
											`Status7`,
											`Status8`,
											`Status9`,
											`Status10`,
											`Status11`,
											`Status12`,
											`Status13`,
											`Status14`,
											`Status15`,
											`Status16`,
											`Status17`,
											`Status18`,
											`Status19`,
											`Status20`,
											`Status21`,
											`Status22`,
											`Status23`,
											`Status24`,
											`Status25`,
											`Status26`,
											`Status27`,
											`Status28`,
											`Status29`,
											`Status30`,
											`Remark`,
											`Remark1`,
											`Remark2`,
											`Remark3`,
											`Remark4`,
											`Remark5`,
											`Remark6`,
											`Remark7`,
											`Remark8`,
											`Remark9`,
											`Remark10`,
											`Remark11`,
											`Remark12`,
											`Remark13`,
											`Remark14`,
											`Remark15`,
											`Remark16`,
											`Remark17`,
											`Remark18`,
											`Remark19`,
											`Remark20`,
											`Remark21`,
											`Remark22`,
											`Remark23`,
											`Remark24`,
											`Remark25`,
											`Remark26`,
											`Remark27`,
											`Remark28`,
											`Remark29`,
											`Remark30`,
											`check1`,
											`check2`,
											`check3`,
											`check4`,
											`check5`,
											`check6`,
											`check7`,
											`check8`,
											`Reason`,
											`Reviewed_By`,
											`Approved_By`,
                                            `entity_ID`,
                                            `users_ID`
                                            ) 
                                        VALUES ( $val )";   		
                                  $stmt = $this->db->prepare($sql);
								  $stmt->execute();
                        }
                        $this->tpl->set('mode', 'add');
                        $this->tpl->set('message', '- Success -');
                        header('Location:' . $this->crg->get('route')['base_path'] . '/admin/mast/feasibility_review_report');
                     } else {
                            //edit option
                            //if submit failed to insert form
                            $this->tpl->set('message', 'Failed to submit!');
                            $this->tpl->set('FmData', $form_post_data);
                            $this->tpl->set('content', $this->tpl->fetch('factory/form/feasibility_review_report.php'));
                     }
                    break;
                case 'add':
                    $this->tpl->set('mode', 'add');
	                $this->tpl->set('page_header', 'Static Data');
                    $staffcode=$dbutil->keyGeneration('staff_info','GMH','','StaffCode');
                    $this->tpl->set('staffcode', $staffcode);
                    $this->tpl->set('content', $this->tpl->fetch('factory/form/feasibility_review_report.php'));
                    break;

                default:
                    /*
                     * List form
                     */
                     
                    ////////////////////start//////////////////////////////////////////////
                    
           //bUILD SQL 
            $whereString = '';
            
         $colArr = array(
				"$feasibility_review_report_table.ID",
                "$enquiry_table.EnquiryNo",
                
                "$feasibility_review_report_table.Title", 
				"$enquirydetail_table.Quantity",
                "$feasibility_review_report_table.Status",
                "$feasibility_review_report_table.Remark",
                //"$feasibility_review_report_table.check1",
				//"$feasibility_review_report_table.check2",
				"$feasibility_review_report_table.Reason",
				"$feasibility_review_report_table.Reviewed_By",
				"$feasibility_review_report_table.Approved_By"
            );
            
            $this->tpl->set('FmData', $_POST);
            foreach($_POST as $k=>$v){
                if(strpos($k,'^')){
                    unset($_POST[$k]);
                }
                $_POST[str_replace('^','_',$k)] = $v;
            }
            $PD=$_POST;
            if($_POST['list']!=''){
                $this->tpl->set('FmData', NULL);
                $PD=NULL;
            }

            IF (count($PD) >= 2) {
                $wsarr = array();
                foreach ($colArr as $colNames) {

	            if (strpos($colNames, 'DATE') !== false) {
                    list($colNames,$x) = $dbutil->dateFilterFormat($colNames);                    
                }else {
        		    $x = $dbutil->__mdsf($PD[str_replace('.','_',$colNames)]);        		    
                }

                  if ('' != $x) {
                   $wsarr[] = $colNames . " LIKE '%" . $x . "%'";
                    }
                }
                
           IF (count($wsarr) >= 1) {
                $whereString = ' AND '. implode(' AND ', $wsarr);
            }
           } else {
             $whereString ="ORDER BY $feasibility_review_report_table.ID DESC";
           }
            
        $sql = "SELECT "
                    . implode(',',$colArr)
                    . " FROM $feasibility_review_report_table LEFT JOIN $enquiry_table ON $enquiry_table.ID=$feasibility_review_report_table.Enquiry_ID LEFT JOIN 	$enquirydetail_table ON $enquirydetail_table.ID=$feasibility_review_report_table.Quantity_ID"
                    . " WHERE "
                    . " $feasibility_review_report_table.entity_ID = $entityID"
                    . " $whereString";		
            
         
    
                $results_per_page = 50;     
            
                if(isset($PD['pageno'])){$page=$PD['pageno'];}
                else if(isset($PD['pagenof'])){$page=$PD['pagenofirst'];}
                else if(isset($PD['pagenop'])){$page=$PD['pagenoprev'];}
                else if(isset($PD['pagenon'])){$page=$PD['pagenonext'];}
                else if(isset($PD['pagenol'])){$page=$PD['pagenolast'];}
                else if(isset($PD['pagenog'])){$page=$PD['pagenogo'];}
                else{$page=1;} 
            /*
             * SET DATA TO TEMPLATE
                        */
           $this->tpl->set('sql_data_rows', $dbutil->setPaginationList($sql,$page,$results_per_page,$wsarr));
         
         
            $this->tpl->set('table_columns_label_arr', array('ID','Enquiry No','Title','Quantity','Status','Remark','Reason','Reviewed_By','Approved_By'));
			
			// $this->tpl->set('table_columns_label_arr', array('ID','Enquiry No','Title','Quantity','Status','Remark','Design','Tender','Reason','Reviewed_By','Approved_By'));
            
            /*
             * selectColArr for filter form
             */
            
            $this->tpl->set('selectColArr',$colArr);
                        
            /*
             * set pagination template
             */
            $this->crg->set('paginationListTemplate','factory/template/sql_based_crud_paginated_table.php');
                   
            //////////////////////close//////////////////////////////////////  
                     
                    include_once $this->tpl->path . '/factory/form/crud_feasibility_review_report.php';
                    $cus_form_data = Form_Elements::data($this->crg);
                    include_once 'util/crud3_1.php';
                    new Crud3($this->crg, $cus_form_data);
                    break;
            }

	    ///////////////Use different template////////////////////
	    $this->tpl->set('master_layout', 'layout_datepicker.php'); 
////////////////////////////////////////////////////////////////////////////////
//////////////////////////////on access condition failed then //////////////////
//////////////////////////////////////////////////////////////////////////////// 
     } else {
             if ($this->ses->get('user')['ID']) {
                 $this->tpl->set('content', $this->tpl->fetch('modules/user/acess_failed_message.php'));
             } else {
                 header('Location:' . $this->crg->get('route')['base_path'] . '/user/auth/login');
             }
         }
    }
	
	/////////////////////////////////////////////////////////////////////////////////////////////////////////
	//////////////////////////////////////////////////////////////////////////////////////////////////////////
	///////////////////////////////////   PROFORMA  INVOICE/////////////////////////////////////////////////?
	/////////////////////////////////////////////////////////////////////////////////////////////////////////
	
function proforma_invoice(){
     if ($this->crg->get('wp') || $this->crg->get('rp')) {
             
            ////////////////////////////////////////////////////////////////////////////////
            //////////////////////////////access condition applied//////////////////////////
            ////////////////////////////////////////////////////////////////////////////////    
            
            include_once 'util/DBUTIL.php';
            $dbutil = new DBUTIL($this->crg);
             
            $entityID = $this->ses->get('user')['entity_ID'];
            $userID = $this->ses->get('user')['ID'];
			
			
            $state_table = $this->crg->get('table_prefix') . 'state';
            $unit_tab = $this->crg->get('table_prefix') . 'unit';		
			$enquiry_tab = $this->crg->get('table_prefix') . 'enquiry';
	/*		$state_tab = $this->crg->get('table_prefix') . 'state';		*/
			$proforma_add_invoice_tab = $this->crg->get('table_prefix') . 'proforma_add_invoice';
			$proforma_invoice_tab = $this->crg->get('table_prefix') . 'proforma_invoice';
			$customer_table = $this->crg->get('table_prefix') . 'customer';
			$companydetails = $this->crg->get('table_prefix') . 'companydetails';
			
			//enquiry table data 
           
            $enquiry_sql = "SELECT ID,EnquiryNo,PONo FROM $enquiry_tab";
            $stmt = $this->db->prepare($enquiry_sql);            
            $stmt->execute();
            $enquiry_data  = $stmt->fetchAll();	
            $this->tpl->set('enquiry_data', $enquiry_data);
			
			//unit table
			
			 //state table data 
           
            $unit_sql = "SELECT ID,UnitName FROM $unit_tab";
            $stmt = $this->db->prepare($unit_sql);            
            $stmt->execute();
            $unit_data  = $stmt->fetchAll();	
            $this->tpl->set('unit_data', $unit_data);
			
			 //state table data 
           
 /*           $state_sql = "SELECT ID,StateName FROM $state_tab";
            $stmt = $this->db->prepare($state_sql);            
            $stmt->execute();
            $state_data  = $stmt->fetchAll();	
            $this->tpl->set('state_data', $state_data);		*/
            
           
            $this->tpl->set('page_title', 'Proforma Invoice Process');	          
            $this->tpl->set('page_header', 'Production');
            //Add Role when u submit the add role form
            $thisPageURL = $this->crg->get('route')['base_path'] . '/' . $this->crg->get('route')['module'] . '/' . $this->crg->get('route')['controller'] . '/' . $this->crg->get('route')['action'];

            $crud_string = null;
		//	echo '<pre>';
		//	console.log($_POST['req_from_list_view']); die;
            if (isset($_POST['req_from_list_view'])) {
                $crud_string = strtolower($_POST['req_from_list_view']);
				  // echo '<pre>';
			  // print_r($crud_string); die;
            }              
            
            //Edit submit
            if (!empty($_POST['edit_submit_button']) && $_POST['edit_submit_button'] == 'edit') {
                $crud_string = 'editsubmit';
            }

            //Add submit
            if (!empty($_POST['add_submit_button']) && $_POST['add_submit_button'] == 'add') {
                $crud_string = 'addsubmit';
            }


            switch ($crud_string) {
                 case 'delete':                    
                      $data = trim($_POST['ycs_ID']);
					  // echo '<pre>';
                       // print_r($data); die;
                       
                       
                    if (!$data) {
                        $this->tpl->set('message', 'Please select any one ID to '.$crud_string.'!');
                        $this->tpl->set('label', 'List');
                        $this->tpl->set('content', $this->tpl->fetch('factory/template/form_button_link.php'));
                       
                    }
                     
                      $sqldetdelete="Delete $proforma_add_invoice_tab,$proforma_invoice_tab from          $proforma_invoice_tab
                                        LEFT JOIN  $proforma_add_invoice_tab ON $proforma_add_invoice_tab.proforma_invoice_ID=$proforma_invoice_tab.ID 
                                        where $proforma_invoice_tab.ID=$data"; 	
						$stmt = $this->db->prepare($sqldetdelete);
                        
                        if($stmt->execute()){
                        $this->tpl->set('message', 'Process deleted successfully');
                        header('Location:' . $this->crg->get('route')['base_path'] . '/admin/mast/proforma_invoice');
                        // $this->tpl->set('label', 'List');
                        // $this->tpl->set('content', $this->tpl->fetch('factory/template/form_button_link.php'));
                        }
            break;
                case 'view':                    
                    $data = trim($_POST['ycs_ID']);
                 
                    if (!$data) {
                        $this->tpl->set('message', 'Please select any one me to view!');
                        $this->tpl->set('label', 'List');
                        $this->tpl->set('content', $this->tpl->fetch('factory/template/form_button_link.php'));
                        break;
                    }
                    
                    //mode of form submit
                    $this->tpl->set('mode', 'view');
                    //set id to edit $ycs_ID
                    $this->tpl->set('ycs_ID', $data);     

		$sqlsrr="SELECT *,$enquiry_tab.PONo,$customer_table.PersonName,$customer_table.CompanyName,$customer_table.GSTNo,$customer_table.BillingAddress1,$customer_table.BillingAddress2,$customer_table.BillingCity,$state_table.StateName,$customer_table.BillingZip 
			   	FROM $proforma_invoice_tab 
							  LEFT JOIN $enquiry_tab ON $enquiry_tab.ID = $proforma_invoice_tab.Enquiry_No
							  LEFT JOIN $customer_table ON $customer_table.ID = $enquiry_tab.customer_ID 
							  LEFT JOIN $state_table ON $state_table.ID = $customer_table.BillingState_ID
					          LEFT JOIN $proforma_add_invoice_tab ON $proforma_add_invoice_tab.proforma_invoice_ID=$proforma_invoice_tab.ID
					          WHERE $proforma_invoice_tab.ID = $data";		
				
		// echo	$sqlsrr="SELECT *,$enquiry_tab.PONo,$customer_table.PersonName,$customer_table.CompanyName,$customer_table.GSTNo,$customer_table.BillingAddress1,$customer_table.BillingAddress2,$customer_table.BillingCity,$state_table.StateName,$customer_table.BillingCountry_ID,$customer_table.BillingZip 
				// FROM $proforma_invoice_tab 
							  // LEFT JOIN $enquiry_tab ON $enquiry_tab.ID = $proforma_invoice_tab.Enquiry_No
							  // LEFT JOIN $customer_table ON $customer_table.ID = $enquiry_tab.employee_ID 
							  // LEFT JOIN $state_table ON $state_table.ID = $customer_table.BillingState_ID
					          // LEFT JOIN $proforma_add_invoice_tab ON $proforma_add_invoice_tab.proforma_invoice_ID=$proforma_invoice_tab.ID
					          // WHERE $proforma_invoice_tab.ID = $data";		die;
							  
                                
                    //$sqlsrr = "SELECT * FROM `$proforma_invoice_tab`,`$proforma_add_invoice_tab` //WHERE`$proforma_add_invoice_tab`.`proforma_invoice_ID`=`$proforma_invoice_tab`.`ID` //AND`$proforma_invoice_tab`.`ID` = '$data'";
				//	$sqlsrr = "SELECT  * FROM `$proforma_invoice_tab` WHERE `$proforma_invoice_tab`.`ID` = '$data'";                    
                   $process_data = $dbutil->getSqlData($sqlsrr); 
                    
                    //edit option     
                    $this->tpl->set('message', 'You can view Proforma Invoice form');
                    $this->tpl->set('page_header', 'Production');
                    $this->tpl->set('FmData', $process_data); 
                    
                    $this->tpl->set('content', $this->tpl->fetch('factory/form/proforma_invoice.php'));                    
               break;
					
					//           check pdf generation
					
				case 'pdf_generation':                    
                    $data = trim($_POST['ycs_ID']);
                 // echo '<pre>';
				 // print_r($_POST['ycs_ID']); die;
                    if (!$data) {
                        $this->tpl->set('message', 'Please select any one to pdf generation!');
                        $this->tpl->set('label', 'List');
                        $this->tpl->set('content', $this->tpl->fetch('factory/template/form_button_link.php'));
                        break;
                    }
                    
                    //mode of form submit
                    $this->tpl->set('mode', 'pdf_generation');
                    //set id to edit $ycs_ID
                    $this->tpl->set('ycs_ID', $data);     

			$sqlsrr="SELECT *,$enquiry_tab.PONo,$customer_table.PersonName,$customer_table.CompanyName,$customer_table.GSTNo,$customer_table.BillingAddress1,$customer_table.BillingAddress2,$customer_table.BillingCity,$state_table.StateName,$customer_table.BillingZip 
			   	FROM $proforma_invoice_tab 
							  LEFT JOIN $enquiry_tab ON $enquiry_tab.ID = $proforma_invoice_tab.Enquiry_No
							  LEFT JOIN $customer_table ON $customer_table.ID = $enquiry_tab.customer_ID 
							  LEFT JOIN $state_table ON $state_table.ID = $customer_table.BillingState_ID
					          LEFT JOIN $proforma_add_invoice_tab ON $proforma_add_invoice_tab.proforma_invoice_ID=$proforma_invoice_tab.ID
					          WHERE $proforma_invoice_tab.ID = $data";	
							  
                                
                    //$sqlsrr = "SELECT * FROM `$proforma_invoice_tab`,`$proforma_add_invoice_tab` //WHERE`$proforma_add_invoice_tab`.`proforma_invoice_ID`=`$proforma_invoice_tab`.`ID` //AND`$proforma_invoice_tab`.`ID` = '$data'";
				//	$sqlsrr = "SELECT  * FROM `$proforma_invoice_tab` WHERE `$proforma_invoice_tab`.`ID` = '$data'";                    
                   $process_data = $dbutil->getSqlData($sqlsrr); 
                    
                    //edit option     
                    $this->tpl->set('message', 'You can Generate PDF Proforma Invoice form');
                    $this->tpl->set('page_header', 'Production');
                    $this->tpl->set('FmData', $process_data); 
                   // header('Location:' . $this->crg->get('route')['base_path'] . '/admin/mast/proforma_invoice');
                    $this->tpl->set('content', $this->tpl->fetch('factory/form/proforma_Pdf.php'));                    
                    break;
					
					
					//            end pdf generation
                
                case 'edit':                    
                    $data = trim($_POST['ycs_ID']);
               // var_dump($data);
                    if (!$data) {
                        $this->tpl->set('message', 'Please select any one ID to edit!');
                        $this->tpl->set('label', 'List');
                        $this->tpl->set('content', $this->tpl->fetch('factory/template/form_button_link.php'));
                        break;
                    }
                    
                    //mode of form submit
                    $this->tpl->set('mode', 'edit');
                    //set id to edit $ycs_ID
                    $this->tpl->set('ycs_ID', $data);         
                                
                   // $sqlsrr = "SELECT  * FROM `$bomprocessdetail_tab`,`$bomprocessmaster_tab` WHERE `$bomprocessdetail_tab`.`proforma_invoice_ID`=`$bomprocessmaster_tab`.`ID` AND `$bomprocessdetail_tab`.`BOMProcessMaster_ID` = '$data'"; 
				   
 		/*	<possibility code 1>	*/	
	             $sqlsrr="SELECT *,$enquiry_tab.PONo,$customer_table.PersonName,$customer_table.CompanyName,$customer_table.GSTNo,$customer_table.BillingAddress1,$customer_table.BillingAddress2,$customer_table.BillingCity,$state_table.StateName,$customer_table.BillingCountry_ID,$customer_table.BillingZip 
				FROM $proforma_invoice_tab 
							  LEFT JOIN $enquiry_tab ON $enquiry_tab.ID = $proforma_invoice_tab.Enquiry_No
							  LEFT JOIN $customer_table ON $customer_table.ID = $enquiry_tab.employee_ID 
							  LEFT JOIN $state_table ON $state_table.ID = $customer_table.BillingState_ID
					          LEFT JOIN $proforma_add_invoice_tab ON $proforma_add_invoice_tab.proforma_invoice_ID=$proforma_invoice_tab.ID
					          WHERE $proforma_invoice_tab.ID = $data";		
							  
		/*	<possibility code 2> 			$sqlsrr="SELECT * FROM $proforma_invoice_tab,$proforma_add_invoice_tab
					         WHERE  $proforma_add_invoice_tab.proforma_invoice_ID=$proforma_invoice_tab.ID
					         AND $proforma_invoice_tab.ID = $data";  */
							  
					 // $sqlsrr = "SELECT  * FROM `$proforma_invoice_tab` WHERE `$proforma_invoice_tab`.`ID` = '$data'";				
                    $process_data = $dbutil->getSqlData($sqlsrr); 

                    //edit option     
                    $this->tpl->set('message', 'You can edit Proforma Invoice form');
                    $this->tpl->set('page_header', 'Production');
                    $this->tpl->set('FmData', $process_data); 
                    
                    $this->tpl->set('content', $this->tpl->fetch('factory/form/proforma_invoice.php'));                    
                    break;
                
                case 'editsubmit':             
                    $data = trim($_POST['ycs_ID']);
                  //  print_r($data); die;
                    //mode of form submit
                    $this->tpl->set('mode', 'edit');
                    //set id to edit $ycs_ID
                    $this->tpl->set('ycs_ID', $data);

                    //Post data
                    include_once 'util/genUtil.php';
                    $util = new GenUtil();
                    $form_post_data = $util->arrFltr($_POST);
                  try{

                               
												 $Enquiry_No=$form_post_data['Enquiry_No']; 	 
												 $GST_NO=$form_post_data['GST_NO'];
												 $Total=$form_post_data['Total'];
												 $GST=$form_post_data['GST'];
												 $CGST=$form_post_data['CGST'];
												$CGSTtotal=$form_post_data['CGSTtotal'];
												 $optradio=$form_post_data['optradio'];
												 $SGST=$form_post_data['SGST'];
												$SGSTtotal=$form_post_data['SGSTtotal'];
												 $IGST=$form_post_data['IGST'];
												$IGSTtotal=$form_post_data['IGSTtotal'];
												$Advance=$form_post_data['Advance'];
												 $Balance=$form_post_data['Balance']; 
  
                                $sql2 = "UPDATE $proforma_invoice_tab set  Enquiry_No='$Enquiry_No',

											GST_NO='$GST_NO',
											Total='$Total',
											GST='$GST',
											CGST='$CGST',
											CGSTtotal='$CGSTtotal',
											`CGST_&_SGST_&_IGST`='$optradio',
											SGST='$SGST',
											SGSTtotal='$SGSTtotal',
											IGST='$IGST',
											IGSTtotal='$IGSTtotal',
											Advance='$Advance',
											Balance='$Balance'

                                             WHERE ID=$data";			
                                        
                
                                $stmt = $this->db->prepare($sql2);
                                $stmt->execute();
								
								$maxCount = $form_post_data['maxCount']; 			   
                      
						 $sql3 = "DELETE FROM $proforma_add_invoice_tab WHERE proforma_invoice_ID=$data";
					     $stmt3 = $this->db->prepare($sql3);
						// $stmt3->execute();
                         //$is_delete = $stmt3->execute();
						 // var_dump($is_delete);die;
					   if($stmt3->execute()){
						  // echo '<pre>';
						  // print_r($_POST); 
                        FOR ($entry_count=1; $entry_count <= $maxCount; $entry_count++) {
                                
                             $Material = $form_post_data['Material_'.$entry_count];
                                $Uom_ID = $form_post_data['Uom_'.$entry_count];
                                $Quantity = $form_post_data['Quantity_'.$entry_count];
                                $price_unit = $form_post_data['price_unit_'.$entry_count];
                                $Value = $form_post_data['Value_'.$entry_count];
                              
							  if(!empty($Quantity) && !empty($price_unit)){
                                $vals = "'" . $data . "'," .
        								"'" . $Material . "'," .
                                        "'" . $Uom_ID . "'," .
                                        "'" . $Quantity . "'," .
                                        "'" . $price_unit . "'," .
                                        "'" . $Value . "'" ;
  
                                 $sql2 = "INSERT INTO $proforma_add_invoice_tab
                                        ( 
										    `proforma_invoice_ID`, 
                                            `Material`, 
                                            `unit_ID`,
                                            `Quantity`,
                                            `price_unit`,
                                            `Value`
                                        ) 
                                VALUES ($vals)";
                                $stmt = $this->db->prepare($sql2);
                                $stmt->execute();
							  }
								
                            //increment here
                            
                            } 
					   }
								
                            //increment here
                          //  $entry_count++;
                         //   }
                       
                            $this->tpl->set('message', 'Proforma Invoice form edited successfully!');   
                            //header('Location:' . $this->crg->get('route')['base_path'] . '/admin/mast/proforma_invoice');
                            $this->tpl->set('label', 'List');
                            $this->tpl->set('content', $this->tpl->fetch('factory/template/form_button_link.php'));
                            } catch (Exception $exc) {
                             //edit failed option
                            $this->tpl->set('message', 'Failed to edit, try again!');
                            $this->tpl->set('FmData', $form_post_data);
                            $this->tpl->set('content', $this->tpl->fetch('factory/form/proforma_invoice.php'));
                            }

                    break;

                case 'addsubmit':
                     if (isset($crud_string)) {
                         
                        $form_post_data = $dbutil->arrFltr($_POST);
							include_once 'util/genUtil.php';
                         $util = new GenUtil();
                        	//echo '<pre>';
                       // print_r($form_post_data);
                        
                       
                       
                            if (isset($form_post_data['Enquiry_No'])) {
								
                           
                                        $val = "'" . $form_post_data['Enquiry_No'] . "'," .
											
												
												
												
												
												"'" . $form_post_data['GST_NO'] . "'," .
												"'" . $form_post_data['Total'] . "'," .
												"'" . $form_post_data['GST'] . "'," .
												"'" . $form_post_data['CGST'] . "'," .
												"'" . $form_post_data['CGSTtotal'] . "'," .
												"'" . $form_post_data['optradio'] . "'," .
												"'" . $form_post_data['SGST'] . "'," .
												"'" . $form_post_data['SGSTtotal'] . "'," .
												"'" . $form_post_data['IGST'] . "'," .
												"'" . $form_post_data['IGSTtotal'] . "'," .
												"'" . $form_post_data['Advance'] . "'," .
												"'" . $form_post_data['Balance'] . "'," .
                                               "'" .  $this->ses->get('user')['entity_ID'] . "'," .
                                               "'" .  $this->ses->get('user')['ID'] . "'";

								$Enquiry_No=$form_post_data['Enquiry_No'];
					if($form_post_data['Enquiry_No']){			   
											   
                             $sql = "INSERT INTO `" . $this->crg->get('table_prefix') . "proforma_invoice`
                                            ( 
                                            `Enquiry_No`,
											
											
											
											
											
											`GST_NO`,
											`Total`,
											`GST`,
											`CGST`,
											`CGSTtotal`,
											`CGST_&_SGST_&_IGST`,
											`SGST`,
											`SGSTtotal`,
											`IGST`,
											`IGSTtotal`,
											`Advance`,
											`Balance`,
                                            `entity_ID`,
                                            `users_ID`
                                            ) 
                                        VALUES ( $val )";
                                  $stmt = $this->db->prepare($sql);		
                          
						
						//  $stmt->execute();

						//	$sql_update="UPDATE $enquiry_table SET EnquiryQuotation_Status=2 WHERE ID=$Enquiry_No";
                        // $stmt1 = $this->db->prepare($sql_update);
						// $stmt1->execute();
					}	
                                  
                    if ($stmt->execute()) { 
						$lastInsertedID = $this->db->lastInsertId();
					   $maxCount = $form_post_data['maxCount'];
					 //  echo '<pre>';
					//   print_r($_POST);
                        FOR ($entry_count=1; $entry_count <= $maxCount; $entry_count++) {
                                
                                $Material = $form_post_data['Material_'.$entry_count];
                                $Uom_ID = $form_post_data['Uom_'.$entry_count];
                                $Quantity = $form_post_data['Quantity_'.$entry_count];
                                $price_unit = $form_post_data['price_unit_'.$entry_count];
                                $Value = $form_post_data['Value_'.$entry_count];
                              
                                if(!empty($Quantity) && !empty($price_unit)){
                                $vals = "'" . $lastInsertedID . "'," .
        								"'" . $Material . "'," .
                                        "'" . $Uom_ID . "'," .
                                        "'" . $Quantity . "'," .
                                        "'" . $price_unit . "'," .
                                        "'" . $Value . "'" ;
  
                                 $sql2 = "INSERT INTO $proforma_add_invoice_tab
                                        ( 
										    `proforma_invoice_ID`, 
                                            `Material`, 
                                            `unit_ID`,
                                            `Quantity`,
                                            `price_unit`,
                                            `Value`
                                        ) 
                                VALUES ($vals)";
                                $stmt = $this->db->prepare($sql2);
                                $stmt->execute();
							  }
                            
                            } 
                    }		
                        }
                        $this->tpl->set('mode', 'add');
                        $this->tpl->set('message', '- Success -');
                        header('Location:' . $this->crg->get('route')['base_path'] . '/admin/mast/proforma_invoice');
                       // $this->tpl->set('content', $this->tpl->fetch('factory/form/bomprocess_form.php'));
                     } else {
                            //edit option
                            //if submit failed to insert form
                            $this->tpl->set('message', 'Failed to submit!');
                            $this->tpl->set('FmData', $form_post_data);
                            $this->tpl->set('content', $this->tpl->fetch('factory/form/proforma_invoice.php'));
                     }
                    break;
                case 'add':
                    $this->tpl->set('mode', 'add');
	                $this->tpl->set('page_header', 'Production');
                    $this->tpl->set('content', $this->tpl->fetch('factory/form/proforma_Pdf_cop.php'));
                    break;

                default:
                    /*
                     * List form
                     */
                     
                    ////////////////////start//////////////////////////////////////////////
                    
           //bUILD SQL 
            $whereString = '';
            
         $colArr = array(
				"$proforma_invoice_tab.ID",
                "$enquiry_tab.EnquiryNo",
				"$enquiry_tab.PONo",
				"$proforma_invoice_tab.GST",
				"$proforma_invoice_tab.Total"
                
            );
            
            $this->tpl->set('FmData', $_POST);
            foreach($_POST as $k=>$v){
                if(strpos($k,'^')){
                    unset($_POST[$k]);
                }
                $_POST[str_replace('^','_',$k)] = $v;
            }
            $PD=$_POST;
            if($_POST['list']!=''){
                $this->tpl->set('FmData', NULL);
                $PD=NULL;
            }

            IF (count($PD) >= 2) {
                $wsarr = array();
                foreach ($colArr as $colNames) {

	            if (strpos($colNames, 'DATE') !== false) {
                    list($colNames,$x) = $dbutil->dateFilterFormat($colNames);                    
                }else {
        		    $x = $dbutil->__mdsf($PD[str_replace('.','_',$colNames)]);        		    
                }

                  if ('' != $x) {
                   $wsarr[] = $colNames . " LIKE '%" . $x . "%'";
                    }
                }
                
           IF (count($wsarr) >= 1) {
                $whereString = ' AND '. implode(' AND ', $wsarr);
            }
           } else {
             $whereString ="ORDER BY $proforma_invoice_tab.ID DESC";
           }
            
       $sql = "SELECT "
                    . implode(',',$colArr)
                    . " FROM $proforma_invoice_tab LEFT JOIN $enquiry_tab ON $enquiry_tab.ID=$proforma_invoice_tab.Enquiry_No"
                    . " WHERE "
                    . " $proforma_invoice_tab.Enquiry_No= $enquiry_tab.ID AND "
                    . " $proforma_invoice_tab.entity_ID = $entityID"
                    . " $whereString";	
            
         
    
                $results_per_page = 50;     
            
                if(isset($PD['pageno'])){$page=$PD['pageno'];}
                else if(isset($PD['pagenof'])){$page=$PD['pagenofirst'];}
                else if(isset($PD['pagenop'])){$page=$PD['pagenoprev'];}
                else if(isset($PD['pagenon'])){$page=$PD['pagenonext'];}
                else if(isset($PD['pagenol'])){$page=$PD['pagenolast'];}
                else if(isset($PD['pagenog'])){$page=$PD['pagenogo'];}
                else{$page=1;} 
            /*
             * SET DATA TO TEMPLATE
                        */
           $this->tpl->set('sql_data_rows', $dbutil->setPaginationList($sql,$page,$results_per_page,$wsarr));
         
         
            $this->tpl->set('table_columns_label_arr', array('ID','EnquiryNo','Customer PO Number','GST','Total'));
            
            /*
             * selectColArr for filter form
             */
            
            $this->tpl->set('selectColArr',$colArr);
                        
            /*
             * set pagination template
             */
            $this->crg->set('paginationListTemplate','factory/template/sql_based_crud_paginated_table_Copy.php');
                   
            //////////////////////close//////////////////////////////////////  
                     
                    include_once $this->tpl->path . '/factory/form/crud_proforma_invoice .php';
                    $cus_form_data = Form_Elements::data($this->crg);
                    include_once 'util/crud3_1.php';
                    new Crud3($this->crg, $cus_form_data);
                    break;
            }

	    ///////////////Use different template////////////////////
	    $this->tpl->set('master_layout', 'layout_datepicker.php'); 
////////////////////////////////////////////////////////////////////////////////
//////////////////////////////on access condition failed then //////////////////
//////////////////////////////////////////////////////////////////////////////// 
     } else {
             if ($this->ses->get('user')['ID']) {
                 $this->tpl->set('content', $this->tpl->fetch('modules/user/acess_failed_message.php'));
             } else {
                 header('Location:' . $this->crg->get('route')['base_path'] . '/user/auth/login');
             }
         }
    }

}


